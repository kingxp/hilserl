import os
from tqdm import tqdm
import numpy as np
import copy
import pickle as pkl
import datetime
from absl import app, flags
import time
from pynput import keyboard

from experiments.mappings import CONFIG_MAPPING

FLAGS = flags.FLAGS
flags.DEFINE_string("exp_name", "plug_assembly", "Name of experiment corresponding to folder.")
flags.DEFINE_integer("successes_needed", 20, "Number of successful demos to collect.")
flags.DEFINE_integer("classifier_checkpoint_step", 200, "Step to load the classifier checkpoint.")
flags.DEFINE_integer("neg_context", 10, "人工判定时给末尾多少帧打标记（误判帧 + 前几帧，供后续回收负例）")

done_key = False

def on_press(key):
    global done_key
    try:
        if str(key) == 'Key.f5':  # 结束当前回合
            done_key = True
            print(">>> done_key = True")
    except AttributeError:
        pass

def main(_):
    global done_key

    listener = keyboard.Listener(on_press=on_press)
    listener.start()

    assert FLAGS.exp_name in CONFIG_MAPPING, 'Experiment folder not found.'
    config = CONFIG_MAPPING[FLAGS.exp_name]()
    env = config.get_environment(fake_env=False, 
                                save_video=False,
                                classifier_checkpoint_step=FLAGS.classifier_checkpoint_step)

    obs, info = env.reset()
    transitions = []
    success_count = 0
    rejected_count = 0          # 被人工否决（输入 0）的回合数
    success_needed = FLAGS.successes_needed
    pbar = tqdm(total=success_needed)
    trajectory = []
    returns = 0
    
    while success_count < success_needed:
        actions = np.zeros(env.action_space.sample().shape) 
        next_obs, rew, done, truncated, info = env.step(actions)
        returns += rew
        if "intervene_action" in info:
            actions = info["intervene_action"]
        transition = copy.deepcopy(
            dict(
                observations=obs,
                actions=actions,
                next_observations=next_obs,
                rewards=rew,
                masks=1.0 - done,
                dones=done,
                infos=info,
            )
        )
        trajectory.append(transition)
        
        pbar.set_description(f"Return: {returns}")

        obs = next_obs
        if done or done_key:
            done_key = False
            auto_success = bool(info.get("succeed", False))
            final_reward = rew

            # ---- 分类器判定成功时，改为人工确认 ----
            # 直接回车 = 采用分类器结果；输入数字 = 覆盖为新 reward（输入 0 视为没成功）
            if auto_success:
                while True:
                    ans = input(
                        f"\n[人工确认] 分类器判定本回合成功(reward={rew})。"
                        f"回车=采用；输入数字(如 0)=覆盖为新 reward > "
                    ).strip()
                    if ans == "":
                        break
                    try:
                        final_reward = float(ans)
                        break
                    except ValueError:
                        print("  输入无效：请直接回车，或输入数字（0=没成功，1=成功）")
                # 反例只需要"误判帧 + 它前面几帧"，没必要给整条回合(可能 300 帧)逐帧打标
                # 关键：必须同时保留【分类器原始判定】，否则后续无法区分
                #      "分类器判成功却被人工否决"(真反例) 与 "本来就失败"(普通负样本)
                n_tail = min(FLAGS.neg_context, len(trajectory))
                tail = trajectory[-n_tail:] if n_tail else []
                offset = len(trajectory) - len(tail)
                for i, t in enumerate(tail):
                    if isinstance(t.get("infos", None), dict):
                        # ---- 分类器原始判定（只读，不被覆盖）----
                        t["infos"]["classifier_reward"] = float(rew)
                        t["infos"]["classifier_succeed"] = bool(auto_success)
                        # ---- 人工判定 ----
                        t["infos"]["succeed"] = bool(final_reward)
                        t["infos"]["human_reward"] = final_reward
                        t["infos"]["human_labeled"] = True
                        t["infos"]["human_modified"] = bool(final_reward != rew)
                        # ---- 帧序号：后续取"误判帧 + 前 N 帧"要用 ----
                        t["infos"]["step_in_episode"] = offset + i
                if trajectory:
                    trajectory[-1]["rewards"] = final_reward           # 稀疏奖励落在终止帧
                if final_reward != rew:
                    print(f"  -> 分类器={rew} 人工={final_reward}"
                          f"（已标记末尾 {len(tail)}/{len(trajectory)} 帧）")

            if bool(final_reward):
                for transition in trajectory:
                    transitions.append(copy.deepcopy(transition))
                success_count += 1
                pbar.update(1)
            else:
                rejected_count += 1
                print(f"  -> 本回合未记为成功（累计否决 {rejected_count} 条）")

            trajectory = []
            returns = 0
            
            if success_count >= success_needed:
                break
            obs, info = env.reset()

    # 数据保存在当前路径下
    uuid = datetime.datetime.now().strftime("%Y-%m-%d")
    abs_save_floder = os.path.join(os.getcwd(), "demo_data", uuid)
    print(">>> demo_data_path = " + abs_save_floder)
    if not os.path.exists(abs_save_floder):
        os.makedirs(abs_save_floder) 

    uuid = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    file_name = f"{abs_save_floder}/{FLAGS.exp_name}_{success_needed}_demos_{uuid}.pkl"
    with open(file_name, "wb") as f:
        pkl.dump(transitions, f)
        print(f"saved {success_needed} demos to {file_name}")
    if rejected_count:
        print(f"[info] 本轮人工否决 {rejected_count} 条（这些回合未写入 demo 数据）")

    env.close()

if __name__ == "__main__":
    app.run(main)