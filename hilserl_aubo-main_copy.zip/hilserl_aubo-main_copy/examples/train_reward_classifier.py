import glob
import os
import pickle as pkl
import jax
from jax import numpy as jnp
import flax.linen as nn
from flax.training import checkpoints
import numpy as np
import optax
from tqdm import tqdm
from absl import app, flags

from serl_launcher.data.data_store import ReplayBuffer
from serl_launcher.utils.train_utils import concat_batches
from serl_launcher.vision.data_augmentations import batched_random_crop
from serl_launcher.networks.reward_classifier import create_classifier

from experiments.mappings import CONFIG_MAPPING

# 命令行输入
FLAGS = flags.FLAGS
flags.DEFINE_string("exp_name", "", "Name of experiment corresponding to folder.")
flags.DEFINE_integer("num_epochs", 200, "Number of training epochs.")
flags.DEFINE_integer("batch_size", 256, "Batch size.")
flags.DEFINE_string("checkpoint_path", None, "Path to save checkpoints.")
flags.DEFINE_float("val_ratio", 0.2, "Ratio of data held out as validation set.")
flags.DEFINE_integer("eval_every", 50, "Run validation every N epochs.")
flags.DEFINE_float("val_thresh", 0.5, "Probability threshold used when reporting val metrics.")

# 彩色打印函数
def print_red(text):
    print(f"\033[31m{text}\033[0m")

def print_green(text):
    print(f"\033[32m{text}\033[0m")

def print_yellow(text):
    print(f"\033[33m{text}\033[0m")

# 训练分类器
def main(_):
    # 检查是否存在对应的实验配置
    assert FLAGS.exp_name in CONFIG_MAPPING, 'Experiment folder not found.'
    # 创建env
    config = CONFIG_MAPPING[FLAGS.exp_name]()
    env = config.get_environment(fake_env=True, save_video=False, classifier=False)
    print_green(f"Observation Space: {env.observation_space}")

    # 检测本地GPU并设置分片策略
    devices = jax.local_devices()
    print_green(f"Devices: {devices}")
    sharding = jax.sharding.PositionalSharding(devices)
    print(f"Sharding: {sharding}")
    
    # 分类器训练数据路径
    floder_abs_path = os.path.join(os.getcwd(), "classifier_data", FLAGS.checkpoint_path)
    print("<<< classifier_data_path = " + floder_abs_path)

    def load_trans(pattern, label):
        """读取某一类样本的全部 transition（不做切分，后面统一划分训练/验证）"""
        out = []
        for path in sorted(glob.glob(os.path.join(floder_abs_path, pattern))):
            try:
                data = pkl.load(open(path, "rb"))
            except Exception as e:
                print(f"[skip] {os.path.basename(path)}: {e}")
                continue
            for trans in data:
                if "images" in trans['observations'].keys():
                    continue
                trans["labels"] = label
                trans['actions'] = env.action_space.sample()
                out.append(trans)
        return out

    def make_buffer(items):
        buf = ReplayBuffer(
            env.observation_space,
            env.action_space,
            capacity=max(len(items), 1) + 1,
            include_label=True,
        )
        for t in items:
            buf.insert(t)
        return buf

    pos_all = load_trans("*success*.pkl", 1)
    neg_all = load_trans("*failure*.pkl", 0)
    _rng = np.random.default_rng(0)
    _rng.shuffle(pos_all)
    _rng.shuffle(neg_all)

    # ---- 划分独立验证集：只有它才能反映"实机会不会误判"，训练集指标会自我欺骗 ----
    n_val_pos = max(1, int(len(pos_all) * FLAGS.val_ratio))
    n_val_neg = max(1, int(len(neg_all) * FLAGS.val_ratio))
    pos_buffer = make_buffer(pos_all[n_val_pos:])          # 训练集
    pos_val_buffer = make_buffer(pos_all[:n_val_pos])      # 验证集
    neg_buffer = make_buffer(neg_all[n_val_neg:])
    neg_val_buffer = make_buffer(neg_all[:n_val_neg])

    # 创建迭代器        
    pos_iterator = pos_buffer.get_iterator(
        sample_args={
            "batch_size": FLAGS.batch_size // 2,    # 批次采样大小为batch_size的一半，取整
        },
        device=sharding.replicate(),
    )
    neg_iterator = neg_buffer.get_iterator(
        sample_args={
            "batch_size": FLAGS.batch_size // 2,
        },
        device=sharding.replicate(),
    )

    print(f"train: pos={len(pos_buffer)} neg={len(neg_buffer)}")
    print(f"val  : pos={len(pos_val_buffer)} neg={len(neg_val_buffer)}  (val_ratio={FLAGS.val_ratio})")

    # 生成随机种子
    rng = jax.random.PRNGKey(0)
    rng, key = jax.random.split(rng)
    pos_sample = next(pos_iterator)
    neg_sample = next(neg_iterator)
    sample = concat_batches(pos_sample, neg_sample, axis=0) # 合并正负样本

    rng, key = jax.random.split(rng)
    classifier = create_classifier(key, sample["observations"], config.classifier_keys)

    # 数据增强
    def data_augmentation_fn(rng, observations):
        for pixel_key in config.classifier_keys:
            observations = observations.copy(
                add_or_replace={
                    pixel_key: batched_random_crop(
                        observations[pixel_key], rng, padding=4, num_batch_dims=2
                    )
                }
            )
        return observations

    @jax.jit
    def train_step(state, batch, key):
        # 定义损失函数
        def loss_fn(params):
            logits = state.apply_fn(
                {"params": params}, batch["observations"], rngs={"dropout": key}, train=True
            )
            return optax.sigmoid_binary_cross_entropy(logits, batch["labels"]).mean()

        # 计算损失、梯度
        grad_fn = jax.value_and_grad(loss_fn)
        loss, grads = grad_fn(state.params)
        logits = state.apply_fn(
            {"params": state.params}, batch["observations"], train=False, rngs={"dropout": key}
        )
        # 计算准确率
        train_accuracy = jnp.mean((nn.sigmoid(logits) >= 0.5) == batch["labels"])

        return state.apply_gradients(grads=grads), loss, train_accuracy

    def evaluate_val(epoch: int):
        """在【独立验证集】上评估：训练集指标会自我欺骗，只有这个能反映实机表现"""
        probs, labels = [], []
        for buf in (pos_val_buffer, neg_val_buffer):
            n = len(buf)
            if n == 0:
                continue
            bs = min(64, n)
            it = buf.get_iterator(sample_args={"batch_size": bs}, device=sharding.replicate())
            for _ in range(max(1, n // bs)):
                b = next(it)
                logits = np.asarray(classifier.apply_fn(
                    {"params": classifier.params}, b["observations"], train=False,
                    rngs={"dropout": jax.random.PRNGKey(0)})).reshape(-1)
                probs.extend(1.0 / (1.0 + np.exp(-logits)))
                labels.extend(np.asarray(b["labels"]).reshape(-1))
        probs = np.asarray(probs)
        labels = np.asarray(labels)
        if len(labels) == 0:
            return
        pos_mask = labels > 0.5
        pred = probs > FLAGS.val_thresh
        acc = float((pred == pos_mask).mean())
        recall = float(pred[pos_mask].mean()) if pos_mask.any() else float("nan")
        far = float(pred[~pos_mask].mean()) if (~pos_mask).any() else float("nan")
        print(f"[val @epoch {epoch}] acc={acc:.4f}  正样本召回={recall:.3f}  "
              f"负样本误报={far:.3f}  (thresh={FLAGS.val_thresh})", flush=True)

    for epoch in tqdm(range(FLAGS.num_epochs)):
        # 采集正负样本
        pos_sample = next(pos_iterator)
        neg_sample = next(neg_iterator)
        # 合并正负样本并创建标签
        batch = concat_batches(
            pos_sample, neg_sample, axis=0
        )

        # 数据增强        
        rng, key = jax.random.split(rng)
        obs = data_augmentation_fn(key, batch["observations"])
        batch = batch.copy(
            add_or_replace={
                "observations": obs,
                "labels": batch["labels"][..., None],
            }
        )

        # 训练分类器    
        rng, key = jax.random.split(rng)
        classifier, train_loss, train_accuracy = train_step(classifier, batch, key)

        print(
            f"Epoch: {epoch+1}, Train Loss: {train_loss:.4f}, Train Accuracy: {train_accuracy:.4f}"
        )
        if (epoch + 1) % FLAGS.eval_every == 0 or (epoch + 1) == FLAGS.num_epochs:
            evaluate_val(epoch + 1)

    # 保存分类器
    # overwrite=True：重训时直接覆盖同 step 的旧 checkpoint，
    # 否则 orbax 会抛 "Destination ... already exists."（旧 ckpt 已存在时必现）
    checkpoints.save_checkpoint(
        os.path.join(os.getcwd(), "classifier_ckpt/"),
        classifier,
        step=FLAGS.num_epochs,
        keep=100,  # 允许保存多个分类器
        overwrite=True,
    )
    

if __name__ == "__main__":
    app.run(main)