import copy
import os
import time
import signal
import faulthandler
from tqdm import tqdm
import numpy as np
import pickle as pkl
import datetime
from absl import app, flags
from pynput import keyboard

from experiments.mappings import CONFIG_MAPPING
# from experiments.rader_insert.config import TrainConfig
# from robot_servers import general_func as gfunc
from aubo_env.utils import general_func as gfunc

from aubo_env.camera.video_capture import VideoCaptureManager

""" 
采集任务成功与否的图像
v2版本，采用通用的VideoCaptureManager来管理环境调用的相机

"""

# 命令行输入
FLAGS = flags.FLAGS
flags.DEFINE_string("exp_name", "plug_assembly", "Name of experiment corresponding to folder.")
flags.DEFINE_integer("successes_needed", 500, "Number of successful transistions to collect.")
flags.DEFINE_integer("per_save_needed", 50, "Number of successful transistions to collect.")

# 按键标志初始化
success_key = False
break_key = False
done_key = False

# 声明保存路径
abs_save_floder = ""

# 检查保存路径是否存在，不存在则创建路径
def check_save_floder():
    global abs_save_floder
    uuid = datetime.datetime.now().strftime("%Y-%m-%d")
    abs_save_floder = os.path.join(os.getcwd(), "classifier_data", uuid) # 保存路径=当前路径 + classifier_data + 当前日期
    print(">>> classifier_data_path = " + abs_save_floder)
    if not os.path.exists(abs_save_floder):
        os.makedirs(abs_save_floder)

# 检测按键
def _dbg(msg):
    """[dbg][record] 采集进度日志：AUBO_DBG=1 时输出（run.sh 默认 0=关）"""
    if os.environ.get("AUBO_DBG", "1") == "1":
        print(msg, flush=True)

def on_press(key):
    global success_key
    global break_key
    global done_key
    try:
        if str(key) == 'Key.space':
            success_key = True
        elif str(key) == 'Key.esc':  # 退出程序 
            break_key = True
        elif str(key) == 'Key.f3':  # 结束当前回合
            done_key = True
            print(">>> done_key = True")
    except AttributeError:
        pass

def main(_):
    # [dbg] 取证：
    #   - enable(): SIGSEGV/SIGABRT 崩溃瞬间自动 dump 所有线程栈（C++ 层 abort 也能抓到 Python 侧位置）
    #   - 卡死(非崩溃)时：另一终端执行 kill -USR1 <pid> 手动 dump
    faulthandler.enable()
    faulthandler.register(signal.SIGUSR1)
    # 声明全局变量：按键标志、保存路径
    global success_key
    global break_key
    global done_key
    global abs_save_floder
    
    # 监听键盘事件
    listener = keyboard.Listener(
        on_press=on_press)
    listener.start()

    # 保存路径检查
    check_save_floder()

    # 检查是否存在对应的实验配置
    assert FLAGS.exp_name in CONFIG_MAPPING, 'Experiment folder not found.'
    
    # 创建env
    config = CONFIG_MAPPING[FLAGS.exp_name]()
    env = config.get_environment(fake_env=False, save_video=False, classifier=False)
    obs, _ = env.reset()

    # 样本采集准备
    successes_buffer = []
    failures_buffer = []
    success_needed = FLAGS.successes_needed
    pbar = tqdm(total=success_needed)
    success_cout = 0
    per_save_needed = FLAGS.per_save_needed


    """ 保存成功与失败转换数据：哪边有货存哪边，先记条数再清空 """
    def save_success_fail(success_count : int, note : str = ""):
        uuid = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")

        if len(successes_buffer) > 0:
            file_name = f"{abs_save_floder}/{success_count}_success_images_{uuid}.pkl"
            with open(file_name, "wb") as f:
                pkl.dump(successes_buffer, f)
            n = len(successes_buffer)
            successes_buffer.clear()
            gfunc.print_yellow(f"saved {n} successful transitions to {file_name} ({note})")

        if len(failures_buffer) > 0:
            file_name = f"{abs_save_floder}/failure_images_{uuid}.pkl"
            with open(file_name, "wb") as f:
                pkl.dump(failures_buffer, f)
            n = len(failures_buffer)
            failures_buffer.clear()
            gfunc.print_yellow(f"saved {n} failure transitions to {file_name} ({note})")


    """ 采集转换数据循环 """
    _loop_i = 0
    _loop_t0 = time.time()
    while len(successes_buffer) < success_needed:
        _loop_i += 1
        if _loop_i % 10 == 1 or time.time() - _loop_t0 > 2.0:
            _loop_t0 = time.time()
            _dbg(f"[dbg][record] i={_loop_i} ok={len(successes_buffer)} fail={len(failures_buffer)}")
        actions = np.zeros(env.action_space.sample().shape)         # 运动增量为0，若无人为干预，机械臂将静止
        _st = time.time()
        next_obs, rew, done, truncated, info = env.step(actions)    # 执行动作
        _dt = time.time() - _st
        if _dt > 0.5:
            _dbg(f"[dbg][record] i={_loop_i} env.step SLOW {_dt*1000:.0f}ms")
        if "intervene_action" in info:
            actions = info["intervene_action"]

        # 复制转换数据
        transition = copy.deepcopy(
            dict(
                observations=obs,
                actions=actions,
                next_observations=next_obs,
                rewards=rew,
                masks=1.0 - done,
                dones=done,
            )
        )
        obs = next_obs

        # 若成功按键被按下，则将转换数据加入成功转换数据列表，反之加入失败转换数据列表
        if success_key:
            success_cout += 1
            successes_buffer.append(transition)
            pbar.update(1)
        else:
            failures_buffer.append(transition)

        # 若回合自然结束或按下结束键，则重置环境
        if done or truncated or done_key:
            success_key = False  # 重置当前状态
            done_key = False  # 重置当前状态
            if success_cout >= per_save_needed:  # 成功样本攒满一段落盘
                save_success_fail(success_cout, "success-batch")
                success_cout = 0
            elif len(failures_buffer) >= 100:    # 失败样本攒满 100 落盘，防中途崩溃全丢
                save_success_fail(success_cout, "fail-batch")
                success_cout = 0
            obs, _ = env.reset()

        # 退出键被按下，则退出循环（退出前强制落盘剩余缓冲，Esc 退出不再丢数据）
        if break_key:
            if len(successes_buffer) > 0 or len(failures_buffer) > 0:
                save_success_fail(success_cout, "exit")
            break
        
if __name__ == "__main__":
    app.run(main)
