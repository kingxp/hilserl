#!/usr/bin/env python3

import glob
import threading
import time
import jax
import jax.numpy as jnp
import numpy as np
import tqdm
from absl import app, flags
from flax.training import checkpoints
import os
import copy
import pickle as pkl
from gymnasium.wrappers.record_episode_statistics import RecordEpisodeStatistics
from natsort import natsorted
from pynput import keyboard
import threading

from serl_launcher.agents.continuous.sac import SACAgent
from serl_launcher.agents.continuous.sac_hybrid_single import SACAgentHybridSingleArm
from serl_launcher.agents.continuous.sac_hybrid_dual import SACAgentHybridDualArm
from serl_launcher.utils.timer_utils import Timer
from serl_launcher.utils.train_utils import concat_batches

from agentlace.trainer import TrainerServer, TrainerClient
from agentlace.data.data_store import QueuedDataStore

from serl_launcher.utils.launcher import (
    make_sac_pixel_agent,
    make_sac_pixel_agent_hybrid_single_arm,
    make_sac_pixel_agent_hybrid_dual_arm,
    make_trainer_config,
    make_wandb_logger,
)
from serl_launcher.data.data_store import MemoryEfficientReplayBufferDataStore

from experiments.mappings import CONFIG_MAPPING

FLAGS = flags.FLAGS

flags.DEFINE_string("exp_name", None, "Name of experiment corresponding to folder.")
flags.DEFINE_integer("classifier_checkpoint_step", None, "Step to load the classifier checkpoint.")
flags.DEFINE_boolean("human_confirm", True, "回合被分类器判成功时等待人工复核：回车=采用，输入数字(如0)=覆盖reward")
flags.DEFINE_integer("neg_context", 10, "人工复核时给末尾多少帧打标记（供后续回收难例）")
flags.DEFINE_integer("seed", 42, "Random seed.")
flags.DEFINE_boolean("learner", False, "Whether this is a learner.")
flags.DEFINE_boolean("actor", False, "Whether this is an actor.")
flags.DEFINE_string("ip", "localhost", "IP address of the learner.")
# flags.DEFINE_multi_string("demo_path", " ", "Path to the demo data.")  # 多个demo文件的路径
flags.DEFINE_string("demo_path", " ", "Path to the demo data.")  # demo文件夹的路径
flags.DEFINE_string("agent_checkpoint_path", None, "Path to save agent checkpoints.")
flags.DEFINE_integer("agnet_checkpoint_step", 0, "Step to load the agent checkpoint for evaluate.")
flags.DEFINE_integer("eval_n_trajs", 0, "Number of trajectories to evaluate.")
flags.DEFINE_boolean("save_video", False, "Save video.")

flags.DEFINE_boolean(
    "debug", True, "Debug mode."
)  # debug mode will disable wandb logging

devices = jax.local_devices()
num_devices = len(devices)
sharding = jax.sharding.PositionalSharding(devices)


def print_green(x):
    return print("\033[92m {}\033[00m".format(x))


def latest_ckpt_step(path):
    """
    返回 (has_ckpt, step)。
    首次训练时目录可能已存在（actor 先建了 buffer/），但还没有 checkpoint_ 前缀的文件，
    此时 checkpoints.latest_checkpoint() 返回 None —— 原代码直接 os.path.basename(None) 会崩。
    """
    if not (path and os.path.exists(path)):
        return False, 0
    latest = checkpoints.latest_checkpoint(os.path.abspath(path))
    if latest is None:
        return False, 0
    try:
        return True, int(os.path.basename(latest)[11:])
    except (ValueError, TypeError):
        return False, 0


##############################################################################


def actor(agent, data_store, intvn_data_store, env, sampling_rng):
    """
    This is the actor loop, which runs when "--actor" is set to True.
    """

    """ 
    while evaluate the actor
    """
    if FLAGS.agnet_checkpoint_step:
        success_counter = 0
        time_list = []

        ckpt = checkpoints.restore_checkpoint(
            os.path.abspath(FLAGS.agent_checkpoint_path),
            agent.state,
            step=FLAGS.agnet_checkpoint_step,
        )
        agent = agent.replace(state=ckpt)

        # evaluate actor multi times
        print_green("staring actor evaluate loop")
        for episode in range(FLAGS.eval_n_trajs):
            obs, _ = env.reset()
            done = False
            start_time = time.time()
            # run the task
            while not done:
                sampling_rng, key = jax.random.split(sampling_rng)
                actions = agent.sample_actions(
                    observations=jax.device_put(obs),
                    argmax=True,                              # True:减少探索
                    seed=key
                )  # 基于当前观测值采样一个随机动作
                actions = np.asarray(jax.device_get(actions))  # 生成的动作从JAX设备内存中取出，并转换为NumPy数组，便于后续处理。

                next_obs, reward, done, truncated, info = env.step(actions)
                obs = next_obs

                if done:
                    if reward:
                        dt = time.time() - start_time
                        time_list.append(dt)
                        print(dt)

                    success_counter += reward  # reward = 0 or 1
                    print(f"reward={reward}, success_counter={success_counter}/{episode + 1}")

        print(f"success rate: {success_counter / FLAGS.eval_n_trajs}")
        print(f"average time: {np.mean(time_list)}")
        return  # after done eval, return and exit

    """ 
    while train the actor 
    """
    # buffer 目录可能已存在但还没有落盘的 pkl（< buffer_period 步）——此时从 0 开始。
    # 另外：退出保存曾用"时间戳"命名(如 transitions_1788939103.pkl)，其数字远超 max_steps，
    # 会让 range(start_step, max_steps) 为空 -> actor 启动即结束（表现为"卡住不动"）。
    # 这里只认 < 1000000 的正常步数序号，时间戳文件自动被排除。
    _buf_pkls = glob.glob(os.path.join(FLAGS.agent_checkpoint_path or "", "buffer/*.pkl"))
    _seqs = [int(os.path.basename(p)[12:-4]) for p in _buf_pkls
             if os.path.basename(p)[12:-4].isdigit()]
    _seqs = [n for n in _seqs if n < 1_000_000]
    start_step = (max(_seqs) + 1) if _seqs else 0

    datastore_dict = {
        "actor_env": data_store,
        "actor_env_intvn": intvn_data_store,
    }

    # Function to update the agent with new params
    def update_params(params):
        nonlocal agent
        agent = agent.replace(state=agent.state.replace(params=params))

    # tcp client, connect to the learner, update actor params when recv
    client = TrainerClient(
        "actor_env",
        FLAGS.ip,
        make_trainer_config(),
        data_stores=datastore_dict,
        wait_for_server=True,
        timeout_ms=3000,
    )
    client.recv_network_callback(update_params)


    """ 
    training loop 
    """
    print_green("staring actor training loop")
    obs, _ = env.reset()
    done = False
    transitions = []
    demo_transitions = []
    episode_buf = []          # 本回合缓存（人工复核后再统一写入 buffer，便于修正 reward）
    rejected_count = 0        # 被人工否决（判为假成功）的回合数
    timer = Timer()
    running_return = 0.0
    already_intervened = False  # current intervention state
    intervention_count = 0
    intervention_steps = 0

    # ---- 键盘控制（actor 端）：空格=暂停/继续，F5=人工判定成功，Esc=优雅退出并保存数据 ----
    ctrl = {"paused": False, "exit": False, "mark_success": False, "confirm": None,
            "waiting_confirm": False, "exit_pending": False}

    def _on_press(key):
        try:
            if str(key) == 'Key.space':
                ctrl["paused"] = not ctrl["paused"]
                state = "暂停（机械臂保持当前位姿，不再下发新目标）" if ctrl["paused"] else "继续"
                print(f"\n>>> [space] {state}", flush=True)
            elif str(key) == 'Key.f5':
                ctrl["mark_success"] = True
                print("\n>>> [F5] 已记录「人工判定成功」，本回合将按成功结束", flush=True)
            elif str(key) == 'Key.esc':
                if ctrl["waiting_confirm"]:
                    # 正在等人工复核：不打断，但【记下退出请求】——复核一完成就自动保存退出
                    ctrl["exit_pending"] = True
                    print("\n>>> [esc] 当前正在等待人工复核：已记下退出请求，"
                          "完成本次复核后会自动保存并退出（无需再按 Esc）", flush=True)
                else:
                    ctrl["exit"] = True
                    print("\n>>> [esc] 正在退出，将先保存已采集数据", flush=True)
                    # 兜底：主循环若卡在阻塞调用（learner 断开、异常后主线程已死等），
                    # 正常保存退出走 os._exit(0) 会更快；10 秒没退就强制结束，保证 Esc 永远有效
                    if not ctrl.get("_force_started"):
                        ctrl["_force_started"] = True

                        def _force_exit():
                            time.sleep(10.0)
                            import sys as _s
                            _s.stdout.flush()
                            print("\n>>> [esc] 主循环 10 秒未响应，强制退出（未保存的数据将丢失）",
                                  flush=True)
                            os._exit(1)

                        threading.Thread(target=_force_exit, daemon=True).start()
            elif str(key) == 'Key.enter':
                ctrl["confirm"] = "accept"      # 人工复核：回车=采用分类器判定
            elif getattr(key, "char", None) in ("0", "1"):
                ctrl["confirm"] = float(key.char)   # 人工复核：0=否决，1=采用
        except AttributeError:
            pass

    kb_listener = keyboard.Listener(on_press=_on_press)
    kb_listener.daemon = True
    kb_listener.start()
    print_green("actor 控制: [space] 暂停/继续   [F5] 人工判定成功(分类器漏检时用)   "
                "[esc] 保存并退出   3D鼠标=接管干预")

    step = start_step   # for 未执行（range 为空）时，退出保存段仍能引用 step
    pbar = tqdm.tqdm(range(start_step, config.max_steps), dynamic_ncols=True)
    for step in pbar:
        # 退出：跳出循环，后面会把剩余数据落盘
        if ctrl["exit"]:
            print_green("收到退出信号，保存数据后结束 actor")
            break
        # 暂停：不采样也不 step，机械臂停在最后目标位姿（伺服保持），安全
        if ctrl["paused"]:
            time.sleep(0.1)
            continue

        timer.tick("total")

        with timer.context("sample_actions"):
            # random actions or samlpe according to the observation
            if step < config.random_steps:
                actions = env.action_space.sample()
            else:
                sampling_rng, key = jax.random.split(sampling_rng)
                actions = agent.sample_actions(
                    observations=jax.device_put(obs),
                    seed=key,
                    argmax=False,
                )
                actions = np.asarray(jax.device_get(actions))

        # Step environment
        with timer.context("step_env"):

            next_obs, reward, done, truncated, info = env.step(actions)
            running_return += reward

            if "left" in info:
                info.pop("left")
            if "right" in info:
                info.pop("right")

            # override the action with the intervention action
            if "intervene_action" in info:
                actions = info.pop("intervene_action")
                intervention_steps += 1
                if not already_intervened:  # count while agent -> intervene
                    intervention_count += 1
                already_intervened = True
            else:
                already_intervened = False

            # ognize the transition data
            transition = dict(
                observations=obs,
                actions=actions,
                next_observations=next_obs,
                rewards=reward,
                masks=1.0 - done,
                dones=done,
            )
            if 'grasp_penalty' in info:
                transition['grasp_penalty'] = info['grasp_penalty']

            if FLAGS.human_confirm:
                # 延迟到回合结束再入 buffer：人工否决时能把这一整段的 reward 改成 0，
                # 否则"假成功"会以 reward=1 写进 replay buffer，还会进 demo buffer 当专家数据
                episode_buf.append((transition, already_intervened))
            else:
                data_store.insert(transition)
                transitions.append(copy.deepcopy(transition))
                if already_intervened:
                    intvn_data_store.insert(transition)
                    demo_transitions.append(copy.deepcopy(transition))

            obs = next_obs

            # ---- F5：人工判定成功 ----
            # 分类器漏检时（人已经接管并把瓶子抓起来了，但它没给 reward），手动标记成功：
            # 本回合按成功结束，reward=1，干预数据进入 demo buffer 当专家示范
            manual_ok = False
            if ctrl["mark_success"]:
                ctrl["mark_success"] = False
                manual_ok = True
                info["succeed"] = True
                reward = 1.0
                done = True
                if episode_buf:
                    episode_buf[-1][0]["rewards"] = 1.0     # 稀疏奖励落在终止帧
                    episode_buf[-1][0]["dones"] = True
                print_green(">>> [F5] 人工判定成功：本回合按成功结束，干预数据将进入 demo buffer")

            if done or truncated:
                # ---- 人工复核：分类器判成功时不直接采信（F5 已人工确认则不再询问）----
                auto_success = bool(info.get("succeed", False))
                final_reward = reward
                if FLAGS.human_confirm and auto_success and not manual_ok:
                    # 非阻塞等待键盘（用 pynput 而不是 input()）：
                    # input() 会卡死线程，导致 Esc 退出在等待期间完全失效
                    ctrl["confirm"] = None
                    ctrl["waiting_confirm"] = True
                    print(f"\n[人工复核] 分类器判定本回合成功(reward={reward})。"
                          f"回车/1=采用   0=否决(假成功)", flush=True)
                    print("    （等待输入中：此期间 Esc 不会退出，请先完成本次复核）", flush=True)
                    while ctrl["confirm"] is None:      # Esc 不打断，必须先完成复核
                        time.sleep(0.05)     # 等待期间不 step，机械臂靠伺服保持原位
                    ctrl["waiting_confirm"] = False
                    if ctrl["exit_pending"]:      # 等待期间按过 Esc：复核一完成就自动退出
                        ctrl["exit"] = True
                        print_green("复核完成，执行此前记下的退出请求")
                    if ctrl["confirm"] is not None and ctrl["confirm"] != "accept":
                        final_reward = float(ctrl["confirm"])
                    if not final_reward:
                        rejected_count += 1
                        print(f"  -> 判为假成功（累计否决 {rejected_count} 条）")

                # ---- 把本回合数据写入 buffer（否决时整段 reward 置 0）----
                if FLAGS.human_confirm and episode_buf:
                    n_tail = min(FLAGS.neg_context, len(episode_buf))
                    for j, (t, _is_intv) in enumerate(episode_buf):
                        if not final_reward:
                            t["rewards"] = 0.0
                        # 末尾若干帧打上复核标记，供后续回收难例（transition 默认无 infos，这里补一个）
                        if j >= len(episode_buf) - n_tail:
                            if not isinstance(t.get("infos", None), dict):
                                t["infos"] = {}
                            t["infos"]["classifier_succeed"] = bool(auto_success)
                            t["infos"]["human_reward"] = final_reward
                            t["infos"]["human_modified"] = bool(final_reward != reward)
                            t["infos"]["step_in_episode"] = j
                        data_store.insert(t)
                        transitions.append(copy.deepcopy(t))
                    if final_reward:   # 只有人工确认成功，干预数据才进 demo buffer（专家数据）
                        for t, is_intv in episode_buf:
                            if is_intv:
                                intvn_data_store.insert(t)
                                demo_transitions.append(copy.deepcopy(t))
                    episode_buf = []
                    if not final_reward:
                        info["succeed"] = False

                # F5/部分路径手动把 done 置 True，没经过 env.step -> RecordEpisodeStatistics
                # 不会往 info 里写 episode 键（它只在 env.step 内部检测到 done 时才写），这里兜底补一个
                if not isinstance(info.get("episode"), dict):
                    info["episode"] = {"r": running_return, "l": 0, "t": 0.0}
                info["episode"]["intervention_count"] = intervention_count
                info["episode"]["intervention_steps"] = intervention_steps
                stats = {"environment": info}  # send stats to the learner to log
                client.request("send-stats", stats)
                pbar.set_description(f"last return: {running_return}")
                running_return = 0.0
                intervention_count = 0
                intervention_steps = 0
                already_intervened = False
                client.update()
                obs, _ = env.reset()

            if info.get('exit') or ctrl["exit"]:   # F3(环境层) 或 Esc(本文件监听) 都能触发退出
                print_green('Exit.')
                break

        # save the transitions data (in segments)
        if step > 0 and config.buffer_period > 0 and step % config.buffer_period == 0:
            # dump to pickle file
            buffer_path = os.path.join(FLAGS.agent_checkpoint_path, "buffer")
            demo_buffer_path = os.path.join(FLAGS.agent_checkpoint_path, "demo_buffer")
            if not os.path.exists(buffer_path):
                os.makedirs(buffer_path)
            if not os.path.exists(demo_buffer_path):
                os.makedirs(demo_buffer_path)
            with open(os.path.join(buffer_path, f"transitions_{step}.pkl"), "wb") as f:
                pkl.dump(transitions, f)
                transitions = []
            with open(
                    os.path.join(demo_buffer_path, f"transitions_{step}.pkl"), "wb") as f:
                pkl.dump(demo_transitions, f)
                demo_transitions = []

        timer.tock("total")

        if step % config.log_period == 0:
            stats = {"timer": timer.get_average_times()}
            client.request("send-stats", stats)

    # ---- 未复核的本回合数据：只落本地 pkl，不发给 learner（reward 未经确认）----
    if episode_buf:
        for t, _ in episode_buf:
            transitions.append(copy.deepcopy(t))
        print_green(f"本回合有 {len(episode_buf)} 条未经人工复核，已随本地 buffer 保存（未发送给 learner）")
        episode_buf = []

    # ---- 正常结束或 Esc 退出前，把剩余数据落盘（否则最多白采 buffer_period 步）----
    if rejected_count:
        print_green(f"本次共人工否决 {rejected_count} 个回合（分类器假成功）")
    if FLAGS.agent_checkpoint_path and (transitions or demo_transitions):
        buffer_path = os.path.join(FLAGS.agent_checkpoint_path, "buffer")
        demo_buffer_path = os.path.join(FLAGS.agent_checkpoint_path, "demo_buffer")
        os.makedirs(buffer_path, exist_ok=True)
        os.makedirs(demo_buffer_path, exist_ok=True)
        # 用当前 step 序号命名（不能用时间戳！actor 启动时会按序号续传，
        # 时间戳数字 > max_steps 会让 for 循环为空、actor 启动即结束）
        seq = step
        if transitions:
            with open(os.path.join(buffer_path, f"transitions_{seq}.pkl"), "wb") as f:
                pkl.dump(transitions, f)
        if demo_transitions:
            with open(os.path.join(demo_buffer_path, f"transitions_{seq}.pkl"), "wb") as f:
                pkl.dump(demo_transitions, f)
        print_green(f"退出保存: {len(transitions)} 条经验 / {len(demo_transitions)} 条干预数据 -> {buffer_path}")

    # Esc 退出时强制结束进程：agentlace / 相机等线程可能非 daemon，会让进程在保存后仍挂着不退
    if ctrl["exit"]:
        import sys
        print_green("保存完成，退出 actor 进程")
        sys.stdout.flush()
        sys.stderr.flush()
        os._exit(0)


##############################################################################


def learner(rng, agent, replay_buffer, demo_buffer, wandb_logger=None):
    """
    The learner loop, which runs when "--learner" is set to True.
    """
    _has_ckpt, _ckpt_step = latest_ckpt_step(FLAGS.agent_checkpoint_path)
    start_step = _ckpt_step + 1 if _has_ckpt else 0
    step = start_step

    def stats_callback(type: str, payload: dict) -> dict:
        """Callback for when server receives stats request."""
        assert type == "send-stats", f"Invalid request type: {type}"
        if wandb_logger is not None:
            wandb_logger.log(payload, step=step)
        return {}  # not expecting a response

    # Create server
    server = TrainerServer(make_trainer_config(), request_callback=stats_callback)
    server.register_data_store("actor_env", replay_buffer)
    server.register_data_store("actor_env_intvn", demo_buffer)
    server.start(threaded=True)

    # ---- learner 端键盘控制：Esc = 保存 checkpoint 后退出 ----
    # 必须放在"填 buffer"之前：否则等 actor 数据期间 Esc 无监听，learner 会一直卡死
    lrn_ctrl = {"exit": False, "_force_started": False}

    def _lrn_on_press(key):
        try:
            if str(key) == 'Key.esc':
                lrn_ctrl["exit"] = True
                print("\n>>> [esc] learner 正在保存 checkpoint 并退出", flush=True)
                # 兜底：主循环若卡住（如等不到 actor），10 秒后强制结束，保证 Esc 永远有效
                if not lrn_ctrl["_force_started"]:
                    lrn_ctrl["_force_started"] = True

                    def _force_exit():
                        time.sleep(10.0)
                        import sys as _s
                        _s.stdout.flush()
                        print("\n>>> [esc] learner 主循环 10 秒未响应，强制退出", flush=True)
                        os._exit(1)

                    threading.Thread(target=_force_exit, daemon=True).start()
        except AttributeError:
            pass

    lrn_listener = keyboard.Listener(on_press=_lrn_on_press)
    lrn_listener.daemon = True
    lrn_listener.start()
    print_green("learner 控制: [esc] 保存 checkpoint 并退出")

    # Loop to wait until replay_buffer is filled
    pbar = tqdm.tqdm(
        total=config.training_starts,
        initial=len(replay_buffer),
        desc="Filling up replay buffer",
        position=0,
        leave=True,
    )
    while len(replay_buffer) < config.training_starts:
        if lrn_ctrl["exit"]:      # 填 buffer 等待期间也要响应 Esc（否则等不到 actor 就一直卡死）
            print_green("退出等待（replay buffer 未填满），保存 checkpoint 后结束 learner")
            break
        pbar.update(len(replay_buffer) - pbar.n)  # Update progress bar
        time.sleep(1)
    pbar.update(len(replay_buffer) - pbar.n)  # Update progress bar
    pbar.close()

    # send the initial network to the actor
    server.publish_network(agent.state.params)
    print_green("sent initial network to actor")

    # 50/50 sampling from RLPD, half from demo and half from online experience
    replay_iterator = replay_buffer.get_iterator(
        sample_args={
            "batch_size": config.batch_size // 2,
            "pack_obs_and_next_obs": True,
        },
        device=sharding.replicate(),
    )
    demo_iterator = demo_buffer.get_iterator(
        sample_args={
            "batch_size": config.batch_size // 2,
            "pack_obs_and_next_obs": True,
        },
        device=sharding.replicate(),
    )

    # wait till the replay buffer is filled with enough data
    timer = Timer()

    # gripper agent enable or not
    if isinstance(agent, SACAgent):
        train_critic_networks_to_update = frozenset({"critic"})
        train_networks_to_update = frozenset({"critic", "actor", "temperature"})
    else:
        train_critic_networks_to_update = frozenset({"critic", "grasp_critic"})
        train_networks_to_update = frozenset({"critic", "grasp_critic", "actor", "temperature"})

    for step in tqdm.tqdm(
            range(start_step, config.max_steps), dynamic_ncols=True, desc="learner"
    ):
        if lrn_ctrl["exit"]:
            print_green("收到退出信号，保存 checkpoint 后结束 learner")
            break

        # run n-1 critic updates and 1 critic + actor update.
        # This makes training on GPU faster by reducing the large batch transfer time from CPU to GPU
        for critic_step in range(config.cta_ratio - 1):
            with timer.context("sample_replay_buffer"):
                batch = next(replay_iterator)
                demo_batch = next(demo_iterator)
                batch = concat_batches(batch, demo_batch, axis=0)

            with timer.context("train_critics"):
                agent, critics_info = agent.update(
                    batch,
                    networks_to_update=train_critic_networks_to_update,
                )

        with timer.context("train"):
            batch = next(replay_iterator)
            demo_batch = next(demo_iterator)
            batch = concat_batches(batch, demo_batch, axis=0)
            # print("contact batch")
            agent, update_info = agent.update(
                batch,
                networks_to_update=train_networks_to_update,
            )

        # publish the updated network
        if step > 0 and step % (config.steps_per_update) == 0:
            agent = jax.block_until_ready(agent)
            server.publish_network(agent.state.params)

        if step % config.log_period == 0 and wandb_logger:
            wandb_logger.log(update_info, step=step)
            wandb_logger.log({"timer": timer.get_average_times()}, step=step)

        if (
            step > 0
            and config.checkpoint_period
            and step % config.checkpoint_period == 0
        ):
            checkpoints.save_checkpoint(
                os.path.abspath(FLAGS.agent_checkpoint_path), agent.state, step=step, keep=100
            )

    # ---- 退出/结束时保存一次 checkpoint，避免白训最多 checkpoint_period 步 ----
    if FLAGS.agent_checkpoint_path:
        checkpoints.save_checkpoint(
            os.path.abspath(FLAGS.agent_checkpoint_path), agent.state, step=step,
            keep=100, overwrite=True,
        )
        print_green(f"已保存 checkpoint @ step {step}")
    if lrn_ctrl["exit"]:
        import sys
        print_green("退出 learner 进程")
        sys.stdout.flush()
        sys.stderr.flush()
        os._exit(0)


##############################################################################


def main(_):
    global config
    config = CONFIG_MAPPING[FLAGS.exp_name]()

    assert config.batch_size % num_devices == 0
    # seed
    rng = jax.random.PRNGKey(FLAGS.seed)
    rng, sampling_rng = jax.random.split(rng)

    """ load env & classifier """
    assert FLAGS.exp_name in CONFIG_MAPPING, "Experiment folder not found."
    env = config.get_environment(
        fake_env=FLAGS.learner,
        save_video=FLAGS.save_video,
        classifier=True,
        classifier_checkpoint_step=FLAGS.classifier_checkpoint_step
    )
    env = RecordEpisodeStatistics(env)

    rng, sampling_rng = jax.random.split(rng)

    # create agent according to the arm num and gripper enable or not
    if config.setup_mode == 'single-arm-fixed-gripper' or config.setup_mode == 'dual-arm-fixed-gripper':
        agent: SACAgent = make_sac_pixel_agent(
            seed=FLAGS.seed,
            sample_obs=env.observation_space.sample(),
            sample_action=env.action_space.sample(),
            image_keys=config.image_keys,
            encoder_type=config.encoder_type,
            discount=config.discount,
        )
        include_grasp_penalty = False
    elif config.setup_mode == 'single-arm-learned-gripper':
        agent: SACAgentHybridSingleArm = make_sac_pixel_agent_hybrid_single_arm(
            seed=FLAGS.seed,
            sample_obs=env.observation_space.sample(),
            sample_action=env.action_space.sample(),
            image_keys=config.image_keys,
            encoder_type=config.encoder_type,
            discount=config.discount,
        )
        include_grasp_penalty = True
    elif config.setup_mode == 'dual-arm-learned-gripper':
        agent: SACAgentHybridDualArm = make_sac_pixel_agent_hybrid_dual_arm(
            seed=FLAGS.seed,
            sample_obs=env.observation_space.sample(),
            sample_action=env.action_space.sample(),
            image_keys=config.image_keys,
            encoder_type=config.encoder_type,
            discount=config.discount,
        )
        include_grasp_penalty = True
    else:
        raise NotImplementedError(f"Unknown setup mode: {config.setup_mode}")

    # replicate agent across devices
    # need the jnp.array to avoid a bug where device_put doesn't recognize primitives
    agent = jax.device_put( jax.tree_util.tree_map(jnp.array, agent), sharding.replicate() )

    # load the latest (agent) checkpoint
    has_ckpt, ckpt_number = latest_ckpt_step(FLAGS.agent_checkpoint_path)
    if has_ckpt:
        # input("Checkpoint path already exists. Press Enter to resume training.")
        ckpt = checkpoints.restore_checkpoint(
            os.path.abspath(FLAGS.agent_checkpoint_path),
            agent.state,
        )
        agent = agent.replace(state=ckpt)
        print_green(f"Loaded previous checkpoint at step {ckpt_number}.")
    else:
        print_green("未找到已有 checkpoint：从 step 0 开始全新训练")

    def create_replay_buffer_and_wandb_logger():
        replay_buffer = MemoryEfficientReplayBufferDataStore(
            env.observation_space,
            env.action_space,
            capacity=config.replay_buffer_capacity,
            image_keys=config.image_keys,
            include_grasp_penalty=include_grasp_penalty,
        )
        # set up wandb and logging
        wandb_logger = make_wandb_logger(
            project="hil-serl",
            description=FLAGS.exp_name,
            debug=FLAGS.debug,
        )
        return replay_buffer, wandb_logger

    if FLAGS.learner:
        sampling_rng = jax.device_put(sampling_rng, device=sharding.replicate())
        replay_buffer, wandb_logger = create_replay_buffer_and_wandb_logger()
        demo_buffer = MemoryEfficientReplayBufferDataStore(
            env.observation_space,
            env.action_space,
            capacity=config.replay_buffer_capacity,
            image_keys=config.image_keys,
            include_grasp_penalty=include_grasp_penalty,
        )

        # load all demo data
        assert FLAGS.demo_path is not None
        # for path in FLAGS.demo_path:
        for file in glob.glob(os.path.join(FLAGS.demo_path, "*.pkl")):
            with open(file, "rb") as f:
                transitions = pkl.load(f)
                for transition in transitions:
                    if 'infos' in transition and 'grasp_penalty' in transition['infos']:
                        transition['grasp_penalty'] = transition['infos']['grasp_penalty']
                    demo_buffer.insert(transition)
        print_green(f"demos buffer size: {len(demo_buffer)}")

        # load previous (demo)buffer data
        if FLAGS.agent_checkpoint_path is not None and os.path.exists(
                os.path.join(FLAGS.agent_checkpoint_path, "buffer")
        ):
            for file in glob.glob(os.path.join(FLAGS.agent_checkpoint_path, "buffer/*.pkl")):
                with open(file, "rb") as f:
                    transitions = pkl.load(f)
                    for transition in transitions:
                        replay_buffer.insert(transition)
            print_green(
                f"Loaded previous buffer data. Replay buffer size: {len(replay_buffer)}"
            )
        if FLAGS.agent_checkpoint_path is not None and os.path.exists(
                os.path.join(FLAGS.agent_checkpoint_path, "demo_buffer")
        ):
            for file in glob.glob(
                    os.path.join(FLAGS.agent_checkpoint_path, "demo_buffer/*.pkl")
            ):
                with open(file, "rb") as f:
                    transitions = pkl.load(f)
                    for transition in transitions:
                        demo_buffer.insert(transition)
            print_green(
                f"Loaded previous demo buffer data. Demo buffer size: {len(demo_buffer)}"
            )

        # learner loop
        print_green("starting learner")
        learner(
            sampling_rng,
            agent,
            replay_buffer,
            demo_buffer=demo_buffer,
            wandb_logger=wandb_logger,
        )

    elif FLAGS.actor:
        sampling_rng = jax.device_put(sampling_rng, sharding.replicate())
        data_store = QueuedDataStore(50000)  # the queue size on the actor
        intvn_data_store = QueuedDataStore(50000)

        # actor loop
        print_green("starting actor")
        actor(
            agent,
            data_store,
            intvn_data_store,
            env,
            sampling_rng,
        )

    else:
        raise NotImplementedError("Must be either a learner or an actor")


if __name__ == "__main__":
    app.run(main)
