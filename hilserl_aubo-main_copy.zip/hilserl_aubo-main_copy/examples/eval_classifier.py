"""
eval_classifier.py —— 离线评估奖励分类器（纯诊断，不改动训练逻辑）

【它回答什么】
训练日志里的 Train Accuracy 只反映"训练批次上的表现"，不能说明实机会不会误判。
这个脚本直接把训练好的分类器拿去给采集数据打分，输出：
  1) 正样本（成功）命中率 = 召回；负样本（失败）误报率；
  2) 概率分布直方图（看模型是"两极分化"还是"全都往一边倒"）；
  3) AUC（整体区分能力，0.5=随机猜，1.0=完美）；
  4) 逐文件统计（哪个 pkl 的标签最可疑，用来定位误触/污染）；
  5) 把典型误判帧（负样本被判成功 / 正样本被判失败）拼成 png 供人工核查。

【用法】
    # 在容器内执行（需要 PYTHONPATH 含 examples 与 serl_robot_infra）
    python3 eval_classifier.py --exp_name=grasp_testing --date=2026-09-08 --ckpt_step=200

【判读】
    - 负样本误报率高   -> 分类器太"乐观"，会把没抓起/复位画面判成功（最常见，危害最大）
    - 正样本命中率低   -> 分类器太保守，真成功也不给奖励，RL 学不到东西
    - AUC 接近 0.5     -> 基本没学到，优先怀疑标签噪声（正样本里混了假成功）
    - 训练集指标很好但实机差 -> 分布偏移/标签噪声，需要补难例而不是加普通数据
"""

import glob
import os
import pickle

import cv2
import jax
import numpy as np
from absl import app, flags

FLAGS = flags.FLAGS
flags.DEFINE_string("exp_name", "grasp_testing", "实验名")
flags.DEFINE_string("date", "", "数据日期目录名，默认今天")
flags.DEFINE_integer("ckpt_step", 200, "分类器 checkpoint 步数")
flags.DEFINE_string("ckpt_path", "", "分类器目录，默认 <cwd>/classifier_ckpt")
flags.DEFINE_float("thresh", 0.85, "判定成功的概率阈值（与 config.CLASSIFIER_THRESHOLD 一致）")
flags.DEFINE_integer("batch", 64, "推理批大小")
flags.DEFINE_integer("max_dump", 16, "每类误判最多拼多少张")
flags.DEFINE_string("out_dir", "", "误判图输出目录，默认 <实验目录>/classifier_preview/eval")


def load_items(pattern, label):
    """读取 pkl，返回 (obs_list, label)。obs 结构保持训练/推理一致：camera1 (1,128,128,3)"""
    xs, ys = [], []
    for f in sorted(glob.glob(pattern)):
        try:
            data = pickle.load(open(f, "rb"))
        except Exception as e:
            print(f"[skip] {os.path.basename(f)}: {e}")
            continue
        for t in data:
            obs = t.get("observations", {})
            img = obs.get("camera1", None)
            if img is None:
                continue
            img = np.asarray(img)
            if img.ndim == 3:                 # (128,128,3) -> (1,128,128,3)
                img = img[None]
            st = np.asarray(obs.get("state", np.zeros((1, 1), dtype=np.float32)))
            if st.ndim == 1:
                st = st[None]
            xs.append({"camera1": img, "state": st})
            ys.append(label)
    return xs, ys


def batched_apply(classifier, items, keys=("camera1",)):
    """分批推理，返回 sigmoid 概率数组"""
    probs = []
    for i in range(0, len(items), FLAGS.batch):
        chunk = items[i:i + FLAGS.batch]
        batch = {k: np.stack([c[k] for c in chunk], axis=0) for k in chunk[0].keys()}
        logits = classifier(batch)
        logits = np.asarray(logits).reshape(-1)
        probs.extend(1.0 / (1.0 + np.exp(-logits)))
    return np.asarray(probs)


def auc(scores, labels):
    """rank-based AUC（含 ties 平均秩）"""
    s = np.asarray(scores)
    y = np.asarray(labels)
    n_pos = int((y == 1).sum())
    n_neg = int((y == 0).sum())
    if n_pos == 0 or n_neg == 0:
        return float("nan")
    order = np.argsort(s)
    ranks = np.empty(len(s), dtype=float)
    sorted_s = s[order]
    i = 0
    while i < len(s):
        j = i
        while j + 1 < len(s) and sorted_s[j + 1] == sorted_s[i]:
            j += 1
        ranks[order[i:j + 1]] = (i + j) / 2.0 + 1.0
        i = j + 1
    return float((ranks[y == 1].sum() - n_pos * (n_pos + 1) / 2.0) / (n_pos * n_neg))


def hist(p, name):
    bins = [0, 0.1, 0.5, 0.85, 0.95, 1.0001]
    labels = ["<0.1", "0.1-0.5", "0.5-0.85", "0.85-0.95", ">0.95"]
    cnt, _ = np.histogram(p, bins=bins)
    total = max(len(p), 1)
    print(f"  [{name}] 概率分布: " + "  ".join(f"{l}={c}({100*c/total:.0f}%)" for l, c in zip(labels, cnt)))


def dump_grid(items, scores, name, want_high, out_dir, thr):
    """拼误判帧：want_high=True 抓被判成功的（误报）；False 抓被判失败的（漏检）"""
    idx = [i for i, s in enumerate(scores) if ((s > thr) if want_high else (s < thr))]
    # 均匀抽样，避免全是相邻重复帧
    if len(idx) > FLAGS.max_dump:
        sel = np.linspace(0, len(idx) - 1, FLAGS.max_dump).astype(int)
        idx = [idx[k] for k in sel]
    if not idx:
        print(f"  {name}: 无样本")
        return
    imgs = []
    for i in idx:
        img = items[i]["camera1"]
        img = np.asarray(img).squeeze()
        img = cv2.resize(img, (128, 128))
        cv2.putText(img, f"p={scores[i]:.2f}", (2, 122), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 0, 255), 1)
        imgs.append(img)
    cols = 8
    rows = [np.hstack(imgs[r * cols:(r + 1) * cols] + [np.zeros_like(imgs[0])] * (cols - len(imgs[r * cols:(r + 1) * cols])))
            for r in range((len(imgs) + cols - 1) // cols)]
    canvas = np.vstack(rows)
    path = os.path.join(out_dir, name)
    cv2.imwrite(path, canvas[..., ::-1])
    print(f"  wrote {path}  ({len(imgs)} 帧)")


def main(_):
    import datetime
    date = FLAGS.date or datetime.datetime.now().strftime("%Y-%m-%d")

    from experiments.mappings import CONFIG_MAPPING
    from serl_launcher.networks.reward_classifier import load_classifier_func

    assert FLAGS.exp_name in CONFIG_MAPPING, "exp_name 不在 CONFIG_MAPPING 里"
    config = CONFIG_MAPPING[FLAGS.exp_name]()
    env = config.get_environment(fake_env=True, save_video=False, classifier=False)

    ckpt_path = FLAGS.ckpt_path or os.path.abspath("classifier_ckpt/")
    print(f"== 加载分类器 {ckpt_path}/checkpoint_{FLAGS.ckpt_step}")
    classifier = load_classifier_func(
        key=jax.random.PRNGKey(0),
        sample=env.observation_space.sample(),
        image_keys=config.classifier_keys,
        checkpoint_path=ckpt_path,
        checkpoint_step=FLAGS.ckpt_step,
    )

    base = os.path.join(os.getcwd(), "classifier_data", date)
    print(f"== 数据目录 {base}")
    pos_x, pos_y = load_items(os.path.join(base, "*success*.pkl"), 1)
    neg_x, neg_y = load_items(os.path.join(base, "*failure*.pkl"), 0)
    print(f"== 正样本 {len(pos_x)} 帧 / 负样本 {len(neg_x)} 帧")
    if not pos_x or not neg_x:
        print("[error] 正或负样本为空，无法评估")
        return

    p_pos = batched_apply(classifier, pos_x)
    p_neg = batched_apply(classifier, neg_x)
    thr = FLAGS.thresh

    hit = float((p_pos > thr).mean())
    far = float((p_neg > thr).mean())
    print("\n===== 结果（注意：这是【训练集回顾】，不是独立验证集）=====")
    print(f"  正样本命中率(召回) = {100*hit:.1f}%   平均 p={p_pos.mean():.3f}  中位 p={np.median(p_pos):.3f}")
    print(f"  负样本误报率       = {100*far:.1f}%   平均 p={p_neg.mean():.3f}  中位 p={np.median(p_neg):.3f}")
    print(f"  AUC = {auc(np.concatenate([p_pos, p_neg]), np.concatenate([np.ones(len(p_pos)), np.zeros(len(p_neg))])):.3f}")
    print("\n===== 概率分布 =====")
    hist(p_pos, "正样本")
    hist(p_neg, "负样本")

    # 逐文件统计：定位"哪个 pkl 最可疑"
    print("\n===== 逐文件负样本误报率(top, 用来定位标签污染) =====")
    per = []
    off = 0
    for f in sorted(glob.glob(os.path.join(base, "*failure*.pkl"))):
        try:
            n = len(pickle.load(open(f, "rb")))
        except Exception:
            n = 0
        seg = p_neg[off:off + n]
        off += n
        if len(seg):
            per.append((os.path.basename(f), float((seg > thr).mean()), len(seg)))
    per.sort(key=lambda x: -x[1])
    for name, r, n in per[:10]:
        print(f"  {r*100:5.1f}%  ({n:4d} 帧)  {name}")

    out_dir = FLAGS.out_dir or os.path.join(os.getcwd(), "classifier_preview", "eval")
    os.makedirs(out_dir, exist_ok=True)
    print("\n===== 误判帧拼图 =====")
    dump_grid(neg_x, p_neg, "eval_false_positive.png", True, out_dir, thr)   # 负样本却被判成功
    dump_grid(pos_x, p_pos, "eval_false_negative.png", False, out_dir, thr)  # 正样本却没判成功
    print("\ndone.")


if __name__ == "__main__":
    app.run(main)
