"""临时诊断：把 classifier_data 的正负样本拼成缩略图 + 统计静止重复帧。用后即删。"""
import glob
import os
import pickle

import cv2
import numpy as np

BASE = "/root/hilserl/hilserl_aubo-main/examples/experiments/grasp_testing"
DATA = os.path.join(BASE, "classifier_data/2026-09-08")
OUT = os.path.join(BASE, "classifier_preview")
os.makedirs(OUT, exist_ok=True)


def is_static(a, b, thresh=5.0):
    """相邻两帧平均绝对差 < thresh 视为'几乎静止重复帧'"""
    if a is None or b is None:
        return False
    return float(np.mean(np.abs(a.astype(np.int16) - b.astype(np.int16)))) < thresh


def load(pat):
    items = []  # (file, idx, frame_rgb)
    for f in sorted(glob.glob(pat)):
        try:
            d = pickle.load(open(f, "rb"))
        except Exception as e:
            print(f"[skip] {os.path.basename(f)}: {e}")
            continue
        for i, t in enumerate(d):
            obs = t.get("observations", {})
            img = obs.get("camera1", None)
            if img is None:
                continue
            img = np.squeeze(np.asarray(img))  # 去掉 batch 维 (1,128,128,3)->(128,128,3)
            items.append((os.path.basename(f), i, img))
    return items


def make_grid(items, name, cols=10, max_rows=6):
    """拼缩略图网格，标注序号。"""
    n = min(len(items), cols * max_rows)
    if n == 0:
        print(f"{name}: 空")
        return
    ims = []
    for k in range(n):
        _, idx, rgb = items[k]
        small = cv2.resize(rgb, (128, 128))
        # 顶部写文件名序号（去掉 f-[0-9]+ 之类超长名，简短即可）
        tag = f"{idx}"
        cv2.putText(small, tag, (2, 14), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 0, 255), 1)
        ims.append(small)
    rows = []
    for r in range((n + cols - 1) // cols):
        row = ims[r * cols:(r + 1) * cols]
        while len(row) < cols:
            row.append(np.zeros_like(row[0]))
        rows.append(np.hstack(row))
    canvas = np.vstack(rows)
    path = os.path.join(OUT, name)
    cv2.imwrite(path, canvas[..., ::-1])  # rgb->bgr
    print(f"wrote {path}  ({n} 帧, 红字=文件内序号)")


def analyze(items, tag):
    if not items:
        return
    # 只按"文件内相邻"比较，估算静止重复占比
    by_file = {}
    for f, i, img in items:
        by_file.setdefault(f, []).append((i, img))
    total_pairs = 0
    static_pairs = 0
    for f, seq in by_file.items():
        seq.sort()
        prev = None
        for i, img in seq:
            if is_static(prev, img):
                static_pairs += 1
            total_pairs += 1
            prev = img
    print(f"[{tag}] 文件内相邻帧对比: 近静止重复占比 {static_pairs}/{total_pairs} = {100*static_pairs/max(total_pairs,1):.0f}%")


def main():
    pos = load(os.path.join(DATA, "*success*.pkl"))
    neg = load(os.path.join(DATA, "*failure*.pkl"))
    print(f"== 正样本(成功) {len(pos)} 帧 ==")
    print(f"== 负样本(失败) {len(neg)} 帧 ==")

    # 文件内重复度（正样本若大量静止重复 => 长时间原地举着/或标正后不动）
    analyze(pos, "success")
    analyze(neg, "failure")

    # 均匀抽样拼图：每文件均匀取, 避免前几十帧全是一个文件
    def sample_uniform(items, k=60):
        if len(items) <= k:
            return items
        idx = np.linspace(0, len(items) - 1, k).astype(int)
        return [items[i] for i in idx]

    make_grid(sample_uniform(pos, 60), "pos_grid.png")
    make_grid(sample_uniform(neg, 60), "neg_grid.png")

    # 每文件首帧与末帧单独存两张，便于对照"一个文件从什么状态开始/结束"
    seen = set()
    for f, i, img in pos:
        if f in seen:
            continue
        seen.add(f)
        cv2.imwrite(os.path.join(OUT, f"pos_{f.replace('.pkl','').replace('_success_images_','@').replace('_','-')}_i{i}.png"),
                    img[..., ::-1])
    print("done. 请查看容器内目录:", OUT)


if __name__ == "__main__":
    main()
