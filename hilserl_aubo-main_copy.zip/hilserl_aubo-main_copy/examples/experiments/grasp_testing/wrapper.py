"""
=============================================================================
 grasp_testing —— 任务环境（wrapper.py）
=============================================================================

【这个文件是干什么的】
定义"这个任务在机器人上到底怎么执行"。里面有两个类：

  1) GraspTestingEnv
     任务环境本体，继承 auboEnv（serl_robot_infra/aubo_env/envs/aubo_env.py）。
     基类已经帮我们做了绝大部分事情：
        - 通过 HTTP 跟机器人控制服务对话（发位姿/关节/夹爪指令、读当前状态）
        - 从 RealSense 读图、裁剪、缩放到 128×128
        - 把动作限制在安全范围内（clip_safety_box）
        - 计算观测、判断是否到达步数上限、保存视频
     子类通常**只需要重写 go_to_reset()**，也就是"每个回合开始时，机器人该怎么回到起点"。

  2) GripperPenaltyWrapper
     夹爪惩罚。抓取任务里策略很容易学会"疯狂开关夹爪"来刷奖励，用这个 wrapper 抑制。

【什么时候需要改这个文件】
  - 复位动作不合适（会撞、走的路径不对、需要先去取料）  -> 改 go_to_reset()
  - 夹爪反馈方向反了（明明闭合却被认为是张开）           -> 改 GripperPenaltyWrapper 的阈值判断
  - 需要"回合开始时先做一串固定动作"（如先张开夹爪再下降）-> 在 go_to_reset() 末尾追加

【调用时机】（都由 gymnasium 的标准流程触发）
  env.reset()  -> auboEnv.reset() -> self.go_to_reset()   # 回合开始
  env.step(a)  -> auboEnv.step()                          # 每一步
"""

import copy
import os
import time

import gymnasium as gym
import numpy as np

from aubo_env.envs.aubo_env import auboEnv


def _dbg(msg):
    """[dbg][reset] 复位流程日志：AUBO_DBG=1 时输出（run.sh 默认 0=关，排查时 AUBO_DBG=1 bash run.sh）"""
    if os.environ.get("AUBO_DBG", "1") == "1":
        print(msg, flush=True)


class GraspTestingEnv(auboEnv):
    """抓取测试任务的环境。

    目前只重写了 go_to_reset()：其余能力（相机、限幅、观测、视频）全部沿用基类。
    如果你要扩展（例如复位时先去料框取件），在这个类里加方法即可。
    """

    def __init__(self, **kwargs):
        # 基类会完成：读取 config、建立安全限位框、连接机器人服务、初始化相机与显示窗口
        super().__init__(**kwargs)

    def go_to_reset(self, joint_reset=False, retreat=True):
        """
        【回合复位流程】——每个回合结束/开始时都会调用一次。

        为什么不能直接一句话"回到起点"？因为机器人此时可能正贴着工件或处于力控状态，
        直接走关节运动会拖着工件撞过去。标准做法是"先脱开接触，再大范围移动"：

        步骤 1  退出力控（阻抗）模式
                —— 力控模式下机器人会主动"抵抗"外力，无法执行精确的点位运动，必须先退出。
        步骤 2  先退开一点（防碰撞）
                —— 沿某个安全方向平移几厘米，脱离与工件/治具的接触。
        步骤 3  回到任务起始点
                —— 推荐用关节角（TASK_INIT_JOINT），重复性好；位姿解算可能有多种关节解。
        步骤 4  张开夹爪
                —— 抓取任务必须：保证每回合都从"没抓住"状态开始，策略才能学到"闭合=抓取"。
        步骤 5  重新开力控并降速
                —— 交还给策略控制；速度调低一点，策略的动作更平滑安全。

        参数：
            joint_reset: True 时额外执行一次关节回零（由基类 reset 里的 JOINT_RESET_PERIOD 触发）
            retreat    : False 时跳过"退开"动作（例如确定当前位置本来就安全时用）

        TODO: "-0.05" 这个后退方向与距离是按原先工位写的，请按你的工位确认：
              机器人往哪边退才不会撞？必要时改成沿工具坐标系后退或增大距离。
        """
        # -------- 步骤 1：退出力控，准备做点位运动 --------
        _t0 = time.time()
        _dbg(f"[dbg][reset] go_to_reset enter joint_reset={joint_reset} retreat={retreat}")
        self._update_currstate()      # 先刷新一次机器人状态，拿到最新的 self.currpos
        _dbg("[dbg][reset]   0) update_currstate ok")
        self._stop_imp_control()      # 通知控制服务关闭力控（对应 HTTP /stop_imp）
        self._set_robot_goal_speed(0.6)   # 全局速度比例 0~1，复位时快一点没关系
        time.sleep(0.1)               # 给机器人一点响应时间
        _dbg("[dbg][reset]   1) stop_imp + speed ok")

        # -------- 步骤 2：沿基座坐标系 x 轴后退 5 厘米，脱离接触 --------
        if retreat:
            pose = copy.deepcopy(self.currpos)          # currpos 是 [x,y,z, qx,qy,qz,qw]
            pose[:3] += np.array([-0.05, 0.0, 0.0])    # 只改位置，姿态保持不变
            _dbg(f"[dbg][reset]   2) retreat send_pose xyz={np.round(pose[:3], 4).tolist()}")
            self._send_target_pose(pose)

        # -------- 步骤 3：回到任务起始点 --------
        if self.randomreset:
            # 开启了随机复位：在起始位姿附近随机偏移，强迫策略适应不同初始状态（提升泛化）
            reset_pose = self.config.TASK_INIT_POSE.copy()
            reset_pose[:3] += np.random.uniform(        # 位置随机
                -self.config.RANDOM_XYZ_RANGE, self.config.RANDOM_XYZ_RANGE, (3,)
            )
            euler_random = self.config.TASK_INIT_POSE[3:].copy()
            euler_random += np.random.uniform(          # 姿态随机
                -self.config.RANDOM_RPY_RANGE, self.config.RANDOM_RPY_RANGE
            )
            reset_pose[3:] = euler_random
            self._send_target_pose(reset_pose, speed=0.8, acce=1.4)
        else:
            # 默认：直接走关节角到起始姿态（speed/acce 是速度与加速度比例）
            _dbg("[dbg][reset]   3) move_joint to TASK_INIT_JOINT (blocking...)")
            self._send_target_joints(self.config.TASK_INIT_JOINT, speed=0.8, acce=1.4)

        # 到位后的稳定时间：move_joint 内部已经 wait=True 阻塞等到位，
        # 这里只需留一点余量让机械臂停稳、状态线程刷新，不需要长时间等待。
        # （这里曾是 time.sleep(60)，纯空等 60 秒，每回合白白多花一分钟）
        #
        # 注意：RANDOM_RESET=True 时上面走的是 _send_target_pose 而不是关节运动，
        # 而 /set_pose 在伺服关闭期间只会写 target_pose、不会真的移动（见 README 12.4-P1-3），
        # 那时机械臂要等步骤 5 重新开伺服后才开始动 —— 若开启随机复位，需要先把 P1-3 修掉再调这个等待。
        _dbg(f"[dbg][reset]   3) arrived, settle 1.5s (elapsed {time.time()-_t0:.1f}s)")
        time.sleep(1.5)

        # -------- 步骤 4：张开夹爪 --------
        # _send_gripper_command 是"二值"模式：>=0.9 张开，<=-0.9 闭合，中间值不动作。
        # GRIPPER_OPEN_AT_RESET 来自 config.py 的 EnvConfig（本任务新增的自定义字段）。
        if getattr(self.config, "GRIPPER_OPEN_AT_RESET", True):
            self._send_gripper_command(1.0)
            time.sleep(getattr(self.config, "GRIPPER_SLEEP", 1.0))   # 等夹爪真的张开

        # -------- 步骤 5：恢复力控，降速，交还策略 --------
        _dbg("[dbg][reset]   5) start_imp")
        self._start_imp_control()
        self._set_robot_goal_speed(0.4)
        time.sleep(0.1)
        _dbg(f"[dbg][reset]   go_to_reset done (elapsed {time.time()-_t0:.1f}s)")


class GripperPenaltyWrapper(gym.Wrapper):
    """抑制"无效夹爪开合"的包装器（只有"学习抓取"的任务才需要）。

    【为什么需要它】
    抓取任务里，策略有时会发现"反复开关夹爪"能在某些画面上骗过奖励分类器，
    从而刷到奖励。加一个小的负惩罚，可以让夹爪动作变得"有必要时才做"。

    【它怎么生效（数据流向）】
        step() 里判断动作是否有效
            -> 把惩罚写进 info["grasp_penalty"]      （注意：不直接改 reward）
            -> train_rlpd.py 的 actor 把它写进 transition
            -> replay buffer（include_grasp_penalty=True，由 setup_mode 自动决定）
            -> SACAgentHybridSingleArm 用 rewards + grasp_penalty 训练 grasp critic

    【放置位置】必须是整条 wrapper 链的**最外层**（见 config.py 第 8 步的注释）。

    【观测索引怎么来的（重要，aubo 与网上 SERL 教程不同）】
        SERLObsWrapper 把 Dict 观测按 proprio_keys 顺序压成一维数组
        ChunkingWrapper 再在最前面加一个时间维（obs_horizon=1 时该维长度为 1）
        而 gripper_pose 是 proprio_keys 的最后一项
        => 所以夹爪状态在 state 的**最后一个**元素，用 state[..., -1] 取最稳妥。
        网上 SERL/Franka 代码里常见的 obs["state"][0, 0] 在本工程会取错位，不要照抄。
    """

    def __init__(self, env, penalty=-0.05, gripper_closed_thresh=0.9):
        super().__init__(env)
        # 学习抓取必须是 7 维动作（前 6 维位姿增量 + 第 7 维夹爪）
        assert env.action_space.shape == (7,), "学习抓取任务需要 7 维动作空间 (xyz+rpy+gripper)"

        # penalty：惩罚值，负数。0 = 关闭惩罚；越负，夹爪越"懒"。
        self.penalty = penalty

        # 判定"夹爪已闭合"的阈值。aubo 的 gripper_pose = gripper[0]/100，范围 0~1。
        # 默认约定：0 = 完全张开，接近 1 = 闭合。
        # TODO: 若你的夹爪反馈方向相反（张开时读数接近 1），把下面两处判断取反即可，
        #       即改成 (gripper_cmd < -0.5 and not already_closed) or (gripper_cmd > 0.5 and already_closed)。
        self.gripper_closed_thresh = gripper_closed_thresh

        self.last_gripper_pos = None

    @staticmethod
    def _get_gripper_pos(obs):
        """从观测里取出夹爪开合量（取 state 的最后一个元素，兼容有无时间维）。"""
        return float(np.asarray(obs["state"]).reshape(-1)[-1])

    def reset(self, **kwargs):
        obs, info = self.env.reset(**kwargs)
        self.last_gripper_pos = self._get_gripper_pos(obs)   # 记录复位后的夹爪状态作为基准
        return obs, info

    def step(self, action):
        observation, reward, terminated, truncated, info = self.env.step(action)

        # 人工接管时，以人类（空间鼠标）的动作作为判断依据，否则会误判
        if "intervene_action" in info:
            action = info["intervene_action"]

        # 动作第 7 维的语义：+1 = 张开，-1 = 闭合，0 = 保持
        gripper_cmd = float(np.asarray(action).reshape(-1)[-1])
        already_closed = self.last_gripper_pos > self.gripper_closed_thresh

        # 无效的两种情况：已经闭合还命令闭合、已经张开还命令张开
        if (gripper_cmd < -0.5 and already_closed) or (gripper_cmd > 0.5 and not already_closed):
            info["grasp_penalty"] = self.penalty
        else:
            info["grasp_penalty"] = 0.0

        # 更新夹爪状态供下一步判断
        self.last_gripper_pos = self._get_gripper_pos(observation)
        return observation, reward, terminated, truncated, info
