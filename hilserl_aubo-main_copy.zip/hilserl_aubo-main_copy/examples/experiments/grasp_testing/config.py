"""
=============================================================================
 grasp_testing —— 任务配置文件（新手请从这里开始读）
=============================================================================

【这个文件是干什么的】
一个"任务"= 一个目录。本文件是这个任务的全部参数与装配说明，回答三个问题：
  1) 机器人/相机长什么样、允许它去哪些地方、一次能走多远  ->  class EnvConfig
  2) 训练时看什么、batch 多大、用哪种算法                 ->  class TrainConfig
  3) 怎么把"裸的机器人环境"一层层包装成"可训练的环境"      ->  TrainConfig.get_environment()

【它在整个工程中的位置（调用链）】
  运行脚本（examples/train_rlpd.py / record_demos.py / record_success_fail.py ...）
      └─ 用 --exp_name=grasp_testing 去 experiments/mappings.py 的 CONFIG_MAPPING 里找
          └─ 找到本文件的 TrainConfig
              └─ 调用 get_environment()
                  ├─ 用 EnvConfig 创建 GraspTestingEnv（见同目录 wrapper.py）
                  │     ├─ 通过 HTTP 请求机器人控制服务（EnvConfig.SERVER_URL）
                  │     └─ 通过 VideoCaptureManager 读 RealSense 相机
                  └─ 逐层套上各种 wrapper（观测变换、人工干预、奖励分类器...）

【改这个文件会影响到什么】
  - 改相机/位姿/限位      -> 影响真实机器人动作，务必先小范围验证
  - 改 proprio_keys      -> 会改变网络输入维度，之前录的 demo_data 与 checkpoint 都会失效，需要重录重训
  - 改 setup_mode        -> 会切换智能体类型（是否含夹爪学习），同样需要重训

【单位与符号约定（全工程统一，务必遵守）】
  - 位姿写成 [x, y, z, rx, ry, rz]：xyz 单位 **米**，rpy 单位 **弧度**（XYZ 内旋欧拉角，与 scipy 的 'xyz' 一致）
  - 关节角单位 **弧度**（示教器通常显示度，需 * np.pi / 180 转换，本文件用 deg2rad）
  - 动作（action）是 7 维向量，每一维都被裁剪到 [-1, 1]：
        前 6 维 = 本步的位姿增量（相对量，乘以 ACTION_SCALE 后才是实际位移）
        第 7 维 = 夹爪指令，取 -1（闭合/抓取）、0（保持）、+1（张开）

【!! 重要 !!】
本文件里所有标了 TODO 的数值都是"占位值"，来自另一套硬件（rubber_assembly 工位），
在你的机器上几乎肯定不适用。必须按同目录 README.html「03 硬件配置与标定」逐项实测替换。
"""

import os

import jax
import jax.numpy as jnp
import numpy as np

# ---------------------------------------------------------------------------
# 机器人底层能力：环境基类与各种 wrapper 都来自 serl_robot_infra/aubo_env
# （运行时必须把 serl_robot_infra 加入 PYTHONPATH，否则这里会 import 失败）
# ---------------------------------------------------------------------------
from aubo_env.envs.wrappers import (
    Quat2EulerWrapper,                          # 把观测里的四元数转成欧拉角
    SpacemouseIntervention,                     # 允许用 3D 鼠标（空间鼠标）接管机器人
    MultiCameraBinaryRewardClassifierWrapper,   # 用图像分类器产生 0/1 奖励
)

from aubo_env.envs.relative_env import RelativeFrame   # 把观测/动作从基座坐标系转到末端坐标系
from aubo_env.envs.aubo_env import DefaultEnvConfig    # 本文件 EnvConfig 的父类，定义了所有字段的默认值
from aubo_env.camera.video_capture import VideoCaptureManager  # RealSense 相机管理（多相机、多线程取图）

# ---------------------------------------------------------------------------
# 训练侧工具：来自 serl_launcher
# ---------------------------------------------------------------------------
from serl_launcher.wrappers.serl_obs_wrappers import SERLObsWrapper  # 把 Dict 观测压成一维 state + 图像
from serl_launcher.wrappers.chunking import ChunkingWrapper          # 观测堆叠 / 动作分块执行

from experiments.config import DefaultTrainingConfig   # 本文件 TrainConfig 的父类（训练超参默认值）

# ---------------------------------------------------------------------------
# 本任务自己的环境类（同目录 wrapper.py）
# ---------------------------------------------------------------------------
from experiments.grasp_testing.wrapper import GraspTestingEnv, GripperPenaltyWrapper


# 角度单位换算：示教器读到的是"度"，代码里一律用"弧度"
deg2rad = np.pi / 180.0
rad2deg = 180.0 / np.pi

# 奖励分类器的判定阈值：分类器输出 0~1 的"成功概率"，超过该值就认为任务成功（给奖励 1）
# 调高 -> 更严格（误判少，但可能迟迟不给奖励）；调低 -> 更宽松（容易误判成功）
CLASSIFIER_THRESHOLD = 0.85


class EnvConfig(DefaultEnvConfig):
    """
    ========================= 环境配置（硬件 + 任务空间）=========================
    继承 DefaultEnvConfig，这里只覆盖需要改的字段；
    未覆盖的字段（如 COMPLIANCE_PARAM 力控参数）沿用 serl_robot_infra/aubo_env/envs/aubo_env.py 的默认值。
    """

    # ---------------------------------------------------------------
    # 一、回合长度
    # ---------------------------------------------------------------
    # 单个回合最多执行多少步。控制频率约 10Hz（每步 sleep 0.1s），所以 300 步 ≈ 30 秒。
    # 走不完就视为失败并复位。太长 -> 浪费时间、学到很多无效动作；太短 -> 任务根本做不完。
    # TODO: 先用空间鼠标手动做一次任务并计时，取"熟练完成时间 × 1.5"对应的步数。
    MAX_EPISODE_LENGTH: int = 300

    # 每多少个回合做一次"关节回零"（回机械零位，消除累积误差）。0 = 从不回零。
    # 抓取类任务一般设 0；若发现长期运行后定位漂移明显，可设 50~200。
    JOINT_RESET_PERIOD: int = 0

    # ---------------------------------------------------------------
    # 二、动作幅度（安全相关，最重要的参数之一）
    # ---------------------------------------------------------------
    # 策略输出的是 [-1,1] 的归一化动作，乘上 ACTION_SCALE 才是"每一步真实的增量"：
    #   [x, y, z, rx, ry, rz, gripper]，xyz 单位米/步，rpy 单位弧度/步，gripper 固定 1.0
    # 例：ACTION_SCALE[0] = 0.05 表示沿 x 一步最多移动 5 厘米。
    # 安全原则：刚开始一定调小（如 0.02 / 0.05 rad），确认动作方向正确、不会撞机后再逐步放大。
    # 经验：平移 0.02~0.05 m/步，旋转 0.05~0.1 rad/步；插入/贴合类任务要更小。
    # TODO: 按你的工位刚度与精度要求调整。
    ACTION_SCALE = np.array([0.02, 0.02, 0.02, 0.1, 0.1, 0.1, 1.0])

    # ---------------------------------------------------------------
    # 三、任务空间与安全限位（安全相关，必须实测）
    # ---------------------------------------------------------------
    # TARGET_POSE：任务的"目标位姿"（例如抓取点/放置点的正上方）。它有两个作用：
    #   1) 作为安全限位框的中心（见下面的 ABS_POSE_LIMIT）
    #   2) 作为姿态约束的参考基准（clip_safety_box 会限制末端相对它的旋转偏差）
    # 注意：本任务的"成功"由图像分类器判定，机器人并不会真的去逼近 TARGET_POSE，
    #       所以它的主要作用是"圈定活动范围"，值不必极端精确，但必须落在你的工位附近。
    # 用示教器把机器人移到任务目标位置，读出的位姿填这里（度要转弧度）。
    TARGET_POSE = np.array(
        [-0.05, -0.60, 0.180, 2.7, 0.0, 0.0]
    )

    # 绝对限位：机械臂 TCP 允许到达的"长方体"范围（基座坐标系）。超出会被自动截断，是最重要的一道安全闸。
    # 写法是 TARGET_POSE ± 偏移量。下方例子表示：x 方向允许 [目标-8cm, 目标+0.5cm]，y/z 各 ±1cm。
    # 姿态那三维（后三项）在当前实现里不直接用于裁剪（代码用相对姿态约束），但保留以防误改。
    # TODO: 手动摇着机器人走一遍任务需要的全部范围，把安全边界填进来。宁可先设小，跑通后再放宽。
    ABS_POSE_LIMIT_HIGH = TARGET_POSE + np.array([0.18, 0.05, 0.15, 1.7, 1.7, 1.7])
    ABS_POSE_LIMIT_LOW = TARGET_POSE - np.array([0.18, 0.30, 0.15, 1.7, 1.7, 1.7])

    # 相对姿态限位：限制末端姿态相对 TARGET_POSE 姿态能偏多少（弧度），防止机器人"扭麻花"。
    # 一般沿用即可；若任务需要大幅转动手腕（比如翻转工件），再放大。
    RELATIVE_POSE_LIMIT_HIGH = np.array([1.7, 1.7, 1.7])
    RELATIVE_POSE_LIMIT_LOW = -np.array([1.7, 1.7, 1.7])

    # ---------------------------------------------------------------
    # 四、复位随机化（影响泛化能力）
    # ---------------------------------------------------------------
    # RANDOM_RESET=True 时，每次复位会在起始位姿附近随机偏移一点，强迫策略适应不同初始状态。
    # 建议：先 False 跑通流程，确认能学会之后改 True 提升鲁棒性。
    RANDOM_RESET = False
    RANDOM_XYZ_RANGE = np.array([0.0, 0.005, 0.005])  # x/y/z 各方向的随机范围（米），三个值分别对应 x,y,z
    RANDOM_RZ_RANGE = np.array([0.1])                 # 绕 z 的随机角度（弧度），当前 wrapper 未使用，保留备用
    RANDOM_RPY_RANGE = np.array([0.05, 0.05, 0.05])   # 姿态三轴的随机范围（弧度）

    # ---------------------------------------------------------------
    # 五、机器人控制服务
    # ---------------------------------------------------------------
    # 机器人不是由本程序直接驱动，而是通过一个 HTTP 服务（serl_robot_infra/robot_servers/aubo_server.py）中转。
    # 这里填这个服务的地址；双臂工位会有两个地址（如 127.0.0.1 / 127.0.0.2）。
    # TODO: 与启动 aubo_server.py 时的 --flask_url / 端口保持一致。
    SERVER_URL: str = "http://127.0.0.1:5000/"

    # 发送夹爪指令后的等待时间（秒）。夹爪是慢设备，给足时间它才能真正到位。
    # 夹爪动作没执行完就发下一条指令，会出现"夹爪状态与观测不符"的问题。
    GRIPPER_SLEEP: float = 1.0

    # ---------------------------------------------------------------
    # 六、本任务专用参数（父类没有，是 grasp_testing 自己加的）
    # ---------------------------------------------------------------
    # 每回合复位时是否自动张开夹爪。抓取任务必须为 True，否则第二回合开始就是"已抓住"状态，学不到抓取。
    GRIPPER_OPEN_AT_RESET: bool = True

    # 对"无效夹爪开合"的惩罚值（必须是负数或 0）。
    # 作用：防止策略疯狂开关夹爪刷奖励。实际生效方式是写入 info["grasp_penalty"]，
    #       由智能体在计算 grasp Q 值时使用（reward + grasp_penalty）。
    # 0    = 关闭惩罚；-0.05 = 温和；-0.2 = 强惩罚（夹爪会变得很"懒"，只在必要时动作）。
    GRASP_PENALTY: float = -0.05

    # ---------------------------------------------------------------
    # 七、相机（视觉输入，第二个必须实测的部分）
    # ---------------------------------------------------------------
    # RealSense 相机配置。字典的 key（这里是 "camera1"）就是相机名，
    # 必须与下面 TrainConfig 的 image_keys / classifier_keys 完全对应。
    # 单相机就只写一个；要加第二台，照格式再加一项，并同步改 image_keys。
    #   serial_number: 相机序列号，用 `rs-enumerate-devices` 或 realsense-viewer 查看
    #   dim          : 采集分辨率，越大越慢，常用 (1280, 720) 或 (640, 480)
    #   exposure     : 曝光，画面过曝调小、太暗调大；光照稳定时建议手动曝光（避免自动曝光导致图像忽明忽暗）
    #   fps          : 帧率
    #  序列号必须换成你自己的相机，否则会报找不到设备/读图超时。
    REALSENSE_CAMERAS: dict = {
        "camera1": {
            "serial_number": "337122072076",  # 实测: RealSense D435i
            "dim": (1280, 720),
            "exposure": 60000,
            # D435i 在 1280x720 + bgr8 下仅支持 fps=6/10/15（不支持30），
            # 设 30 会触发 pipeline.start() 的 "Couldn't resolve requests"。
            "fps": 15,
        },
    }

    # 图像裁剪：从原始画面里切出"任务相关区域"，再统一缩放到 128×128 送给网络。
    # 写法 lambda img: img[高度范围, 宽度范围]，即 img[y0:y1, x0:x1]（注意先高后宽）。
    # 裁剪得好，等于给网络做了一次"注意力聚焦"：无关背景越少，学得越快、越稳。
    # 调整方法：把 DISPLAY_IMAGE 设为 True，运行 record_success_fail.py 弹出画面，按框选位置改这四个数。
    # TODO: 必须按你的相机安装位置重新框选。
    IMAGE_CROP: dict[str, callable] = {
        # "camera1": lambda img: img[250:500, 700:1000],
        # "camera1": lambda img: img[1:720, 430:1160],#画面太大，夹爪占比太少，判断失败
        "camera1": lambda img: img[300:720, 580:1010],#最新
        # "camera1": lambda img: img[1:720, 1:1280],#全部画面
    }

    # 是否弹出 OpenCV 窗口实时显示相机画面。调试阶段设 True；跑正式训练时可设 False 省资源（无显示器时必须 False）。
    DISPLAY_IMAGE: bool = True

    # ---------------------------------------------------------------
    # 八、预留位姿（当前 wrapper.py 未使用，供你扩展任务流程时取用）
    # ---------------------------------------------------------------
    # 抓取位姿 / 抓取关节角：如果希望"复位时先去抓工件"，可在 wrapper 里用这两个值。
    GRASP_POSE = np.array(
        [-0.18579, -0.43476, 0.35056, -3.1415926, 0.00, 0.0]
    )
    GRASP_JOINT = np.array([-86.37, -26.10, 117.63, 1.59, -88.73, 3.41]) * np.pi / 180

    # 过渡（via）位姿：两点之间移动时的中间安全点，用于绕开障碍。
    VIA_POSE = np.array(
        [-0.18579, -0.43476, 0.200, -3.1415926, 0.00, 0.0]
    )
    VIA_JOINT = np.array([-86.84, 23.08, 130.62, 17.61, 88.74, 2.93]) * np.pi / 180

    # ---------------------------------------------------------------
    # 九、复位位姿（每个回合的起点，必须实测）
    # ---------------------------------------------------------------
    # TASK_INIT_POSE : 复位位姿（xyz+rpy）。当 RANDOM_RESET=True 时作为随机化的基准。
    # TASK_INIT_JOINT: 复位关节角（弧度）。wrapper.go_to_reset() 默认走关节角（重复性比位姿好），
    #                  因此这两个值里 **TASK_INIT_JOINT 才是真正生效的那个**。
    # 测量方法：示教器把机器人摇到"每回合开始时应该在的位置" -> 读出六个关节角（度）-> 乘 deg2rad 填入。
    TASK_INIT_POSE = np.array(
        [-0.05, -0.60, 0.180, 2.7, 0.0, 0.0]
    )
    TASK_INIT_JOINT = np.array([-70.1, 19.37, 139.52, 53.91, 81.64, 17.91]) * deg2rad


class TrainConfig(DefaultTrainingConfig):
    """
    ========================= 训练配置（学什么 + 怎么学）=========================
    继承 DefaultTrainingConfig，父类提供了全部默认值（见 examples/experiments/config.py），
    这里只覆盖本任务关心的部分。常用但未列出的父类字段：
        max_steps(1000000)  replay_buffer_capacity(200000)  discount(0.97)
        random_steps(0)     training_starts(100)            eval_period(2000)
        cta_ratio(2)        log_period(10)                  demo_path(None)
    """

    # ---------------------------------------------------------------
    # 一、观测内容（决定网络"看"什么）
    # ---------------------------------------------------------------
    # 参与策略决策的相机名，必须是 EnvConfig.REALSENSE_CAMERAS 里的 key。
    # 例子只用一个相机；若加第二台，写成 ["camera1", "camera2"]，网络会自动多一路输入。
    image_keys = ["camera1"]

    # 参与"奖励分类器"的相机名。可以和 image_keys 不同：
    # 例如策略看腕部相机（近处好操作），分类器看侧面相机（远处能判断是否成功）。
    # 本任务只有一台相机，所以两者相同。
    classifier_keys = ["camera1"]

    # 本体感受（非图像）观测量，会按顺序拼接成一维 state 向量。
    # 可选键来自 auboEnv 的观测空间：tcp_pose / tcp_vel / tcp_force / tcp_torque / gripper_pose
    #   tcp_pose    : 末端位姿（经 Quat2EulerWrapper 后为 6 维：xyz + rpy）
    #   tcp_vel     : 末端速度（6 维，已被 RelativeFrame 转到末端坐标系）
    #   tcp_force   : 末端受力前 3 维（需要力传感器；没有或噪声大时可去掉）
    #   tcp_torque  : 末端受力后 3 维（力矩；同上）
    #   gripper_pose: 夹爪开合量（0~1 归一化）
    #
    # !! 顺序很重要 !!：GripperPenaltyWrapper 通过 state 的"最后一个元素"读取夹爪状态，
    #    因此 **gripper_pose 必须保持在列表最后**。
    # 想去掉力/力矩（没有力传感器或噪声大）时，改成：
    #     proprio_keys = ["tcp_pose", "tcp_vel", "gripper_pose"]
    # 注意：改动会改变输入维度，之前录的示范数据与 checkpoint 都会失效，需要重录重训。
    proprio_keys = ["tcp_pose", "tcp_vel", "tcp_force", "tcp_torque", "gripper_pose"]

    # ---------------------------------------------------------------
    # 二、算法与超参
    # ---------------------------------------------------------------
    # 单卡/多卡下每次梯度更新的样本数，必须能被 GPU 数量整除
    # （train_rlpd.py 里有 assert config.batch_size % num_devices == 0）
    batch_size = 64

    # actor 每多少步把采集到的经验写成 pkl 落盘（防止崩溃丢数据，也便于续训）
    buffer_period = 1000

    # learner 每多少步保存一次网络 checkpoint（保存到 --agent_checkpoint_path 目录）
    checkpoint_period = 3000

    # learner 每多少步把最新网络参数推送给 actor。
    # 调小 -> actor 更快用上新策略（学习快，但通信开销大）；调大 -> 更省带宽但滞后。
    steps_per_update = 50

    # 视觉编码器："resnet-pretrained" = 冻结的预训练 ResNet10（推荐，样本效率高）；
    #              "resnet"          = 从零训练的 ResNet10（需要更多数据）
    encoder_type = "resnet-pretrained"

    # 机械臂构型，决定使用哪种智能体与动作空间，取值：
    #   "single-arm-fixed-gripper"   : 单臂，夹爪不学习（预抓取），动作 6 维  -> SACAgent
    #   "single-arm-learned-gripper" : 单臂，夹爪由策略学习，动作 7 维        -> SACAgentHybridSingleArm（本任务）
    #   "dual-arm-*"                 : 双臂版本
    # 改动这一项 = 换智能体 = 必须重新训练，且 demo 数据也要重录。
    setup_mode = "single-arm-learned-gripper"

    # ---------------------------------------------------------------
    # 三、环境装配（核心：把"裸环境"包成"训练环境"）
    # ---------------------------------------------------------------
    # 所有训练/采集脚本都会调用这个函数拿环境，因此这里是理解整个系统的最佳入口。
    # 参数说明：
    #   fake_env                  : True = 假环境（不连机器人/相机），learner 端用，只为拿到 observation_space
    #   save_video                : 是否把每回合画面存成 mp4 到 ./videos
    #   classifier                : 是否加载奖励分类器（训练/录示范时必须 True，否则没有奖励信号）
    #   classifier_checkpoint_step: 加载 classifier_ckpt/checkpoint_<N> 的第 N 步权重
    #   spacemouse_expert         : 空间鼠标对象，默认内部新建
    def get_environment(
        self,
        camera_manager=None,
        fake_env=False,
        save_video=False,
        classifier=False,
        classifier_checkpoint_step=None,
        classifier_checkpoint_path=None,
        spacemouse_expert=None,
    ):
        # ---- 第 0 步：相机管理器 ------------------------------------------
        # 相机是独占设备，多个环境实例共享同一个管理器；fake_env 时不需要真实相机。
        if not camera_manager and (not fake_env):
            camera_manager = VideoCaptureManager(verbose=True)

        # ---- 第 1 步：任务环境本体 ----------------------------------------
        # GraspTestingEnv（同目录 wrapper.py）继承 auboEnv，提供：
        #   - 通过 HTTP 与机器人控制服务通信（发位姿/关节/夹爪指令、读状态）
        #   - 读取并处理相机图像（裁剪 + resize 到 128×128）
        #   - 安全限位裁剪（clip_safety_box）
        #   - go_to_reset()：回合复位流程（本任务重写了它）
        # env_name 只用于显示窗口标题，不影响功能。
        env = GraspTestingEnv(
            env_name="grasp_testing",
            camera_manager=camera_manager,
            fake_env=fake_env,
            save_video=save_video,
            config=EnvConfig(),
        )

        # ---- 第 2 步：空间鼠标人工干预 ------------------------------------
        # 人可以用 3D 鼠标随时接管机器人。接管产生的动作会放进 info["intervene_action"]，
        # 训练脚本会把这些"人类修正"的数据单独存进 demo buffer，这就是 HIL-SERL 的关键机制。
        # 因为动作空间是 7 维，鼠标的左右键还能控制夹爪开合（6 维时则禁用夹爪控制）。
        if not fake_env:
            env = SpacemouseIntervention(env, expert=spacemouse_expert)

        # ---- 第 3 步：相对坐标系 -------------------------------------------
        # 把观测与动作从"基座坐标系"变换到"末端（工具）坐标系"，并把 tcp_pose 变成相对复位点的位姿。
        # 好处：策略学到的是"相对自己的动作"，换个安装位置也能复用；同时对小位移更敏感。
        env = RelativeFrame(env)

        # ---- 第 4 步：四元数转欧拉角 ---------------------------------------
        # 机器人给的是四元数，直接喂网络会有"双覆盖"问题（q 与 -q 表示同一姿态），转成欧拉角更稳定。
        env = Quat2EulerWrapper(env)

        # ---- 第 5 步：观测扁平化 -------------------------------------------
        # 把 {"state": {...}, "images": {...}} 压成 {"state": 一维数组, "camera1": 图像}。
        # 数组顺序 = proprio_keys 的顺序，这是理解 state 各段含义的关键。
        env = SERLObsWrapper(env, proprio_keys=self.proprio_keys)

        # ---- 第 6 步：观测堆叠 ---------------------------------------------
        # obs_horizon=1 表示不堆叠历史帧（只看当前帧）；act_exec_horizon=None 表示一次执行一个动作。
        env = ChunkingWrapper(env, obs_horizon=1, act_exec_horizon=None)

        # ---- 第 7 步：奖励分类器 -------------------------------------------
        # 机器人任务很难写解析式奖励，这里用一个"图像二分类网络"判断当前画面是否达成了目标：
        #   是 -> reward = 1 且回合结束；否 -> reward = 0
        # 分类器权重来自第 05 节流程中的 --task=train 步骤（classifier_ckpt/）。
        if classifier or classifier_checkpoint_step:
            from serl_launcher.networks.reward_classifier import load_classifier_func

            # 没显式指定路径时，在"当前工作目录"下找 classifier_ckpt/
            # => 所有脚本都必须先 cd 到实验目录再运行，否则会找不到分类器。
            if not classifier_checkpoint_path:
                classifier_checkpoint_path = os.path.abspath("classifier_ckpt/")

            classifier = load_classifier_func(
                key=jax.random.PRNGKey(0),
                sample=env.observation_space.sample(),
                image_keys=self.classifier_keys,
                checkpoint_path=classifier_checkpoint_path,
                checkpoint_step=classifier_checkpoint_step,
            )

            def reward_func(obs):
                # 分类器输出 logits，经 sigmoid 变成 0~1 的成功概率
                sigmoid = lambda x: 1 / (1 + jnp.exp(-x))
                classifier_reward = sigmoid(classifier(obs))
                print(f"classifier reward: {classifier_reward}")
                # 超过阈值才算成功（可调：误判多就调高，迟迟不给奖励就调低）
                return int(np.array(classifier_reward > CLASSIFIER_THRESHOLD))

            env = MultiCameraBinaryRewardClassifierWrapper(env, reward_func)

        # ---- 第 8 步：夹爪惩罚（本任务特有，必须在最外层）--------------------
        # 作用：防止策略疯狂开关夹爪。它读取动作第 7 维与当前夹爪状态，
        #       把惩罚写进 info["grasp_penalty"]，最终由 SACAgentHybridSingleArm 使用。
        # 放在最外层的原因：
        #   1) 需要读到内层 SpacemouseIntervention 写入的 info["intervene_action"]；
        #   2) 需要在分类器包装之后，才能把 grasp_penalty 附加到最终的 info 上。
        env = GripperPenaltyWrapper(env, penalty=EnvConfig.GRASP_PENALTY)

        return env
