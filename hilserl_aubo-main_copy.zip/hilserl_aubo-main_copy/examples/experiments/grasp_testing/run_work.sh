#!/bin/bash
#
# 产线作业模式：加载训练好的网络，在真实工位循环执行任务
# 若只想评估成功率（打印 success rate），把 train_work.py 换成 train_rlpd.py 即可：
#   bash run.sh --task=eval
# 执行： bash run_work.sh
#
# 运行环境：docker 容器（默认 hilserl）内运行，容器内已装好全部依赖，无需 conda。
#   在宿主机执行  -> 自动 docker exec 进入容器后重跑本脚本
#   已在容器内执行 -> 直接运行
#

ORIG_ARGS="$*"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ---------------- docker 配置 ----------------
USE_DOCKER=true                                # false = 直接在当前环境运行，不进容器
DOCKER_CONTAINER=hilserl                       # 容器名
HOST_MOUNT_PREFIX=/home/xupeng/xupeng/hilserl  # 宿主机上的挂载点（docker -v 的左边）
CONTAINER_MOUNT_PREFIX=/root/hilserl           # 容器内的挂载点（docker -v 的右边）
PY=python3                                     # 容器内的 python 解释器

# ---------------- 进入 docker 容器（不在容器内时自动进入并重跑本脚本） ----------------
if [ "$USE_DOCKER" = true ] && [ ! -f /.dockerenv ]; then
    case "$SCRIPT_DIR" in
        "$HOST_MOUNT_PREFIX"*)
            CONTAINER_DIR="$CONTAINER_MOUNT_PREFIX${SCRIPT_DIR#$HOST_MOUNT_PREFIX}"
            ;;
        *)
            echo "[error] 脚本路径 $SCRIPT_DIR 不在挂载点 $HOST_MOUNT_PREFIX 内，无法映射为容器路径"
            echo "        请修改脚本头部的 HOST_MOUNT_PREFIX / CONTAINER_MOUNT_PREFIX"
            exit 1
            ;;
    esac
    if [ -t 0 ]; then TTY_FLAG="-it"; else TTY_FLAG="-i"; fi
    echo "[docker] 进入容器 $DOCKER_CONTAINER：$CONTAINER_DIR"
    exec docker exec $TTY_FLAG -e DISPLAY="$DISPLAY" -e PYTHONPATH= "$DOCKER_CONTAINER" \
        bash -lc "cd '$CONTAINER_DIR' && bash run_work.sh $ORIG_ARGS"
fi

cd "$SCRIPT_DIR"
export PYTHONPATH=$PYTHONPATH:$(cd ../../../serl_robot_infra && pwd)

# ---------------- 按需修改 ----------------
AGENT_CKPT=first_run          # agent checkpoint 目录
AGENT_STEP=30000              # 要加载的网络步数（--agnet_checkpoint_step，注意原 flag 拼写）
CLASSIFIER_STEP=200           # classifier_ckpt/checkpoint_<N>
# ----------------------------------------

export XLA_PYTHON_CLIENT_PREALLOCATE=false
export XLA_PYTHON_CLIENT_MEM_FRACTION=.1

$PY ../../train_work.py \
    --exp_name=grasp_testing \
    --classifier_checkpoint_step=$CLASSIFIER_STEP \
    --agent_checkpoint_path=$AGENT_CKPT \
    --agnet_checkpoint_step=$AGENT_STEP \
    --eval_n_trajs=1 \
    --actor
