#!/bin/bash
#
# grasp_testing 集成脚本，用法： bash run.sh --task=xxx
#   data     采集成功/失败图像（供分类器训练）
#   train    训练图像奖励分类器
#   demo     录制专家示范轨迹（需先有分类器）
#   learner  启动训练端（GPU 机器）
#   actor    启动采样端（连接机器人的机器）
#   eval     评估指定步数的策略
#   work     产线作业模式
#
# 说明：所有数据目录（classifier_data / classifier_ckpt / demo_data / agent checkpoint）
#       都以本脚本所在目录（实验目录）为基准，脚本会自动 cd 过去。
#
# 运行环境：本套脚本在 docker 容器（默认容器名 hilserl）内运行，容器内已装好全部依赖，
#       不再需要 conda。两种用法都可以：
#         1) 在宿主机执行  -> 脚本自动 docker exec 进入容器后重新执行自己
#         2) 已 docker exec 进入容器后执行 -> 直接在容器内运行
#

ORIG_ARGS="$*"

# ---------------- 解析命令行参数 ----------------
while [[ "$#" -gt 0 ]]; do
    case $1 in
    --task=*) task="${1#*=}" ;;
    *)
        echo "Unknown parameter passed: $1"
        exit 1
        ;;
    esac
    shift
done

if [ -z "$task" ]; then
    echo "Error: --task parameter is required. (data/train/demo/learner/actor/eval/work)"
    exit 1
fi

# ---------------- 路径自动推导（移植到别的机器无需改这里） ----------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
EXAMPLE_PATH="$(cd "$SCRIPT_DIR/../.." && pwd)"
EXPERIMENT_PATH="$SCRIPT_DIR"

# [dbg] 排查日志开关：默认关闭（终端干净）。需要定位卡点/看机械臂状态时再开：
#   AUBO_DBG=1 bash run.sh --task=xxx
export AUBO_DBG="${AUBO_DBG:-0}"

# ---------------- COMMON CONFIGS ----------------
# docker 运行环境（容器内已装好依赖，无需 conda）
USE_DOCKER=true                                # false = 直接在当前环境运行，不进容器
DOCKER_CONTAINER=hilserl                       # 容器名，改成你自己的
HOST_MOUNT_PREFIX=/home/xupeng/xupeng/hilserl  # 宿主机上的挂载点（docker -v 的左边）
CONTAINER_MOUNT_PREFIX=/root/hilserl           # 容器内的挂载点（docker -v 的右边）
PY=python3                                     # 容器内的 python 解释器

# 实验名称，必须与 experiments/mappings.py 中的 key 一致
EXPERIMENT_NAME=grasp_testing

# 数据日期：默认取【运行当天】，与 record_success_fail.py / record_demos.py 里
#           datetime.now().strftime("%Y-%m-%d") 的建目录规则一致，
#           所以"同一天：采集 → 训分类器 → 录示范 → 训练"可以全自动对上，不用手改。
#   classifier_data/<DATA_DATE>/   ← --task=data  产出的分类器训练集
#   demo_data/<DATA_DATE>/         ← --task=demo  产出的示范轨迹
# 需要读【往天】的数据时，用环境变量临时覆盖（不要改这里，改了第二天又会错）：
#   DATA_DATE=2026-09-07 bash run.sh --task=train
# 注意：采集/录示范的"写入目录"由 Python 用当天日期生成，不受本变量控制；
#       所以隔天补采会写进新目录，需要时也用上面的方式指过去。
DATA_DATE=${DATA_DATE:-$(date +%F)}
DATA_DATE=2026-09-09

# 分类器训练所用的数据集文件夹（classifier_data/<DATA_DATE>）
CLASSIFIER_DATA_CHECKPOINT=$DATA_DATE

# 使用的分类器 classifier_ckpt/checkpoint_<N>，需与 --num_epochs 一致
CLASSIFIER_CHECKPOINT=200

# 示范轨迹文件夹（会加载该文件夹下所有 pkl）
DEMO_PATH=$EXPERIMENT_PATH/demo_data/$DATA_DATE

# 保存 agent 与 buffer 的文件夹名
ACTOR_CHECKPOINT=first_run

# 评估/部署时加载的网络步数（改成你实际训练出来的 step）
AGENT_CHECKPOINT_STEP=30000
EVAL_N_TRAJS=10

# wandb（learner 端需要；留空则不上传）
WANDB_API_KEY_CLH=

# ---------------- 进入 docker 容器（不在容器内时自动进入并重跑本脚本） ----------------
if [ "$USE_DOCKER" = true ] && [ ! -f /.dockerenv ]; then
    case "$SCRIPT_DIR" in
        "$HOST_MOUNT_PREFIX"*)
            CONTAINER_DIR="$CONTAINER_MOUNT_PREFIX${SCRIPT_DIR#$HOST_MOUNT_PREFIX}"
            ;;
        *)
            echo "[error] 脚本路径 $SCRIPT_DIR 不在挂载点 $HOST_MOUNT_PREFIX 内，无法映射为容器路径"
            echo "        请修改脚本头部的 HOST_MOUNT_PREFIX / CONTAINER_MOUNT_PREFIX"
            exit 1
            ;;
    esac
    if [ -t 0 ]; then TTY_FLAG="-it"; else TTY_FLAG="-i"; fi
    echo "[docker] 进入容器 $DOCKER_CONTAINER：$CONTAINER_DIR"
    # 传 TZ：容器内 python 的 datetime.now() 按本地时区生成数据目录名，
    #        若容器是 UTC 而宿主机是 CST，凌晨那几个小时两边日期会差一天，导致"写进 A 目录、读 B 目录"。
    # 传 DATA_DATE：宿主机算出的日期传给容器内重跑的脚本，保证两边读同一个目录。
    HOST_TZ="${TZ:-$(cat /etc/timezone 2>/dev/null || echo Asia/Shanghai)}"
    # AUBO_DBG 已在上面 export（默认 0=关，AUBO_DBG=1 开启排查日志），这里原样透传进容器
    exec docker exec $TTY_FLAG -e DISPLAY="$DISPLAY" -e PYTHONPATH= -e TZ="$HOST_TZ" \
        -e DATA_DATE="${DATA_DATE:-}" -e AUBO_DBG="$AUBO_DBG" "$DOCKER_CONTAINER" \
        bash -lc "cd '$CONTAINER_DIR' && bash run.sh $ORIG_ARGS"
fi

# ---------------- 环境准备 ----------------
# EXAMPLE_PATH 是 .../hilserl_aubo-main/examples，serl_robot_infra 在项目根下，所以是 ../
export PYTHONPATH=$PYTHONPATH:$(cd "$EXAMPLE_PATH/../serl_robot_infra" && pwd)
echo "PYTHONPATH is set to: $PYTHONPATH"
cd "$EXPERIMENT_PATH" || exit 1
echo "EXPERIMENT_PATH = $EXPERIMENT_PATH"

# ---------------- 日志落盘（仅 AUBO_DBG=1 时启用；默认关，终端干净） ----------------
# 排查用：AUBO_DBG=1 时把 task 全部输出（含 [dbg]）追加写入 <实验目录>/logs/，
#         并启动 tick 进程每秒记一行，量化"从哪一秒开始没动静"。
if [ "$AUBO_DBG" = "1" ]; then
    set -o pipefail
    LOG_DIR="$EXPERIMENT_PATH/logs"
    mkdir -p "$LOG_DIR"
    LOG_FILE="$LOG_DIR/$(date +%Y%m%d_%H%M%S)_${task}.log"
    echo "[log] 本进程输出已同时写入: $LOG_FILE"

    # tick 进程：即使被测进程所有线程被冻结，它也照常每秒写一行（量化停顿时长）
    ( while :; do printf '[tick] %s\n' "$(date +%Y-%m-%d_%H:%M:%S.%N)" >> "$LOG_FILE"; sleep 1; done ) &
    _TICK_PID=$!
    trap '[ -n "$_TICK_PID" ] && kill "$_TICK_PID" 2>/dev/null' EXIT

    run_task() { "$@" 2>&1 | tee -a "$LOG_FILE"; }
else
    echo "[log] 调试日志已关闭（AUBO_DBG=0）。需要排查时用: AUBO_DBG=1 bash run.sh --task=$task"
    run_task() { "$@"; }
fi

# ---------------- 按任务分发 ----------------
echo "[data] DATA_DATE=$DATA_DATE    (今天 $(date +%F))"
echo "       classifier_data/$DATA_DATE  ← 分类器训练集；demo_data/$DATA_DATE ← 示范轨迹"
if [ "$DATA_DATE" != "$(date +%F)" ]; then
    echo "[warn] DATA_DATE 不是今天：读取的是历史目录，确认这是你想要的（新建数据只会写到今天）"
fi
if [ "$task" == "data" ]; then
    # 采集成功/失败图像：空格=成功，F3=结束回合，Esc=退出
    run_task $PY "$EXAMPLE_PATH/record_success_fail.py" "$@" \
        --exp_name=$EXPERIMENT_NAME \
        --successes_needed=500

elif [ "$task" == "train" ]; then
    # 护栏：数据集目录不存在/为空时立刻报错，避免"训完才发现训了个空的"
    if [ -z "$(ls -A classifier_data/$CLASSIFIER_DATA_CHECKPOINT 2>/dev/null)" ]; then
        echo "[error] classifier_data/$CLASSIFIER_DATA_CHECKPOINT 不存在或为空（今天 $(date +%F)）"
        echo "        请先跑 --task=data 采集；若数据在其他日期的目录里，用下面的方式指定："
        echo "            DATA_DATE=2026-09-07 bash run.sh --task=train"
        exit 1
    fi
    run_task $PY "$EXAMPLE_PATH/train_reward_classifier.py" "$@" \
        --exp_name=$EXPERIMENT_NAME \
        --checkpoint_path=$CLASSIFIER_DATA_CHECKPOINT \
        --num_epochs=$CLASSIFIER_CHECKPOINT

elif [ "$task" == "demo" ]; then
    # 示范录制：空间鼠标演示，F5=结束回合，成功回合才保存
    run_task $PY "$EXAMPLE_PATH/record_demos.py" "$@" \
        --exp_name=$EXPERIMENT_NAME \
        --classifier_checkpoint_step=$CLASSIFIER_CHECKPOINT \
        --successes_needed=20

elif [ "$task" == "learner" ]; then
    # 护栏：示范目录不存在时立刻报错，否则 demo buffer 为 0，RLPD 只有一半样本
    if [ ! -d "$DEMO_PATH" ]; then
        echo "[error] $DEMO_PATH 不存在（今天 $(date +%F)）"
        echo "        请先跑 --task=demo 录示范；若示范在其他日期的目录里，用下面的方式指定："
        echo "            DATA_DATE=2026-09-07 bash run.sh --task=learner"
        exit 1
    fi
    [ -n "$WANDB_API_KEY_CLH" ] && export WANDB_API_KEY=$WANDB_API_KEY_CLH
    export XLA_PYTHON_CLIENT_PREALLOCATE=false
    export XLA_PYTHON_CLIENT_MEM_FRACTION=.5
    run_task $PY "$EXAMPLE_PATH/train_rlpd.py" "$@" \
        --exp_name=$EXPERIMENT_NAME \
        --classifier_checkpoint_step=$CLASSIFIER_CHECKPOINT \
        --agent_checkpoint_path=$ACTOR_CHECKPOINT \
        --demo_path=$DEMO_PATH \
        --learner

elif [ "$task" == "actor" ]; then
    export XLA_PYTHON_CLIENT_PREALLOCATE=false
    export XLA_PYTHON_CLIENT_MEM_FRACTION=.2
    run_task $PY "$EXAMPLE_PATH/train_rlpd.py" "$@" \
        --exp_name=$EXPERIMENT_NAME \
        --classifier_checkpoint_step=$CLASSIFIER_CHECKPOINT \
        --agent_checkpoint_path=$ACTOR_CHECKPOINT \
        --actor

elif [ "$task" == "eval" ]; then
    # 只评估不训练：给了 --agnet_checkpoint_step 就会进入评估模式
    export XLA_PYTHON_CLIENT_PREALLOCATE=false
    export XLA_PYTHON_CLIENT_MEM_FRACTION=.1
    run_task $PY "$EXAMPLE_PATH/train_rlpd.py" "$@" \
        --exp_name=$EXPERIMENT_NAME \
        --classifier_checkpoint_step=$CLASSIFIER_CHECKPOINT \
        --agent_checkpoint_path=$ACTOR_CHECKPOINT \
        --agnet_checkpoint_step=$AGENT_CHECKPOINT_STEP \
        --eval_n_trajs=$EVAL_N_TRAJS \
        --actor

elif [ "$task" == "work" ]; then
    export XLA_PYTHON_CLIENT_PREALLOCATE=false
    export XLA_PYTHON_CLIENT_MEM_FRACTION=.1
    run_task $PY "$EXAMPLE_PATH/train_work.py" "$@" \
        --exp_name=$EXPERIMENT_NAME \
        --classifier_checkpoint_step=$CLASSIFIER_CHECKPOINT \
        --agent_checkpoint_path=$ACTOR_CHECKPOINT \
        --agnet_checkpoint_step=$AGENT_CHECKPOINT_STEP \
        --eval_n_trajs=1 \
        --actor

else
    echo "Unsupported task name: $task"
    echo "可选：data / train / demo / learner / actor / eval / work"
    exit 1
fi
