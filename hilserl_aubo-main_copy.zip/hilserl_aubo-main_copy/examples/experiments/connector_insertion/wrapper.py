import copy
import time
from franka_env.utils.rotations import euler_2_quat
from scipy.spatial.transform import Rotation as R
import numpy as np
import requests
from pynput import keyboard
import gymnasium as gym

from aubo_env.envs.aubo_env import auboEnv

class TaskEnv(auboEnv):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        self.should_grasp = False
        self.start_key_listener()

    def start_key_listener(self):
        # 键盘控制关闭夹爪
        def on_press(key):
            if str(key) == "Key.f2":
                self.should_grasp = True

        self.listener = keyboard.Listener(
            on_press=on_press)
        self.listener.start()

    def stop_key_listener(self):
        self.listener.stop()


    def go_to_reset(self, joint_reset=False, retreat=True):
        """
        Move to the rest position defined in base class.
        Add a small z offset before going to rest to avoid collision with object.
        """    
        # 退出力控
        self._update_currstate()
        self._stop_imp_control()
        self._set_robot_goal_speed(0.6)
        time.sleep(0.1)

        # # 沿工具坐标系y轴后退
        # pose = copy.deepcopy(self.currpos)
        # quat = pose[3:]
        # rotation = R.from_quat(quat)
        # p = np.array([0,0.05,0])
        # pt = rotation.as_matrix() @ p
        # pose[:3] += pt
        # self._send_target_pose(pose)

        # 沿基座坐标系x轴后退
        if retreat:
            pose = copy.deepcopy(self.currpos)
            p = np.array([-0.05,0,0])
            pose[:3] += p
            self._send_target_pose(pose)

        if self.randomreset:  # randomize reset position in xy plane
            reset_pose = self.config.TASK_INIT_POSE.copy()
            
            reset_pose[:3] += np.random.uniform(
                -self.config.RANDOM_XYZ_RANGE, self.config.RANDOM_XYZ_RANGE, (3,)
            )
            euler_random = self.config.TASK_INIT_POSE[3:].copy()
            euler_random += np.random.uniform(
                -self.config.RANDOM_RPY_RANGE, self.config.RANDOM_RPY_RANGE
            )            
            # euler_random[-1] += np.random.uniform(
            #     -self.random_rz_range, self.random_rz_range
            # )
            reset_pose[3:] = euler_random

            self._send_target_pose(reset_pose, speed=0.8, acce = 1.4)
        else:
            # 运动到任务起始点
            self._send_target_joints(self.config.TASK_INIT_JOINT, speed=0.8, acce = 1.4)

        self._start_imp_control()
        self._set_robot_goal_speed(0.4)
        time.sleep(0.1)