#!/bin/bash

#
# 强化学习集成脚本： 用法： bash run.sh --task=xxx
# 注意修改任务名称、任务文件夹、脚本绝对路径等参数
#

# 解析命令行参数  --task=XXX
while [[ "$#" -gt 0 ]]; do
    case $1 in
    --task=*) task="${1#*=}" ;;
    *)
        echo "Unknown parameter passed: $1"
        exit 1
        ;;
    esac
    shift
done

# 检查是否提供了 task_nake 参数
if [ -z "$task" ]; then
    echo "Error: --task parameter is required."
    exit 1
fi

################## some COMMON CONFIGS ##############
CONDA_ENV=/home/byd/miniconda3/envs/hilserl/bin/python

EXAMPLE_PATH=/home/byd/rl/hilserl_aubo/examples

# 实验（操作任务）名称，需要和mapping中的对应
EXPERIMENT_NAME=connector_insertion
EXPERIMENT_PATH=$EXAMPLE_PATH/experiments/connector_insertion

# 分类器训练加载哪个数据集文件夹
# 是str，可以添加后缀
CLASSIFIER_DATA_CHECKPOINT=2025-10-17

# 使用的分类器 classifier_ckpt/checkpoint_XXX
# 需要是int
CLASSIFIER_CHECKPOINT=200

# 示范轨迹文件夹路径，会加载改文件夹下所有的数据
DEMO_PATH=$EXPERIMENT_PATH/demo_data/2025-10-17

# 保存的agent、buffer文件夹
ACTOR_CHECKPOINT=2st_run

# wandb api key
WANDB_API_KEY_CLH=9812170b92a88b31961ca2624a268bee5f3d81e0

################## detail cmd ##################
cd $EXPERIMENT_PATH

# 根据条件判断执行
if [ "$task" == "data" ]; then
    $CONDA_ENV $EXAMPLE_PATH/record_success_fail.py "$@" \
        --exp_name=$EXPERIMENT_NAME

elif [ "$task" == "train" ]; then
    $CONDA_ENV $EXAMPLE_PATH/train_reward_classifier.py "$@" \
        --exp_name=$EXPERIMENT_NAME \
        --checkpoint_path=$CLASSIFIER_DATA_CHECKPOINT \
        --num_epochs=200

elif [ "$task" == "demo" ]; then
    $CONDA_ENV $EXAMPLE_PATH/record_demos.py "$@" \
        --exp_name=$EXPERIMENT_NAME \
        --classifier_checkpoint_step=$CLASSIFIER_CHECKPOINT \
        --successes_needed=10

elif [ "$task" == "learner" ]; then
    export WANDB_API_KEY=$WANDB_API_KEY_CLH
    export XLA_PYTHON_CLIENT_PREALLOCATE=false &&
        export XLA_PYTHON_CLIENT_MEM_FRACTION=.5 &&
        $CONDA_ENV $EXAMPLE_PATH/train_rlpd.py "$@" \
            --exp_name=$EXPERIMENT_NAME \
            --classifier_checkpoint_step=$CLASSIFIER_CHECKPOINT \
            --agent_checkpoint_path=$ACTOR_CHECKPOINT \
            --demo_path=$DEMO_PATH \
            --learner

# 训练actor
elif [ "$task" == "actor" ]; then
    # export WANDB_API_KEY=$WANDB_API_KEY_CLH
    export XLA_PYTHON_CLIENT_PREALLOCATE=false &&
        export XLA_PYTHON_CLIENT_MEM_FRACTION=.2 &&
        $CONDA_ENV $EXAMPLE_PATH/train_rlpd.py "$@" \
            --exp_name=$EXPERIMENT_NAME \
            --classifier_checkpoint_step=$CLASSIFIER_CHECKPOINT \
            --agent_checkpoint_path=$ACTOR_CHECKPOINT \
            --actor

# 测试actor
elif [ "$task" == "eval" ]; then
    # export WANDB_API_KEY=$WANDB_API_KEY_CLH
    export XLA_PYTHON_CLIENT_PREALLOCATE=false
    export XLA_PYTHON_CLIENT_MEM_FRACTION=.1
    $CONDA_ENV $EXAMPLE_PATH/train_rlpd.py "$@" \
        --exp_name=$EXPERIMENT_NAME \
        --classifier_checkpoint_step=$CLASSIFIER_CHECKPOINT \
        --agent_checkpoint_path=$ACTOR_CHECKPOINT \
        --agnet_checkpoint_step=450000 \
        --eval_n_trajs=100 \
        --actor

# 演示工作场景
elif [ "$task" == "work" ]; then
    # export WANDB_API_KEY=$WANDB_API_KEY_CLH
    export XLA_PYTHON_CLIENT_PREALLOCATE=false
    export XLA_PYTHON_CLIENT_MEM_FRACTION=.1
    $CONDA_ENV $EXAMPLE_PATH/train_work.py "$@" \
        --exp_name=$EXPERIMENT_NAME \
        --classifier_checkpoint_step=$CLASSIFIER_CHECKPOINT \
        --agent_checkpoint_path=$ACTOR_CHECKPOINT \
        --agnet_checkpoint_step=450000 \
        --eval_n_trajs=1 \
        --actor

else
    echo "Unsupported task name: $task"
    exit 1
fi
