import os
import jax
import jax.numpy as jnp
import numpy as np

from aubo_env.envs.wrappers import (
    Quat2EulerWrapper,
    SpacemouseIntervention,
    MultiCameraBinaryRewardClassifierWrapper,
    GripperKeepEnv
)

from aubo_env.envs.relative_env import RelativeFrame
from aubo_env.envs.aubo_env import DefaultEnvConfig
from aubo_env.camera.video_capture import VideoCaptureManager

from serl_launcher.wrappers.serl_obs_wrappers import SERLObsWrapper
from serl_launcher.wrappers.chunking import ChunkingWrapper

from experiments.config import DefaultTrainingConfig
from experiments.connector_insertion.wrapper import TaskEnv


deg2rad = np.pi/180.0
rad2deg = 180.0/np.pi

class EnvConfig(DefaultEnvConfig):
    ### 任务相关参数
    MAX_EPISODE_LENGTH: int = 200
    JOINT_RESET_PERIOD: int = 0
    
    ### 任务空间运动相关参数
    ACTION_SCALE = np.array([0.02, 0.02, 0.02, 0.05, 0.05, 0.05, 1.0])  # xyz+rpy+gripper
    
    TARGET_POSE = np.array([0.43294, -0.17822, 0.34191, -177.311*deg2rad, -2.100*deg2rad, -89.724*deg2rad])  # 目标位姿及其上下界，组成运动限制范围
    ABS_POSE_LIMIT_HIGH = TARGET_POSE + np.array([0.03, 0.01, 0.01, 0.2, 0.2, 0.5]) 
    ABS_POSE_LIMIT_LOW = TARGET_POSE - np.array([0.01, 0.01, 0.015, 0.2, 0.2, 0.5]) 
    RELATIVE_POSE_LIMIT_HIGH = np.array([0.2, 0.2, 0.5])
    RELATIVE_POSE_LIMIT_LOW = -np.array([0.2, 0.2, 0.5])

    RANDOM_RESET = False
    RANDOM_XYZ_RANGE = np.array([0.0, 0.005, 0.005])
    RANDOM_RZ_RANGE = np.array([0.1])
    RANDOM_RPY_RANGE = np.array([0.05, 0.05, 0.05])

    ### 机器人控制相关参数
    SERVER_URL: str = "http://127.0.0.1:5000/"  # 机器人控制器服务地址
    GRIPPER_SLEEP: float = 1.0
    
    ### 相机相关参数
    REALSENSE_CAMERAS: dict = {
        "camera1": {"serial_number": "218622275245", 
                    "dim": (1280, 720),
                    "exposure": 60000,
                    "fps": 30,},
    }
    IMAGE_CROP: dict[str, callable] = {
        "camera1": lambda img: img[250:500, 700:1000],  
    }
    DISPLAY_IMAGE: bool = True

    GRASP_POSE = np.array([0.60244, 0.25668, 0.35056, 
                            63.486* np.pi / 180,  0.00, 134.140* np.pi / 180])
    GRASP_JOINT = np.array([-63.34, -27.08, 128.31, 100.58, -46.82, 42.23]) * np.pi / 180

    VIA_POSE = np.array([0.56271, 0.09578, 0.21962, 
                            137.657* np.pi/180, -16.634* np.pi/180, 108.834* np.pi/180])
    VIA_JOINT = np.array([-77.27, 14.77, 111.56, 59.54, 24.66, 67.22])* np.pi/180

    TASK_INIT_POSE = np.array([0.42294, -0.17822, 0.34191, -177.311*deg2rad, -2.100*deg2rad, -89.724*deg2rad])
    TASK_INIT_JOINT = np.array([141.76, -2.95, -67.84, 21.82, -90.28, 141.62])* deg2rad

class TrainConfig(DefaultTrainingConfig):
    
    image_keys = ["camera1"]
    classifier_keys = ["camera1"]
    proprio_keys = ["tcp_pose", "tcp_vel", "tcp_force", "tcp_torque", "gripper_pose"]

    batch_size = 64
    buffer_period = 1000
    checkpoint_period = 3000
    steps_per_update = 50
    encoder_type = "resnet-pretrained"
    setup_mode = "single-arm-fixed-gripper"

    def get_environment(self, 
                        camera_manager =None,
                        fake_env=False, 
                        save_video=False, 
                        classifier=False, 
                        classifier_checkpoint_step=None,
                        classifier_checkpoint_path = None,
                        spacemouse_expert=None,
                        ):
        # 无输入则创建
        if not camera_manager and (not fake_env):
            camera_manager = VideoCaptureManager(verbose=True)
        
        env = TaskEnv(
            env_name = "connector_insertion",
            camera_manager = camera_manager,
            fake_env=fake_env,
            save_video=save_video,
            config=EnvConfig(),
        )
        env = GripperKeepEnv(env)  # 不涉及夹爪动作、控制，保持关闭
        if not fake_env:
            env = SpacemouseIntervention(env, expert=spacemouse_expert)
        env = RelativeFrame(env)
        env = Quat2EulerWrapper(env)
        env = SERLObsWrapper(env, proprio_keys=self.proprio_keys)
        env = ChunkingWrapper(env, obs_horizon=1, act_exec_horizon=None)

        """ 加载分类器、分类器返回值函数 """
        if classifier or classifier_checkpoint_step:
            from serl_launcher.networks.reward_classifier import load_classifier_func

            # 默认在运行路径下寻找分类器文件夹
            if not classifier_checkpoint_path:
                classifier_checkpoint_path = os.path.abspath("classifier_ckpt/")

            classifier = load_classifier_func(
                key = jax.random.PRNGKey(0),
                sample = env.observation_space.sample(),
                image_keys = self.classifier_keys,
                checkpoint_path = classifier_checkpoint_path,
                checkpoint_step = classifier_checkpoint_step,
            )
            def reward_func(obs):
                sigmoid = lambda x: 1 / (1 + jnp.exp(-x))

                # added check for z position to further robustify classifier, but should work without as well
                # return int(np.array(sigmoid(classifier(obs)) > 0.65 and obs['state'][0, 6] > 0.044))
                classifier_reward = sigmoid(classifier(obs))
                print(f"classifier reward: {classifier_reward}")
                return int(np.array(classifier_reward > 0.85))

            env = MultiCameraBinaryRewardClassifierWrapper(env, reward_func)

        return env
