#!/bin/bash

# 1. 激活 conda 环境
# 注意：在脚本中激活 conda 需要先 source 配置文件
source ~/miniconda3/etc/profile.d/conda.sh
conda activate hilserl

# 2. 将机器人环境路径加入 PYTHONPATH
export PYTHONPATH=$PYTHONPATH:/home/byd-czk/hilserl_aubo/serl_robot_infra

# 3. 打印当前路径信息（用于调试，可选）
echo "PYTHONPATH is set to: $PYTHONPATH"

# 4. 运行数据采集脚本
# 你可以根据需要修改参数
python /home/byd-czk/hilserl_aubo/examples/record_success_fail.py \
    --exp_name plug_assembly \
    --successes_needed 500
