export XLA_PYTHON_CLIENT_PREALLOCATE=false && \
export XLA_PYTHON_CLIENT_MEM_FRACTION=.1 && \

python ../../train_rlpd.py "$@" \
    --exp_name=plug_assembly \
    --classifier_checkpoint_step=200 \
    --agent_checkpoint_path=first_run \
    --agnet_checkpoint_step=207000 \
    --eval_n_trajs=10 \
    --actor \
