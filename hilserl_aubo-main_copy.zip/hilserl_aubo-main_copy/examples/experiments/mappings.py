# from experiments.ram_insertion.config import TrainConfig as RAMInsertionTrainConfig
# from experiments.usb_pickup_insertion.config import TrainConfig as USBPickupInsertionTrainConfig
# from experiments.object_handover.config import TrainConfig as ObjectHandoverTrainConfig
# from experiments.egg_flip.config import TrainConfig as EggFlipTrainConfig
# from experiments.connector_insertion.config import TrainConfig as ConnectorInsertionTrainConfig
from experiments.plug_assembly.config import TrainConfig as PlugAssemblyTrainConfig # 导入
from experiments.grasp_testing.config import TrainConfig as GraspTestingTrainConfig # 抓取任务（学习夹爪，7 维动作）

CONFIG_MAPPING = {
                # "ram_insertion": RAMInsertionTrainConfig,
                # "usb_pickup_insertion": USBPickupInsertionTrainConfig,
                # "object_handover": ObjectHandoverTrainConfig,
                # "egg_flip": EggFlipTrainConfig,
                # "connector_insertion": ConnectorInsertionTrainConfig,
                "plug_assembly": PlugAssemblyTrainConfig, 
                "grasp_testing": GraspTestingTrainConfig,
               }