import requests
import json
import numpy as np

# 目标服务器地址
SERVER_URL: str = "http://127.0.0.1:5000/"

# 发送数据函数
def send_data():
    try:
        while True:
            num = input("输入要执行的操作：")
            print(num)
            if num == "1":
                response = requests.post(SERVER_URL+"/start_imp")
                print(response.text)
            elif num == "2":
                response = requests.post(SERVER_URL+"/stop_imp")
                print(response.text)
            elif num == "3":
                response = requests.post(SERVER_URL+"/get_state").json()
                print(f"tcp_pos:{response['pose']}")
                print(f"tcp_vel:{response['vel']}")
                print(f"tcp_wrench:{response['force']}")  
                print(f"joint_torque:{response['torque']}")  
                print(f"joint_pos:{response['q']}") 
                print(f"joint_vel:{response['dq']}")
                print(f"gripper_pos:{response['gripper_pos']}")   
            elif num == "4":
                data = {"pose": [-0.51759, -0.07125, 0.26102, -177.152*np.pi/180, -2.686*np.pi/180, -87.175*np.pi/180]}
                response = requests.post(SERVER_URL+"/set_pose",json=data)
                print(response.text)   
            elif num == "5":
                joints = np.array([-7.26, 8.66, -65.53, 19.21, -88.18, 20.05])
                joints = joints*np.pi/180
                data = {"joints": joints.tolist()}
                response = requests.post(SERVER_URL+"/set_joints",json=data)
                print(response.text)                  
            elif num == "6":
                data = {"pos": 40}
                response = requests.post(SERVER_URL+"/set_gripper",json=data)
                print(response.text)
            elif num == "7":
                response = requests.post(SERVER_URL+"/close_gripper")
                print(response.text) 
            elif num == "8":
                response = requests.post(SERVER_URL+"/open_gripper")
                print(response.text)   
            elif num == "9":
                speed = 0.5
                data = {"speed": speed}
                response = requests.post(SERVER_URL+"/set_robot_goal_speed",json=data)
            elif num == "10":
                response = requests.post(SERVER_URL+"/start_mission")
                print(response.text)                 
                                                                           
    except requests.exceptions.RequestException as e:
        print("Connection failed:", e)

if __name__ == '__main__':
    # 示例数据
    send_data()
