"""
该文件启动一个在实时PC上运行的控制服务器, 该PC连接到aubo机器人。
请在screen中运行 python aubo_server.py。
"""
from flask import Flask, request, jsonify
import numpy as np
import time
import subprocess
from scipy.spatial.transform import Rotation as R
from absl import app, flags
import aubo_env.utils.general_func as gfunc
from aubo_env.controller.aubo_impedance_controller import auboImpedanceController
import signal
import sys

deg2rad = np.pi/180.0
rad2deg = 180.0/np.pi

# 命令行参数输入
FLAGS = flags.FLAGS
flags.DEFINE_string(
    "robot_ip", "192.168.25.100", "IP address of the franka robot's controller box"
)
flags.DEFINE_string(
    "gripper_port", "/dev/ttyUSB0", "Port of the robotiq gripper if being used"
)
flags.DEFINE_string(
    "gripper_type", "Robotiq", "Type of gripper to use: Robotiq, DH, or None"
)
flags.DEFINE_list(
    "reset_joint_target",
    '[-1.379, 0.471, -1.794, -0.2443, 1.414, 0.075]',
    "Target joint angles for the robot to reset to"
)
flags.DEFINE_string("flask_url", 
    "127.0.0.1",
    "URL for the flask server to run on."
)

def main(_):
    ROBOT_IP = FLAGS.robot_ip
    GRIPPER_PORT = FLAGS.gripper_port
    GRIPPER_TYPE = FLAGS.gripper_type
    RESET_JOINT_TARGET = FLAGS.reset_joint_target

    webapp = Flask(__name__)

    """Starts impedance controller"""
    robot_server = auboImpedanceController(
        robot_ip=ROBOT_IP,
        gripper_type=GRIPPER_TYPE,
        gripper_port=GRIPPER_PORT,
        reset_joint_target=RESET_JOINT_TARGET,
    )

    robot_server.start()

    # Route for starting control (力控 / 位姿伺服 由 control_mode 决定)
    @webapp.route("/start_imp", methods=["POST"])
    def start_impedance():
        robot_server.enable_control()
        return "Started control"

    # Route for stopping control
    @webapp.route("/stop_imp", methods=["POST"])
    def stop_impedance():
        robot_server.disable_control()
        return "Stopped control"

    # Route for getting all state information
    @webapp.route("/get_state", methods=["POST"])
    def get_state():
        return jsonify(
            {
                "pose": np.array(gfunc.pose_euler2quat(robot_server.current_pose)).tolist(),
                "vel": np.array(robot_server.current_vel).tolist(),
                "force": np.array(robot_server.current_wrench).tolist(),
                "torque": np.array(robot_server.current_joint_torque).tolist(),
                "joints": np.array(robot_server.current_joint_pos).tolist(),
                "gripper": robot_server.gripper_info,
            }
        )

    # Route for sending a pose command
    @webapp.route("/set_pose", methods=["POST"])
    def pose():
        pose = np.array(request.json["pose"])
        if pose.shape==(7,):
            pose_euler=gfunc.pose_quat2euler(pose.tolist())
        elif pose.shape==(6,):
            pose_euler=pose.tolist()
        else:
            print("Invalid pose shape")

        if robot_server.is_imp_control_ready():
            robot_server.target_pose = np.array(pose_euler)
        else:
            robot_server.robot.move_line(pose_euler)
            
        return "Sended a pose command"

    # Route for sending a joint command
    @webapp.route("/set_joints", methods=["POST"])
    def set_joints():
        """ falsk通讯，请求端会等待该服务端反馈，因此使用等待的movejoint """
        data = request.get_json()  # 获取整个 JSON 数据
        joints = np.array(data.get("joints"))
        robot_server.robot.move_joint(joints)
        return "Sended a joint command"
    
    # Route for moving the gripper
    @webapp.route("/set_gripper", methods=["POST"])
    def move_gripper():
        data = request.get_json()  # 获取整个 JSON 数据
        pos = int(data.get("pos"))
        pos = np.clip(pos,0,85)
        robot_server.gripper.setPosition_mm(pos)
        return "Moved gripper"

    # Route for closing the Gripper
    @webapp.route("/close_gripper", methods=["POST"])
    def close():
        robot_server.gripper.closeGripper()
        return "Closed gripper"

    # Route for opening the Gripper
    @webapp.route("/open_gripper", methods=["POST"])
    def open():
        robot_server.gripper.openGripper()
        return "Opened gripper"

    # Route for setting goal speed
    @webapp.route("/set_robot_goal_speed", methods=["POST"])
    def set_robot_goal_speed():
        data = request.get_json()  # 获取整个 JSON 数据
        speed = np.array(data.get("speed"))
        speed = np.clip(speed, 0, 1)
        robot_server.robot.set_global_speed(speed)
        return f"Set robot goal speed to {speed}"
    
    # 终止信号处理
    def signal_handler(sig, frame):
        gfunc.print_red('\n[AuboServer] User terminated the program')
        robot_server.stopit()
        # 控制线程是非 daemon：等它退出并完成"关伺服 + 对齐目标"，
        # 避免 stop 之后仍向机械臂下发旧目标（拖动时会触发关节突变报警）
        try:
            robot_server.join(timeout=3)
        except Exception:
            pass
        sys.exit(0)
    signal.signal(signal.SIGINT, signal_handler)

    webapp.run(host=FLAGS.flask_url)


if __name__ == "__main__":
    app.run(main)