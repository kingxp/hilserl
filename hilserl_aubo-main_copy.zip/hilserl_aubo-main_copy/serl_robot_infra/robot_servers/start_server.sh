#!/bin/bash
#
# aubo_server 一键启动 / 停止 / 查看状态（带日志自动落盘）
#
# 用法：
#   bash start_server.sh start     # 后台启动服务（robot_ip 用默认 192.168.25.100，无需传参）
#   bash start_server.sh status    # 查看是否在运行
#   bash start_server.sh stop      # 优雅停止（SIGINT）
#
# 特性：
#   - 宿主机执行会自动 docker exec 进 hilserl 容器重跑本脚本；已在容器内则直接运行
#   - robot_ip 不传参，使用 aubo_server.py 默认值（192.168.25.100）
#   - 日志写入本目录 logs/aubo_server_<时间戳>.log，并记录 PID
#
# 若容器名/挂载点不同，改下面四行即可。

DOCKER_CONTAINER=hilserl
HOST_MOUNT_PREFIX=/home/xupeng/xupeng/hilserl
CONTAINER_MOUNT_PREFIX=/root/hilserl
PY=python3

SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ---------------- 宿主机 -> 自动进容器重跑自己 ----------------
if [ ! -f /.dockerenv ] && command -v docker >/dev/null 2>&1; then
    case "$SELF_DIR" in
        "$HOST_MOUNT_PREFIX"*)
            CONT_DIR="$CONTAINER_MOUNT_PREFIX${SELF_DIR#$HOST_MOUNT_PREFIX}"
            ;;
        *)
            echo "[error] 脚本路径 $SELF_DIR 不在挂载点 $HOST_MOUNT_PREFIX 内"
            exit 1
            ;;
    esac
    echo "[docker] 在容器 $DOCKER_CONTAINER 内执行：$0 $*"
    if [ "${1:-start}" = "start" ]; then
        # 分离会话(detach)启动：前台 exec 会话一结束，其派生的服务子进程会被一起清理，
        # 必须让服务脱离 exec 会话才能常驻。
        docker exec -d "$DOCKER_CONTAINER" bash -c "cd '$CONT_DIR' && bash start_server.sh start"
        sleep 5
        exec docker exec "$DOCKER_CONTAINER" bash "$CONT_DIR/start_server.sh" status
    else
        exec docker exec "$DOCKER_CONTAINER" bash "$CONT_DIR/start_server.sh" "$@"
    fi
fi

# ---------------- 容器内实际逻辑 ----------------
LOG_DIR="$SELF_DIR/logs"
mkdir -p "$LOG_DIR"
PIDFILE="$LOG_DIR/aubo_server.pid"

server_pid() {
    [ -f "$PIDFILE" ] || return 1
    local pid
    pid="$(cat "$PIDFILE" 2>/dev/null)"
    if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
        echo "$pid"
        return 0
    fi
    rm -f "$PIDFILE"
    return 1
}

do_start() {
    # 先进入脚本目录，否则 aubo_server.py 的相对路径找不到（docker exec 默认 cwd 不是这里）
    cd "$SELF_DIR" || { echo "[error] 无法进入 $SELF_DIR"; exit 1; }

    if pid="$(server_pid)"; then
        echo "[aubo_server] 已在运行 (pid=$pid)，无需重复启动"
        echo "              日志: $LOG_DIR/$(ls -1t "$LOG_DIR"/aubo_server_*.log 2>/dev/null | head -1)"
        exit 0
    fi
    export PYTHONPATH="$SELF_DIR/.."
    local logfile="$LOG_DIR/aubo_server_$(date +%Y%m%d_%H%M%S).log"
    echo "[aubo_server] 启动中 ... (robot_ip 用默认值，如需指定请手动加 --robot_ip=xxx)"
    nohup env PYTHONPATH="$SELF_DIR/.." $PY aubo_server.py \
        > "$logfile" 2>&1 < /dev/null &
    echo $! > "$PIDFILE"
    sleep 2
    if pid="$(server_pid)"; then
        echo "[aubo_server] 已启动 (pid=$pid)"
        echo "  日志文件: $logfile"
        echo "  查看日志: tail -f $logfile"
    else
        echo "[aubo_server] 启动失败，请看日志:"
        tail -30 "$logfile"
        rm -f "$PIDFILE"
        exit 1
    fi
}

do_stop() {
    if pid="$(server_pid)"; then
        echo "[aubo_server] 发送 SIGINT 停止 (pid=$pid)"
        kill -INT "$pid"
        for _ in $(seq 1 10); do
            kill -0 "$pid" 2>/dev/null || break
            sleep 0.5
        done
        if kill -0 "$pid" 2>/dev/null; then
            echo "[aubo_server] 未退出，升级 SIGKILL"
            kill -9 "$pid"
        fi
        rm -f "$PIDFILE"
        echo "[aubo_server] 已停止"
    else
        echo "[aubo_server] 没有在运行"
    fi
}

do_status() {
    if pid="$(server_pid)"; then
        echo "[aubo_server] 运行中 (pid=$pid)"
        local latest_log
        latest_log="$(ls -1t "$LOG_DIR"/aubo_server_*.log 2>/dev/null | head -1)"
        echo "  最新日志: ${latest_log:-无}"
    else
        echo "[aubo_server] 未在运行"
    fi
}

case "${1:-start}" in
    start)  do_start ;;
    stop)   do_stop ;;
    status) do_status ;;
    *) echo "用法: bash start_server.sh [start|stop|status]" ;;
esac
