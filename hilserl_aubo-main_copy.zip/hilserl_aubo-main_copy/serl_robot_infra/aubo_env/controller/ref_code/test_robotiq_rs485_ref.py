"""对照测试：直接使用参考实现 GripperRobotiqRS485 驱动 Robotiq 夹爪。

用途：判断"夹爪不激活/不开合"到底是夹爪硬件问题，还是我们拷贝实现的问题。

说明：ref_code/GripperRobotIQ.py 引用的 BasicEndEffector 基类没有随仓库带过来，
      这里用一个 stub 基类补上（该参考类实际只用到 is_connected/logger），
      从而可以真正实例化并驱动它做开合测试。

运行（容器内）：
    cd /root/hilserl/hilserl_aubo-main/serl_robot_infra
    PYTHONPATH=/root/hilserl/hilserl_aubo-main/serl_robot_infra \
      python3 aubo_env/controller/ref_code/test_robotiq_rs485_ref.py
"""

import sys
import types

# ---- stub BasicEndEffector，使 GripperRobotIQ.py 能 import ----
_stub = types.ModuleType("aubo_env.controller.ref_code.BasicEndEffector")


class BasicEndEffector:
    def __init__(self, config=None, logger=None):
        self.is_connected = False
        self.logger = logger
        self.config = config or {}


_stub.BasicEndEffector = BasicEndEffector
sys.modules["aubo_env.controller.ref_code.BasicEndEffector"] = _stub

import time
from aubo_env.controller.ref_code.GripperRobotIQ import GripperRobotiqRS485


def dump(tag, g):
    s = g.read_status()
    print(f"{tag}: {s}")
    return s


def main():
    g = GripperRobotiqRS485(config={"port": "/dev/ttyUSB0", "timeout": 1.0})

    print("== connect()（内部走参考实现的激活流程）==")
    print("connect ->", g.connect())
    dump("init     ", g)

    print("== open() ==")
    print("open ->", g.open())
    time.sleep(1.5)
    dump("after open ", g)

    print("== close() ==")
    print("close ->", g.close())
    time.sleep(1.5)
    dump("after close", g)

    print("== goto(128) ==")
    print("goto ->", g.goto([128]))
    time.sleep(1.5)
    dump("after goto ", g)

    print("== 再次 open() ==")
    print("open ->", g.open())
    time.sleep(1.5)
    dump("after open2", g)

    g.disconnect()
    print("== done ==")


if __name__ == "__main__":
    main()
