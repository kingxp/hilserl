import socket
import time
import numpy as np
from typing import Any, Dict, List, Optional
from .BasicEndEffector import BasicEndEffector
import logging


class GripperTCPClient(BasicEndEffector):
    """AUBO TCP LUA 脚本方式控制的 Robotiq 2F-140 夹爪"""

    def __init__(self, config: dict, logger: Optional[logging.Logger] = None):
        """
        初始化末端执行器

        Args:
            config: 配置字典，包含以下可选键：
                - host: TCP 服务器地址（默认 "192.168.25.20"）
                - port: TCP 端口（默认 30000）
                - wait_response: 是否等待响应（默认 false）
                - tcp_offset: TCP 偏移 4x4 齐次变换矩阵（可选）
            logger: 日志记录器
        """
        super().__init__(config, logger)
        self.host = config.get("host", "192.168.25.20")
        self.port = config.get("port", 30000)
        self.logger = logger if logger else logging.getLogger(__name__)
        self.socket = None
        self.wait_response = config.get("wait_response", False)
        # 从配置读取 tcp_offset，若无则保持 None
        tcp_cfg = config.get("tcp_offset", None)
        if tcp_cfg is not None:
            self._tcp_offset_val = np.array(tcp_cfg, dtype=float).reshape(4, 4)
        else:
            self._tcp_offset_val = None

    @classmethod
    def from_params(cls, host: str, port: int, logger: logging.Logger = None, wait_response=False, tcp_offset: Optional[np.ndarray] = None):
        """
        通过具体参数创建 GripperTCPClient 实例

        Args:
            host: TCP 服务器地址
            port: TCP 端口
            logger: 日志记录器
            wait_response: 是否等待响应
            tcp_offset: TCP 偏移 4x4 齐次变换矩阵（可选）

        Returns:
            GripperTCPClient: 新的 TCP 夹爪控制实例
        """
        config = {
            "host": host,
            "port": port,
            "wait_response": wait_response,
        }
        if tcp_offset is not None:
            config["tcp_offset"] = tcp_offset
        return cls(config=config, logger=logger)

    @property
    def tcp_offset(self) -> Optional[np.ndarray]:
        """该夹爪实例的 TCP 偏移（4x4 齐次变换矩阵），未配置时返回 None"""
        if self._tcp_offset_val is None:
            self.logger.warning("TCP 偏移未配置，返回 None")
            return None
        return self._tcp_offset_val.copy()

    def connect(self):
        """连接到TCP服务器"""
        try:
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.socket.connect((self.host, self.port))
            if self.logger:
                self.logger.info(f"已连接到 {self.host}:{self.port}")
            self.activate()
            return True
        except Exception as e:
            if self.logger:
                self.logger.error(f"连接失败: {e}")
            return False

    def disconnect(self):
        """关闭连接"""
        if self.socket:
            self.socket.close()
            if self.logger:
                self.logger.info("连接已关闭")

    def send_command(self, command: str):
        """发送命令到服务器"""
        if not self.socket:
            self.logger.error("未连接到服务器，请先调用connect()方法")
            return False

        try:
            # 确保命令以换行符结尾（如果需要）
            if not command.endswith("\n"):
                command += "\n"

            self.socket.sendall(command.encode("utf-8"))
            self.logger.debug(f"已发送命令: {command.strip()}")
            time.sleep(2.0)

            # 等待并打印响应（如果有）
            if self.wait_response:
                try:
                    # 设置超时时间
                    self.socket.settimeout(2.0)
                    response = self.socket.recv(1024)
                    if response:
                        self.logger.info(
                            f"收到响应: {response.decode('utf-8').strip()}"
                        )
                except socket.timeout:
                    self.logger.info("未收到响应（超时）")
                except Exception as e:
                    self.logger.error(f"接收响应时出错: {e}")

            return True
        except Exception as e:
            self.logger.error(f"发送命令失败: {e}")
            return False

    def open(self, wait_time: float = 1.0):
        command = """
return function(api)\n\
    local _ENV = require('aubo').sched.select_robot(1)\n\
    local aubo = require(\'aubo\')\n\
    local sched = aubo.sched\n\
    local gripper_service = sched.jsonrpc.proxy('http://127.0.0.1:30500/jsonrpc')\n\
    gripper_service.gripperMove(9, '{"block":false,"braced_force":1.0,"clamping_force":50.0,"force_maintenance":false,"position":0.0,"rotation_angle":1.0,"rotation_torque":1.0,"rotation_velocity":1.0,"velocity":100.0}')\n\
end\n\
\r\n\r\n
"""
        ret = self.send_command(command)
        time.sleep(wait_time)  # 机械臂运行lua脚本时无法进行运动, 添加延迟
        return ret

    def close(self, wait_time: float = 1.0):
        command = """
return function(api)\n\
    local _ENV = require('aubo').sched.select_robot(1)\n\
    local aubo = require(\'aubo\')\n\
    local sched = aubo.sched\n\
    local gripper_service = sched.jsonrpc.proxy('http://127.0.0.1:30500/jsonrpc')\n\
    gripper_service.gripperMove(9, '{"block":false,"braced_force":1.0,"clamping_force":50.0,"force_maintenance":false,"position":100.0,"rotation_angle":1.0,"rotation_torque":1.0,"rotation_velocity":1.0,"velocity":100.0}')\n\
end\n\
\r\n\r\n
"""
        ret = self.send_command(command)
        time.sleep(wait_time)  # 机械臂运行lua脚本时无法进行运动, 添加延迟
        return ret

    def goTo(self, position, wait_time: float = 1.0):
        command = """
return function(api)\n\
    local _ENV = require('aubo').sched.select_robot(1)\n\
    local aubo = require(\'aubo\')\n\
    local sched = aubo.sched\n\
    local gripper_service = sched.jsonrpc.proxy('http://127.0.0.1:30500/jsonrpc')\n\
"""
        command += '    gripper_service.gripperMove(9, \'{"block":false,"braced_force":1.0,"clamping_force":50.0,"force_maintenance":false,"position":'
        command += "{}".format(position)
        command += ',"rotation_angle":1.0,"rotation_torque":1.0,"rotation_velocity":1.0,"velocity":100.0}\')\n'
        command += """
end\n\
\r\n\r\n
"""
        ret = self.send_command(command)
        time.sleep(wait_time)  # 机械臂运行lua脚本时无法进行运动, 添加延迟
        return ret

    def activate(self, wait_time: float = 2.0):
        command = """
return function(api)\n\
    local _ENV = require('aubo').sched.select_robot(1)\n\
    local aubo = require(\'aubo\')\n\
    local sched = aubo.sched\n\
    local gripper_service = sched.jsonrpc.proxy('http://127.0.0.1:30500/jsonrpc')\n\
    gripper_service.gripperConnect(9, true)\n\
end\n\
\r\n\r\n
"""
        ret = self.send_command(command)
        time.sleep(wait_time)  # 机械臂运行lua脚本时无法进行运动, 添加延迟
        return ret


class GripperURRTDEClient(BasicEndEffector):
    """
    通过UR的RTDE协议通讯控制Robotiq夹爪
    
    使用 ur_rtde 的 RTDEControlInterface 发送 URScript 脚本函数与夹爪通信。
    
    Attributes:
        rtde_c (rtde_control.RTDEControlInterface): UR RTDE 控制接口
    """

    def __init__(self, config: dict, logger: Optional[logging.Logger] = None):
        """
        初始化末端执行器
        
        Args:
            config: 配置字典，必须包含 'rtde_c' 键（rtde_control.RTDEControlInterface）
                    可选包含 'tcp_offset' 键，4x4 齐次变换矩阵
            logger: 日志记录器
        """
        import rtde_control
        from .robotiq_preamble import ROBOTIQ_PREAMBLE
        super().__init__(config, logger)
        self.rtde_c: rtde_control.RTDEControlInterface = config.get("rtde_c")
        self._ROBOTIQ_PREAMBLE = ROBOTIQ_PREAMBLE
        # 从配置读取 tcp_offset，若无则保持 None
        tcp_cfg = config.get("tcp_offset", None)
        if tcp_cfg is not None:
            self._tcp_offset_val = np.array(tcp_cfg, dtype=float).reshape(4, 4)
        else:
            self._tcp_offset_val = None

    @property
    def tcp_offset(self) -> Optional[np.ndarray]:
        """该夹爪实例的 TCP 偏移（4x4 齐次变换矩阵），未配置时返回 None"""
        if self._tcp_offset_val is None:
            self.logger.warning("TCP 偏移未配置，返回 None")
            return None
        return self._tcp_offset_val.copy()

    @classmethod
    def from_rtde(cls, rtde_c, logger: Optional[logging.Logger] = None):
        """
        通过 RTDEControlInterface 直接创建 GripperURRTDEClient 实例
        
        Args:
            rtde_c: UR RTDE 控制接口
            logger: 日志记录器
            
        Returns:
            GripperURRTDEClient: 新的夹爪控制实例
        """
        config = {"rtde_c": rtde_c}
        return cls(config=config, logger=logger)

    # ------------------------------------------------------------------ #
    # 内部辅助方法
    # ------------------------------------------------------------------ #

    def _call(self, script_name: str, script_function: str) -> bool:
        """
        发送自定义 URScript 脚本函数到 UR 控制器
        
        Args:
            script_name: 脚本名称（用于标识）
            script_function: 脚本函数内容
            
        Returns:
            bool: 命令是否成功
        """
        return self.rtde_c.sendCustomScriptFunction(
            "ROBOTIQ_" + script_name,
            self._ROBOTIQ_PREAMBLE + script_function
        )

    # ------------------------------------------------------------------ #
    # BasicEndEffector 抽象方法实现
    # ------------------------------------------------------------------ #

    def connect(self) -> bool:
        """
        连接并激活夹爪
        
        Returns:
            bool: 连接是否成功
        """
        self.is_connected = self.activate()
        return self.is_connected

    def disconnect(self) -> None:
        """断开夹爪连接"""
        self.is_connected = False
        if self.logger:
            self.logger.info("夹爪已断开连接")

    def open(self) -> bool:
        """
        打开夹爪（张开到最大位置）
        
        Returns:
            bool: 操作是否成功
        """
        return self._call("OPEN", "rq_open_and_wait()")

    def close(self) -> bool:
        """
        关闭夹爪（闭合到最小位置）
        
        Returns:
            bool: 操作是否成功
        """
        return self._call("CLOSE", "rq_close_and_wait()")

    def goto(self, position: List[float]) -> bool:
        """
        控制夹爪移动到指定位置
        
        Args:
            position: 目标位置 [pos_in_mm] 或 [pos_in_mm, speed, force]
                      - pos_in_mm: 位置（毫米）
                      - speed: 速度百分比 [0-100]（可选）
                      - force: 力百分比 [0-100]（可选）
        
        Returns:
            bool: 操作是否成功
        """
        pos_in_mm = position[0]
        return self._call("MOVE", "rq_move_and_wait_mm(" + str(pos_in_mm) + ")")

    # ------------------------------------------------------------------ #
    # Robotiq 扩展控制方法
    # ------------------------------------------------------------------ #

    def activate(self) -> bool:
        """
        激活夹爪。激活过程需要约 5 秒。
        
        Returns:
            bool: 激活是否成功
        """
        ret = self._call("ACTIVATE", "rq_activate()")
        time.sleep(3)  # HACK
        return ret

    def set_speed(self, speed: int) -> bool:
        """
        设置夹爪运动速度
        
        Args:
            speed: 速度百分比 [0-100]
            
        Returns:
            bool: 操作是否成功
        """
        return self._call("SET_SPEED", "rq_set_speed_norm(" + str(speed) + ")")

    def set_force(self, force: int) -> bool:
        """
        设置夹爪夹持力
        
        Args:
            force: 力百分比 [0-100]
            
        Returns:
            bool: 操作是否成功
        """
        return self._call("SET_FORCE", "rq_set_force_norm(" + str(force) + ")")


class GripperRobotiqRS485(BasicEndEffector):
    """
    通过 RS485/Modbus RTU 协议控制 Robotiq 2F 夹爪
    
    使用串口 Modbus RTU 协议与夹爪通信，基于 Robotiq 2F-85/2F-140。
    
    Attributes:
        serial (serial.Serial): 串口对象
        slave_id (int): Modbus 从站 ID，默认 9
    """

    OUTPUT_REG_START = 0x03E8   # 1000
    INPUT_REG_START  = 0x07D0   # 2000

    def __init__(self, config: dict, logger: Optional[logging.Logger] = None):
        """
        初始化夹爪
        
        Args:
            config: 配置字典，包含串口参数等
                - port: 串口端口，如 '/dev/ttyUSB0'
                - baudrate: 波特率，默认 115200
                - slave_id: Modbus 从站 ID，默认 9
                - timeout: 超时时间，默认 1.0
            logger: 日志记录器
        """
        super().__init__(config, logger)

        import serial
        self._serial_module = serial
        self.serial = None
        self.slave_id = config.get('slave_id', 9)
        self.port = config.get('port', '/dev/ttyUSB0')
        self.baudrate = config.get('baudrate', 115200)
        self.timeout = config.get('timeout', 1.0)
        self._activated = False

        # 从配置读取 tcp_offset，若无则保持 None
        tcp_cfg = config.get("tcp_offset", None)
        if tcp_cfg is not None:
            self._tcp_offset_val = np.array(tcp_cfg, dtype=float).reshape(4, 4)
        else:
            self._tcp_offset_val = None

    @property
    def tcp_offset(self) -> Optional[np.ndarray]:
        """该夹爪实例的 TCP 偏移（4x4 齐次变换矩阵），未配置时返回 None"""
        if self._tcp_offset_val is None:
            self.logger.warning("TCP 偏移未配置，返回 None")
            return None
        return self._tcp_offset_val.copy()

    # ------------------------------------------------------------------ #
    # Modbus 通信底层（静态方法）
    # ------------------------------------------------------------------ #

    @staticmethod
    def _crc16_modbus(data: bytes) -> int:
        """计算 Modbus CRC16 校验码"""
        crc = 0xFFFF
        for byte in data:
            crc ^= byte
            for _ in range(8):
                if crc & 0x0001:
                    crc = (crc >> 1) ^ 0xA001
                else:
                    crc >>= 1
        return crc

    @staticmethod
    def _build_modbus_frame(slave_id: int, func_code: int, data: bytes) -> bytes:
        """构建 Modbus RTU 帧（含 CRC）"""
        frame = bytes([slave_id, func_code]) + data
        crc = GripperRobotiqRS485._crc16_modbus(frame)
        return frame + crc.to_bytes(2, byteorder='little')

    # ------------------------------------------------------------------ #
    # 通信底层
    # ------------------------------------------------------------------ #

    def _send_frame(self, frame: bytes) -> bytes:
        """发送帧并返回完整响应（含CRC）"""
        if not self.serial or not self.serial.is_open:
            raise RuntimeError("串口未打开")

        self.serial.reset_input_buffer()
        if self.logger and self.logger.isEnabledFor(logging.DEBUG):
            self.logger.debug(f"发送帧: {frame.hex().upper()}")

        self.serial.write(frame)
        time.sleep(0.05)

        response = b''
        start_time = time.time()
        while time.time() - start_time < self.timeout:
            if self.serial.in_waiting > 0:
                chunk = self.serial.read(self.serial.in_waiting)
                response += chunk
                if len(response) >= 8:
                    if response[0] == self.slave_id and response[1] == 0x10:
                        if self.logger and self.logger.isEnabledFor(logging.DEBUG):
                            self.logger.debug(f"完整写响应: {response.hex().upper()}")
                        return response
                    elif response[0] == self.slave_id and response[1] in (0x03, 0x04):
                        byte_count = response[2]
                        expected_len = 3 + byte_count + 2
                        if len(response) >= expected_len:
                            if self.logger and self.logger.isEnabledFor(logging.DEBUG):
                                self.logger.debug(f"完整读响应: {response.hex().upper()}")
                            return response
            time.sleep(0.01)

        if self.logger:
            self.logger.debug(f"响应超时，已收 {len(response)} 字节")
        return b''

    def _write_multiple_registers(self, address: int, values: List[int]) -> bool:
        """FC16 写多个寄存器，返回是否成功"""
        byte_data = b''.join(v.to_bytes(2, 'big') for v in values)
        data = (address.to_bytes(2, 'big') +
                len(values).to_bytes(2, 'big') +
                (len(byte_data)).to_bytes(1, 'big') +
                byte_data)
        frame = self._build_modbus_frame(self.slave_id, 0x10, data)
        resp = self._send_frame(frame)
        if len(resp) < 8:
            return False
        return resp[0] == self.slave_id and resp[1] == 0x10

    def _read_input_registers(self, address: int, count: int = 3) -> Optional[bytes]:
        """FC04 读输入寄存器，返回数据字节（不含CRC）"""
        data = address.to_bytes(2, 'big') + count.to_bytes(2, 'big')
        frame = self._build_modbus_frame(self.slave_id, 0x04, data)
        resp = self._send_frame(frame)
        if len(resp) < 5 or resp[0] != self.slave_id or resp[1] != 0x04:
            return None
        byte_count = resp[2]
        if len(resp) < 3 + byte_count + 2:
            return None
        return resp[3:3+byte_count]

    # ------------------------------------------------------------------ #
    # 核心功能
    # ------------------------------------------------------------------ #

    def _send_auto_release(self, direction: int = 1) -> bool:
        """发送自动释放命令（direction: 0=闭合, 1=张开）"""
        byte0 = 0x01 | 0x02 | (direction << 1)   # rACT=1, rATR=1, rARD=direction
        reg0 = (byte0 << 8) | 0x00
        if self.logger:
            self.logger.info(f"发送自动释放 (方向: {'张开' if direction else '闭合'})")
        return self._write_multiple_registers(self.OUTPUT_REG_START, [reg0, 0x0000, 0x0000])

    def _activate(self) -> bool:
        """激活流程：自动释放 → 清除rACT → 设置rACT → 等待2秒"""
        # 1. 发送自动释放（张开方向）复位内部状态
        if self.logger:
            self.logger.info("发送自动释放以复位...")
        if not self._send_auto_release(direction=1):
            self.logger.warning("自动释放发送失败，继续尝试")
        time.sleep(2)

        # 2. 清除 rACT
        if self.logger:
            self.logger.info("清除 rACT...")
        if not self._write_multiple_registers(self.OUTPUT_REG_START, [0, 0, 0]):
            self.logger.error("清除 rACT 失败")
            return False
        time.sleep(0.2)

        # 3. 设置 rACT=1
        if self.logger:
            self.logger.info("设置 rACT=1...")
        if not self._write_multiple_registers(self.OUTPUT_REG_START, [0x01, 0x00, 0x00]):
            self.logger.error("设置 rACT 失败")
            return False

        # 4. 等待激活生效
        if self.logger:
            self.logger.info("等待 2 秒使激活生效...")
        time.sleep(2)

        self._activated = True
        if self.logger:
            self.logger.info("激活完成（假定）")
        return True

    def _send_go_to(self, position: int, speed: int = 0xFF, force: int = 0xFF) -> bool:
        """发送 GoTo 命令并等待运动完成"""
        reg0 = (0x09 << 8) | 0x00          # rACT=1, rGTO=1
        reg1 = (0x00 << 8) | position
        reg2 = ((speed & 0xFF) << 8) | (force & 0xFF)
        if not self._write_multiple_registers(self.OUTPUT_REG_START, [reg0, reg1, reg2]):
            return False
        return self._wait_motion_complete()

    def _wait_motion_complete(self, timeout: float = 5.0) -> bool:
        """等待运动完成（位置稳定或gOBJ非零）"""
        start = time.time()
        last_pos = -1
        stable_count = 0
        while time.time() - start < timeout:
            data = self._read_input_registers(self.INPUT_REG_START, 3)
            if data and len(data) >= 6:
                byte0 = data[0]
                byte4 = data[4]
                gGTO = (byte0 >> 3) & 0x01
                gOBJ = (byte0 >> 2) & 0x03
                if gOBJ != 0:
                    return True
                if gGTO == 0:
                    return True
                if byte4 == last_pos:
                    stable_count += 1
                    if stable_count >= 3:
                        return True
                else:
                    stable_count = 0
                    last_pos = byte4
            time.sleep(0.1)
        return False

    # ------------------------------------------------------------------ #
    # BasicEndEffector 抽象方法实现
    # ------------------------------------------------------------------ #

    def connect(self) -> bool:
        """连接串口并激活夹爪"""
        if self.is_connected:
            return True
        try:
            self.serial = self._serial_module.Serial(
                port=self.port,
                baudrate=self.baudrate,
                bytesize=8,
                parity='N',
                stopbits=1,
                timeout=self.timeout
            )
            if not self.serial.is_open:
                return False
            if self.logger:
                self.logger.info(f"串口 {self.port} 打开成功")
            if not self._activate():
                self.disconnect()
                return False
            self.is_connected = True
            return True
        except Exception as e:
            if self.logger:
                self.logger.error(f"连接异常: {str(e)}")
            return False

    def disconnect(self) -> None:
        """关闭串口并断开连接"""
        if self.serial and self.serial.is_open:
            self.serial.close()
        self.is_connected = False
        self._activated = False

    def open(self) -> bool:
        """张开夹爪"""
        if not self.is_connected:
            return False
        return self._send_go_to(0, 0xFF, 0xFF)

    def close(self) -> bool:
        """闭合夹爪"""
        if not self.is_connected:
            return False
        return self._send_go_to(255, 0xFF, 0xFF)

    def goto(self, position: List[float]) -> bool:
        """
        移动到指定位置
        
        Args:
            position: [pos] 或 [pos, speed, force]
                      - pos: 位置 0~255
                      - speed: 速度 0~255（可选）
                      - force: 力 0~255（可选）
        
        Returns:
            bool: 操作是否成功
        """
        if not self.is_connected or not position:
            return False
        pos = int(round(max(0, min(255, position[0]))))
        speed = 0xFF
        force = 0xFF
        if len(position) >= 3:
            speed = int(round(max(0, min(255, position[1]))))
            force = int(round(max(0, min(255, position[2]))))
        return self._send_go_to(pos, speed, force)

    # ------------------------------------------------------------------ #
    # 扩展方法
    # ------------------------------------------------------------------ #

    def read_status(self) -> Optional[Dict[str, int]]:
        """读取并解析夹爪状态（调试用）"""
        data = self._read_input_registers(self.INPUT_REG_START, 3)
        if not data or len(data) < 6:
            return None
        return {
            'gACT': data[0] & 0x01,
            'gGTO': (data[0] >> 3) & 0x01,
            'gSTA': (data[0] >> 4) & 0x03,
            'gOBJ': (data[0] >> 2) & 0x03,
            'fault': data[2],
            'pos_echo': data[3],
            'actual_pos': data[4],
            'current': data[5],
        }
