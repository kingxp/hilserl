import logging
from abc import ABC, abstractmethod
from contextlib import contextmanager
import math
import numpy as np
from typing import Any, Dict, List, Optional, Tuple
import time

#本地模块导入

# 第三方模块导入
import pyaubo_sdk

#测试
# python -m environment.robot.AUBORobotBasic


class AUBORobotBasic():
    def __init__(self, config: dict, logger: Optional[logging.Logger] = None):
        """
        AUBO机器人控制器

        :param config: 配置字典，包含ip_address, port, gripper_port等参数
        :param logger: 日志记录器
        """
        self.logger = logger if logger else logging.getLogger(__name__)

        #机械臂基本配置参数
        self.ip_address = config["ip_address"]
        self.port = int(config.get("port", 30004))
        self.eef_cfg = config.get("eef", {})
        self.username = config.get("username", "aubo")
        self.password = config.get("password", "123456")

        # 机械臂接口
        self.rpc_client = None
        self.robot_interface = None
        self.motion_control = None
        self.robot_config = None
        self.robot_algorithm = None

        # 速度参数
        self.joint_speed = config.get("joint_speed", 80 * (math.pi / 180)) # rad/s
        self.joint_acceleration = config.get("joint_acceleration", 60 * (math.pi / 180)) # rad/s²
        self.linear_speed = config.get("linear_speed", 0.30)  # 米/秒
        self.linear_acceleration = config.get("linear_acceleration", 0.30)  # 米/秒²

        #伺服控制参数   在aubo中，暂时不可用，无需配置
        self.servo_joint_speed = config.get("servo_joint_speed", 1)
        self.servo_joint_acceleration = config.get("servo_joint_acceleration", 0.2)
        self.servo_lookahead_time = config.get("servo_lookahead_time", 0.1)
        self.servo_gain = config.get("servo_gain", 300.0)
        

    def connect(self) -> bool:
        """
        连接机器人和末端执行器（夹爪/吸盘）
        
        初始化RPC客户端，连接AUBO机器人，登录并获取机器人控制接口。
        
        Returns:
            bool: 连接成功返回True，失败返回False
        """
        try:
            # 初始化RPC客户端
            self.rpc_client = pyaubo_sdk.RpcClient()
            self.rpc_client.setRequestTimeout(1000)  # 设置RPC超时

            # 连接RPC服务
            self.rpc_client.connect(self.ip_address, self.port)

            if not self.rpc_client.hasConnected():
                self.logger.error("RPC客户端连接失败")
                return False

            # 登录机器人
            self.rpc_client.login(self.username, self.password)

            # 获取机器人接口
            robot_names = self.rpc_client.getRobotNames()
            if not robot_names:
                self.logger.error("未找到机器人")
                return False

            self.robot_interface = self.rpc_client.getRobotInterface(robot_names[0])
            self.motion_control = self.robot_interface.getMotionControl()
            self.robot_config = self.robot_interface.getRobotConfig()
            self.robot_algorithm = self.robot_interface.getRobotAlgorithm()

            # 设置速度和加速度
            self.motion_control.setSpeedFraction(0.75)


            if self.logger:
                self.logger.info(f"机器人连接成功: {robot_names[0]}")
            return True

        except Exception as e:
            if self.logger:
                self.logger.error(f"连接过程中发生错误: {e}")
            return False

    def disconnect(self) -> None:
        """
        断开机器人连接
        
        退出登录并断开RPC客户端连接。
        """
        try:
            if self.rpc_client:
                self.rpc_client.logout()
                self.rpc_client.disconnect()
                self.logger.info("机器人断开连接")

        except Exception as e:
            if self.logger:
                self.logger.error(f"断开连接时发生错误: {e}")


    def moveLine(self, tcp_pose: List[float], tcp_speed: float = None, 
              tcp_acc: float = None) -> bool:
        """
        直线运动
        
        Args:
            tcp_pose: 目标位姿 [x, y, z, rx, ry, rz]
            tcp_speed: 运动速度 (m/s)
            tcp_acc: 加速度 (m/s^2)
        """
        
        try:

            # 位姿比较：前三位(x,y,z)直接比较，后三位(欧拉角)需要处理角度跳变问题
            current_pose = np.array(self.get_tcp_pose())
            target_pose = np.array(tcp_pose)
            
            # 位置部分：直接比较
            pos_diff = np.abs(current_pose[:3] - target_pose[:3])
            # 角度部分：处理 -π 到 π 的跳变
            angle_diff = np.abs(current_pose[3:] - target_pose[3:])
            angle_diff = np.minimum(angle_diff, 2 * np.pi - angle_diff)  # 处理跳变
            
            if (pos_diff.sum() + angle_diff.sum()) < 1e-4:
                self.logger.info("直线运动到当前相同姿态, 跳过")
                return True
            
            #默认参数处理
            local_linear_speed = tcp_speed if tcp_speed is not None else self.linear_speed
            local_linear_acceleration = (
                tcp_acc if tcp_acc is not None else self.linear_acceleration
            )

            #发送指令
            result = self.motion_control.moveLine(
                tcp_pose, local_linear_acceleration, local_linear_speed, 0.0, 0.0
            )
            
            if result != 0:
                self.logger.error(f"直线运动指令发送失败，错误码为: {result}")
                return False
            
            # 阻塞
            ret = self.wait_arrival()

            if ret == 0:
                self.logger.info("直线运动成功")
                return True
            else:
                self.logger.error(f"直线运动失败，错误码为: {ret}")
                return False
        except Exception as e:
            self.logger.error(f"直线运动失败，抛出错误: {e}")
            return False

    def moveJoint(self, joint_positions: List[float], joint_speed: float = None, 
              joint_acc: float = None, )->bool:
        """
        关节运动
        
        Args:
            joint_positions: 目标关节角度 [j1, j2, j3, j4, j5, j6] (rad)
            joint_speed: 关节运动速度 (rad/s)，未指定时使用初始化时的参数
            joint_acc: 加速度 (rad/s^2)，未指定时使用初始化时的参数
        """
        
        try:
            # 获取当前关节角度
            current_joints = self.get_joint_positions()

            # 检查是否已经接近目标
            if abs(np.array(current_joints) - np.array(joint_positions)).sum() < 1e-4:
                self.logger.info("关节运动到当前相同位置, 跳过")
                return True

            # 使用指定参数，若未指定则使用初始化时的参数
            local_joint_speed = joint_speed if joint_speed is not None else self.joint_speed
            local_joint_acc = joint_acc if joint_acc is not None else self.joint_acceleration

            # 执行关节空间运动
            self.motion_control.setSpeedFraction(0.75)
            result = self.motion_control.moveJoint(
                joint_positions,  # 目标关节角度
                local_joint_acc,  # 关节加速度
                local_joint_speed,  # 关节速度
                0.0,  # blend_radius
                0.0,  # 运动时间
            )
            
            if result != 0:
                self.logger.error(f"关节运动指令发送失败，错误码为: {result}")
                return False

            # 等待运动完成
            ret = self.wait_arrival()

            if ret == 0:
                self.logger.info("关节运动成功")
                return True
            else:
                self.logger.error(f"关节运动失败，错误码为: {ret}")
                return False

        except Exception as e:
            self.logger.error(f"关节运动失败: {e}")
            return False

    def servoJoint(self, 
                   joint_positions: List[float], 
                   dt: float = 0.01, )->bool:
        """
        关节伺服控制的单次控制转发，用于统一伺服控制接口，并添加控制错误代码报错
        
        Args:
            joint_positions: 目标关节角度 [j1, j2, j3, j4, j5, j6] (rad)
            joint_speed: 关节运动速度 (rad/s)
            joint_acc: 加速度 (rad/s^2)
            dt: 时间步 (s，默认0.01)
            lookahead_time: 前向时间 (s，默认0.1)
            gain:增益 (默认300.0)
        """
        result = self.motion_control.servoJoint(
            joint_positions,    # joint positions
            self.servo_joint_acceleration,      # Velocity
            self.servo_joint_speed,        # Acceleration  
            dt,    # Time duration
            self.servo_lookahead_time,   # Lookahead time
            self.servo_gain             # Gain
        )
        if result != 0:
            self.logger.error(f"关节伺服控制失败: 错误代码{result}")
            return False
        return True
       

    def wait_arrival(self):
        max_retry_count = 20
        cnt = 0

        # 接口调用: 获取当前的运动指令 ID
        exec_id = self.motion_control.getExecId()

        # 等待机械臂开始运动
        while exec_id == -1:
            if cnt > max_retry_count:
                return -1
            time.sleep(0.05)
            cnt += 1
            exec_id = self.motion_control.getExecId()

        # 等待机械臂运动完成
        while self.motion_control.getExecId() != -1:
            time.sleep(0.05)

        return 0
    
    def setServoMode(self, servo: bool = False, mode: str = "joint"):
        """
        设置伺服模式
        
        Args:
            servo: 是否开启伺服模式 (默认False)
            mode: 伺服模式类型，"joint"或"line" (默认"joint")
        
        Returns:
            bool: 设置成功返回True，超时或失败返回False
        """
        
        self.motion_control.setServoMode(servo)
        i = 0
        while not (self.motion_control.isServoModeEnabled() == servo):
            i += 1
            if i > 20:
                if self.logger:
                    self.logger.error(
                        f"Servo模式切换失败，当前伺服状态: {self.motion_control.isServoModeEnabled()}"
                    )
                return False
            time.sleep(0.05)

        return True

    def servoLine(self, tcp_pose: List[float], dt: float = 0.01) -> bool:
        """
        位姿伺服控制（未实现）
        
        AUBO暂时不支持servoLine接口，调用时抛出NotImplementedError。
        
        Raises:
            NotImplementedError: 始终抛出，表示该功能未实现
        """
        raise NotImplementedError("AUBO暂不支持servoLine位姿伺服控制")

    def forward_kinematics(self, joint_positions: List[float])->List[float]:
        """
        正向运动学
        
        使用AUBO SDK的正向运动学接口，将关节角度转换为TCP位姿。
        
        Args:
            joint_positions: 关节角度 [j1, j2, j3, j4, j5, j6] (rad)
        
        Returns:
            List[float]: TCP位姿 [x, y, z, rx, ry, rz]
        """
        fk_result = self.robot_interface.getRobotAlgorithm().forwardKinematics(joint_positions)
        return fk_result[0]

    def inverse_kinematics(self, tcp_pose: List[float], current_joints: List[float] = None) -> Tuple[Optional[List[float]], int]:
        """
        逆向运动学求解
        
        统一返回元组 (关节角度解, 错误码)，调用者根据错误码自主处理。
        适用于批量调用需要频繁重试的场景。
        
        Args:
            tcp_pose: 目标位姿 [x, y, z, rx, ry, rz]
            current_joints: 当前关节角度 [j1, j2, j3, j4, j5, j6] (rad)
                           为None时自动调用get_joint_positions()获取
        
        Returns:
            Tuple[Optional[List[float]], int]: (关节角度解, 错误码)
                - 成功: (List[float], 0)
                - 失败: (None, 错误码)
                
            错误码说明:
                0:  正常（求解成功）
                -1: 无解（目标位姿不可达，或机器人处于奇异性）
                -2: 输入参数无效（位姿格式错误、关节角度越界等）
                -3: SDK内部错误/异常（网络超时、SDK调用失败等）
        """
        try:
            # 参数有效性检查
            if tcp_pose is None or len(tcp_pose) < 6:
                self.logger.error("逆运动学计算失败：目标位姿无效")
                return None, -2

            if current_joints is None:
                current_joints = self.get_joint_positions()
            if current_joints is None or len(current_joints) < 6:
                self.logger.error("逆运动学计算失败：当前关节角度无效")
                return None, -2

            ik_result = self.robot_interface.getRobotAlgorithm().inverseKinematics(
                current_joints, 
                tcp_pose
            )
            
            # ik_result 格式为 (joint_angles_or_None, error_code)
            if ik_result[1] == 0 and ik_result[0] is not None:
                return list(ik_result[0]), 0
            elif ik_result[1] == -27:
                self.logger.error(f"目标点存在解析解，但均不满足选解条件，SDK错误码为: {ik_result[1]}")
                return None, -1
            else:
                self.logger.error(f"逆运动学计算失败，SDK错误码为: {ik_result[1]}")
                return None, -3
                
        except Exception as e:
            self.logger.error(f"逆运动学计算失败: {e}")
            return None, -3
        
        

    def get_joint_positions(self)->List[float]:
        """
        获取当前关节角度
        
        Returns:
            List[float]: 当前关节角度 [j1, j2, j3, j4, j5, j6] (rad)
        """
        return self.robot_interface.getRobotState().getJointPositions()


    def get_tcp_pose(self)->Optional[List[float]]:
        """
        获取当前TCP位姿
        
        Returns:
            Optional[List[float]]: 当前位姿 [x, y, z, rx, ry, rz]，失败时返回None
        """
        try:
            robot_state = self.robot_interface.getRobotState()
            tcp_pose = robot_state.getTcpPose()
            return tcp_pose
            
        except Exception as e:
            self.logger.error(f"Error getting TCP pose: {e}")
            return None

    def set_tcp_offset(self, tcp_offset: "np.ndarray") -> bool:
        """
        设置 TCP 偏移量
        
        将末端执行器偏移矩阵写入 AUBO SDK，使 FK/IK/get_tcp_pose/moveLine
        均以夹爪末端（TCP）为参考。
        
        Args:
            tcp_offset: 4x4 齐次变换矩阵，T_flange_to_tcp
            
        Returns:
            bool: 设置成功返回 True
        """
        try:
            # 从 4x4 矩阵提取平移和欧拉角
            from scipy.spatial.transform import Rotation
            xyz = tcp_offset[:3, 3].tolist()
            rpy = Rotation.from_matrix(tcp_offset[:3, :3]).as_euler('xyz').tolist()
            tcp_pose = xyz + rpy  # [x, y, z, roll, pitch, yaw]

            # 调用 AUBO SDK 设置 TCP 偏移（需确认 API 签名）
            result = self.robot_config.setTcpOffset(tcp_pose)
            if result != 0:
                self.logger.error(f"设置 TCP 偏移失败，错误码: {result}")
                return False
            self.logger.info(f"TCP 偏移已设置: {tcp_pose}")
            return True

        except Exception as e:
            self.logger.error(f"设置 TCP 偏移失败: {e}")
            return False


if __name__ == "__main__":
    """
    AUBORobotBasic 测试
    使用方式：python -m environment.robot.AUBORobotBasic
    
    测试内容：
    1. 加载配置文件
    2. 连接机械臂
    3. 获取当前关节角度
    4. 关节角度控制——运动到 home 位置
    5. 断开连接
    """
    import sys
    import os
    import yaml
    import logging

    # 查找配置文件（优先使用项目目录下的配置，否则使用默认路径）
    config_path = os.path.join(os.path.dirname(__file__), "aubo_i7.yaml")
    if not os.path.exists(config_path):
        config_path = "config/robot/aubo_i7.yaml"
    if not os.path.exists(config_path):
        print(f"错误：未找到配置文件 {config_path}")
        sys.exit(1)

    with open(config_path, "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)

    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger("aubo_test")

    robot = AUBORobotBasic(cfg, logger)
    robot.connect()


    # 获取当前关节角度
    joints = robot.get_joint_positions()
    logger.info(f"当前关节角度: {joints}")

    # 关节角度控制——运动到 home 位置
    # test_joints = joints.copy()
    # test_joints[5] += 0.5
    # logger.info(f"关节运动到: {test_joints}")
    # robot.moveJoint(test_joints, joint_speed=0.5)
    # logger.info("关节运动完成")
    # time.sleep(2)
    # logger.info(f"关节返回: {joints}")
    # robot.moveJoint(joints, joint_speed=0.5)
    # logger.info("关节运动完成")

    robot.setServoMode(True)
    cur_j = robot.get_joint_positions()
    target_j = cur_j.copy()
    target_j[5] += 0.5
    target_j[1] += 0.5
    target_j[2] -= 0.5
    target_j_list = []
    freq = 10
    iter_num = int(freq * 4)
    dt = 1/freq
 
    # ===== 位姿伺服测试(servoCartesian) =====
    # 读当前位姿 -> 计算一组位姿 -> 按固定频率执行4秒
    cur_pose = robot.get_tcp_pose()
    logger.info(f"当前TCP位姿: {cur_pose}")

    # servoCartesian 当前固件只有 pose 和 t 生效, a/v/lookahead_time/gain 被忽略
    # t = 连续调用 servoCartesian 的间隔时间(实测值), t 越小运动越快; 与 servo_dt 不一致就会走走停停
    # 200Hz(0.005) 实测返回错误码 2 = AUBO_QUEUE_FULL(规划队列已满, 该条指令被丢弃), 故降到 50Hz
    servo_dt = 0.02     # 下发周期(s) -> 50Hz
    servo_t = 0.02      # t: 必须与 servo_dt 一致
    amp = 0.13          # 往复幅度(m)
    period = 4.0        # 往复周期(s), 4秒走2个来回, 结束时回到原位
    pose_list = []
    for i in range(int(4.0 / servo_dt)):
        p = list(cur_pose)
        p[0] = cur_pose[0] + amp * math.sin(2 * math.pi * (i * servo_dt) / period)
        pose_list.append(p)

    gaps = []
    fail_cnt = 0
    last_t = time.time()
    for p in pose_list:
        now = time.time()
        gaps.append(now - last_t)
        last_t = now
        ret = robot.motion_control.servoCartesian(p, 0.8, 0.25, servo_t, 0.2, 200)
        if ret != 0:
            fail_cnt += 1
            if fail_cnt <= 10:
                logger.error(f"位姿伺服下发失败, 错误码: {ret}")
        time.sleep(servo_dt)

    logger.info(f"位姿伺服完成: 次数={len(gaps)} 失败={fail_cnt} "
                f"平均间隔={np.mean(gaps) * 1000:.2f}ms 最大间隔={np.max(gaps) * 1000:.2f}ms")

    robot.setServoMode(False)
    robot.moveJoint(cur_j)
    robot.disconnect()
