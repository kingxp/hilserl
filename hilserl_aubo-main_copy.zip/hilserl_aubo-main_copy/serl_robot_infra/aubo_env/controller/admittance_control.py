import sys
from pathlib import Path
# 获取当前文件的父目录的父目录（即 code 目录）
root_dir = Path(__file__).resolve().parent.parent
sys.path.append(str(root_dir))

import numpy as np
from scipy.spatial.transform import Rotation
import modern_robotics as mr
import aubo_env.controller.aubo_sdk_wripper as aubo_sdk_wripper
import time
from aubo_env.utils import filter
import aubo_env.force_sensor.KWForceSensor as KWForceSensor
import json
import threading
import math
from enum import Enum, auto
import os

class AdmittanceControl:
    def __init__(self, cycle_t, M=[1.0]*6, D=[20.0]*6, K=[10.0]*6):
        # 阻抗参数
        self.Mf = np.diag(M[:3])
        self.Df = np.diag(D[:3])
        self.Kf = np.diag(K[:3])
        self.Wf = np.diag([0.5, 0.5, 0.5])
        self.Mm = np.diag(M[3:])
        self.Dm = np.diag(D[3:])
        self.Km = np.diag(K[3:])
        self.Wm = np.diag([0.05, 0.05, 0.05])

        # 控制周期
        self.cycle_t = cycle_t
        self.collect_data = False

        # 启动系数
        self.count = 0
        self.count_num = 200
        self.ratio = 0

        # 目标力旋
        self.target_wrench = np.array([0, 0, -2, 0, 0, 0])
        self.wrench_switch = np.array([0, 0, 1, 0, 0, 0])

        # 目标位姿
        self.target_pose = [0.0]*6
        self.record_pose = [0.0]*6

        # 指令相关变量
        self.last_command = np.zeros(6,)
        self.last_pos_velo = np.zeros(3,)
        self.last_ori_velo = np.zeros(3,)
        self.last_ori_error = np.zeros(3,)
        self.last_ori_error_t = np.zeros(3,)
        
        # 上一周期力
        self.last_actual_force = np.zeros(3,)

    # 更新MDKF参数
    def update_MDKF(self, M, D, K, W):
        self.Mf = np.diag(M[:3])
        self.Df = np.diag(D[:3])
        self.Kf = np.diag(K[:3])
        self.Wf = np.diag(W[:3])
        self.Mm = np.diag(M[3:])
        self.Dm = np.diag(D[3:])
        self.Km = np.diag(K[3:])
        self.Wm = np.diag(W[3:])

    # pos+rpy转齐次变换矩阵
    def pose2matrix(self, pose):
        pos = pose[:3]
        rpy = pose[3:]
        R = Rotation.from_euler('xyz',rpy).as_matrix()
        T = np.eye(4)
        T[:3,:3] = R
        T[:3,3] = pos
        return T

    # 齐次变换矩阵转pos+rpy
    def matrix2pose(self, T):
        pos = T[:3,3]
        R = T[:3,:3]
        rpy = Rotation.from_matrix(R).as_euler('xyz')
        pose = np.concatenate((pos, rpy))
        return pose

    # 齐次变换矩阵转运动旋量
    def matrix2twist(self, T):
        se3 = mr.MatrixLog6(T)
        twist = mr.se3ToVec(se3)
        return twist

    # 运动旋量转齐次变换矩阵
    def twist2matrix(self, twist):
        se3 = mr.VecTose3(twist)
        T = mr.MatrixExp6(se3)
        return T

    # 运动旋量转pos+rpy
    def twist2pose(self, twist):
        se3 = mr.VecTose3(twist)
        T = mr.MatrixExp6(se3)
        pos = T[:3,3]
        R = T[:3,:3]
        rpy = Rotation.from_matrix(R).as_euler('xyz')
        pose = np.concatenate((pos, rpy))
        return pose

    # 近零处理
    def near_zero(self, x_, e):
        x = x_.copy()
        n = len(x)
        for i in range(n):
            if abs(x[i]) < e[i]:
                x[i] = 0
        return x

    # 最值约束
    def limit(self, x_, min, max):
        x = x_.copy()
        n = len(x)
        for i in range(n):
            if x[i]<min[i]:
                x[i] = min[i]
            elif x[i]>max[i]:
                x[i] = max[i]
        return x

    # 轴角连续性处理
    def rotvec_continuous_processing(self, rpy, last_rpy):
        for i in range(3):
            if (rpy[i]-last_rpy[i]) > 350*np.pi/180:
                rpy[i] = rpy[i]-np.pi*int(abs(rpy[i]-last_rpy[i])/(175.0*np.pi/180.0))
            elif (rpy[i]-last_rpy[i]) < -350*np.pi/180:
                rpy[i] = rpy[i]+np.pi*int(abs(rpy[i]-last_rpy[i])/(175.0*np.pi/180.0))
        return rpy

    # 导纳控制
    def admittance_control(self, Initialized, target_pose_, actual_pose_, actual_wrench_, target_wrench_):
        target_pose = target_pose_.copy()
        actual_pose = actual_pose_.copy()
        actual_wrench = actual_wrench_.copy()
        target_wrench = target_wrench_.copy()
        last_command = self.last_command.copy()

        if not Initialized:
            self.last_command = np.array(actual_pose)
            self.last_pos_velo = np.zeros(3,)
            self.last_ori_velo = np.zeros(3,)
            self.last_ori_error = np.zeros(3,)
            last_command = self.last_command.copy()
            self.last_actual_force = np.zeros(3,)

        # 实际数据
        actual_pos = last_command[:3]
        actual_pos_velo = self.last_pos_velo.copy()
        actual_force = actual_wrench[:3]
        actual_ori = last_command[3:]
        actual_R = Rotation.from_euler('xyz',actual_ori)
        actual_ori_velo = self.last_ori_velo.copy()
        actual_moment = actual_wrench[3:]

        # 力传感器数据死区
        force_zero_zone = 10
        moment_zero_zone = 0.5
        for i in range(3):
            if actual_force[i]>force_zero_zone:
                actual_force[i] = actual_force[i]-force_zero_zone
            elif actual_force[i]<-force_zero_zone:
                actual_force[i] = actual_force[i]+force_zero_zone
            else:
                actual_force[i] = 0
            
            if actual_moment[i]>moment_zero_zone:
                actual_moment[i] = actual_moment[i]-moment_zero_zone
            elif actual_moment[i]<-moment_zero_zone:
                actual_moment[i] = actual_moment[i]+moment_zero_zone
            else:
                actual_moment[i] = 0    
 
        # 目标数据
        target_pos = np.array(target_pose[:3])
        target_force = target_wrench[:3]
        target_ori = np.array(target_pose[3:])
        target_R = Rotation.from_euler('xyz',target_ori)
        target_moment = target_wrench[3:]

        # 误差
        pos_error = actual_pos-target_pos
        ori_error = -actual_R.as_matrix() @ ((actual_R.inv()*target_R).as_rotvec())
        ori_error = self.rotvec_continuous_processing(ori_error, self.last_ori_error)
        self.last_ori_error = ori_error
        
        # 动态速度约束
        force_delta = np.zeros(3,)
        pos_velo_limit = np.zeros(3,)
        for i in range(3):
            force_delta[i] = abs(actual_force[i]-self.last_actual_force[i])
            pos_velo_limit[i] = 0.015*1/(1+force_delta[i]*100)

        # 位置导纳
        pos_acc = np.linalg.inv(self.Mf) @ (self.Wf @ (actual_force - target_force) - self.Df @ actual_pos_velo - self.Kf @ pos_error)
        pos_velo = self.last_pos_velo + pos_acc*self.cycle_t
        pos_velo = self.limit(pos_velo, -pos_velo_limit, pos_velo_limit)
        pos = actual_pos + pos_velo*self.cycle_t
        pos_command = pos

        # 姿态导纳
        ori_acc = np.linalg.inv(self.Mm) @ (self.Wm @ (actual_moment - target_moment) - self.Dm @ actual_ori_velo - self.Km @ ori_error)
        ori_velo = self.last_ori_velo + ori_acc*self.cycle_t
        # ori_velo = self.limit(ori_velo,[-0.04, -0.04, -0.1], [0.04, 0.04, 0.1])
        ori_velo = self.limit(ori_velo,[-0.1, -0.1, -0.1], [0.1, 0.1, 0.1])
        ori = ori_velo*self.cycle_t
        ori_command = (Rotation.from_rotvec(ori) * actual_R).as_euler('xyz')
        last_ori_command = last_command[3:]
        ori_command = self.rotvec_continuous_processing(ori_command, last_ori_command)

        # 更新指令
        command = np.zeros(6,)
        command[:3] = pos_command
        command[3:] = ori_command

        # 更新上一周期数据
        self.last_command = command
        self.last_pos_velo = pos_velo
        self.last_ori_velo = ori_velo
        self.last_actual_force = actual_force

        
        if self.collect_data:
            # 记录数据到文件
            data = {
                "target_pose" : target_pose,
                "actual_pose" : actual_pose.tolist(),
                "pos_error" : pos_error.tolist(),
                "ori_error" : ori_error.tolist(),
                "pos_acc" : pos_acc.tolist(),
                "ori_acc" : ori_acc.tolist(),
                "pos_velo" : pos_velo.tolist(),
                "ori_velo" : ori_velo.tolist(),
                "force" : actual_wrench_.tolist(), #actual_wrench.tolist(),
                "command" : command.tolist(),
            }
            with open("/home/byd/rl/hilserl_aubo/serl_robot_infra/robot_servers/sample.json", "a") as outfile:
                json.dump(data, outfile)
                outfile.write("\n")


        return command.tolist()

    # 力位混合控制
    def hybrid_force_position_control(self, Initialized, target_pose, actual_pose, actual_wrench, target_wrench, wrench_switch):
        if not Initialized:
            self.last_command = np.array(actual_pose)
            self.last_pos_velo = np.zeros(3,)
            self.last_ori_velo = np.zeros(3,)
            self.last_ori_error = np.zeros(3,)
            self.last_ori_error_t = np.zeros(3,)

            # 启动系数
            self.count = 0
            self.ratio = 0    
        
        if self.count<self.count_num:
            self.count += 1
            self.ratio = self.count/self.count_num

        # 实际数据
        actual_pos = self.last_command[:3]
        actual_pos_velo = self.last_pos_velo
        actual_force = actual_wrench[:3]
        actual_ori = self.last_command[3:]
        actual_R = Rotation.from_euler('xyz',actual_ori)
        actual_ori_velo = self.last_ori_velo
        actual_moment = actual_wrench[3:]

        # # 力传感器数据死区
        # actual_force = self.near_zero(actual_force, [1,1,1])
        # actual_moment = self.near_zero(actual_moment, [0.05,0.05,0.05])    

        # 目标数据
        target_pos = np.array(target_pose[:3])
        target_force = target_wrench[:3]
        target_ori = np.array(target_pose[3:])
        target_R = Rotation.from_euler('xyz',target_ori)
        target_moment = target_wrench[3:]

        # 误差
        pos_error = actual_pos-target_pos
        ori_error = -actual_R.as_matrix() @ ((actual_R.inv()*target_R).as_rotvec())
        ori_error = self.rotvec_continuous_processing(ori_error, self.last_ori_error)
        self.last_ori_error = ori_error
        
        # 位置导纳
        pos_acc = np.linalg.inv(self.Mf) @ (self.Wf @ (actual_force - target_force) - self.Df @ actual_pos_velo - self.Kf @ pos_error)
        pos_velo = self.last_pos_velo + pos_acc*self.cycle_t
        pos_velo = self.limit(pos_velo,[-0.1, -0.1, -0.1], [0.1, 0.1, 0.1])
        pos = actual_pos + pos_velo*self.cycle_t*self.ratio
        pos_command = pos

        # 姿态导纳
        ori_acc = np.linalg.inv(self.Mm) @ (self.Wm @ (actual_moment - target_moment) - self.Dm @ actual_ori_velo - self.Km @ ori_error)
        ori_velo = self.last_ori_velo + ori_acc*self.cycle_t
        ori_velo = self.limit(ori_velo,[-0.4, -0.4, -0.6], [0.4, 0.4, 0.6])
        ori = ori_velo*self.cycle_t
        ori_command = (Rotation.from_rotvec(ori) * actual_R).as_euler('xyz')
        last_ori_command = self.last_command[3:]
        ori_command = self.rotvec_continuous_processing(ori_command, last_ori_command)

        # 利用实际位姿计算位姿增量
        actual_pos_t = actual_pose[:3]
        actual_rpy_t = actual_pose[3:]

        pos_error_t = target_pos - actual_pos_t
        pos_error_t = self.limit(pos_error_t, [-0.0005, -0.0005, -0.0005], [0.0005, 0.0005, 0.0005])
        pos_command_t = actual_pos_t + pos_error_t

        actual_R_t = Rotation.from_euler('xyz', actual_rpy_t)
        ori_error_t = actual_R_t.as_matrix() @ ((actual_R_t.inv()*target_R).as_rotvec())
        ori_error_t = self.rotvec_continuous_processing(ori_error_t, self.last_ori_error_t)
        self.last_ori_error_t = ori_error_t
        actual_rotvec_t = actual_R_t.as_rotvec()
        ori_t = self.limit(ori_error_t, [-0.002, -0.002, -0.0024], [0.002, 0.002, 0.0024])
        ori_command_t = (Rotation.from_rotvec(ori_t) * actual_R_t).as_euler('xyz')

        for i in range(3):
            if wrench_switch[i]==0:
                pos_command[i] = pos_command_t[i]
            
            if wrench_switch[i+3]==0:
                ori_command[i] = ori_command_t[i]

        # 更新指令
        command = np.zeros(6,)
        command[:3] = pos_command
        command[3:] = ori_command

        # 更新上一周期数据
        self.last_command = command
        self.last_pos_velo = pos_velo
        self.last_ori_velo = ori_velo

        if self.collect_data:
            # 记录数据到文件
            data = {
                "target_pose" : target_pose,
                "actual_pose" : actual_pose,
                "pos_error" : pos_error.tolist(),
                "ori_error" : ori_error.tolist(),
                "pos_velo" : pos_velo.tolist(),
                "ori_velo" : ori_velo.tolist(),
                "force" : actual_wrench.tolist(),
                "command" : command.tolist(),
            }
            with open("./general/sample.json", "a") as outfile:
                json.dump(data, outfile)
                outfile.write("\n")

        return command.tolist()

# if __name__ == "__main__":

