import numpy as np
import time
import threading
from aubo_env.controller import aubo_sdk_wripper
from aubo_env.force_sensor import KWForceSensor
from aubo_env.gripper import dh_gripper
from aubo_env.utils import filter
from aubo_env.spacemouse.spacemouse_expert import SpaceMouseExpert
from aubo_env.utils import general_func as gfunc
from scipy.spatial.transform import Rotation as R
import math

class auboImpedanceDefaultConfig:
    """阻抗控制器参数配置"""    

    # aubo 配置sdk相关
    aubo_config = {
        "tcp_force_sensor": "xinjingcheng_ftsensor",
        "tcp_force_sensor_offset": [0, 0, 0.06, 0, 0, 0],
        "tcp_offset": [0.00, 0.00, 0.00, 0.0, 0.0, 0.0],
        "payload_mass": 2.098,
        "payload_offset": [0.00488, -0.00463, 0.10448],
        "moment_axis" : [0, 0, 0],
        "inertia" : [0, 0, 0, 0, 0, 0],
        "sensor_limit" : [200, 200, 200, 4, 4, 4],
        "threshold" : [2, 2, 2, 1, 1, 1]
    }

    # 控制模式: "impedance" 需要外部 TCP 六维力传感器; "servo" 为位姿伺服(透传 servoCartesian), 无需力传感器
    control_mode = "servo"

    ############### 
    # aubo 力控模式相关参数
    # 一般不修改，以保持机械臂自身力控模式的稳定性
    ############### 
    M = [25.0, 25.0, 25.0, 5.0, 5.0, 5.0]
    D = [2500.0, 2500.0, 2500.0, 50.0, 50.0, 50.0] # 适当调大阻尼，可避免接触时机械臂反弹；调小阻尼，可提升运动速度
    K = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    feature = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0]  # 相对base坐标系
    compliance = [True, True, True, True, True, True]  # 启用那些方向的力控
    speed_limits = [2.0, 2.0, 2.0, 2.0, 2.0, 2.0]
    Fmax = 200   # N
    Mmax = 4    # N*m

    ############### 
    # 阻抗控制 tcp力矢量计算参数q
    # 可以根据任务需要进行修改
    ###############  
    fc_param = {
        "m": np.array([2.0, 2.0, 2.0, 2.0, 2.0, 2.0]),
        "d": np.array([50, 50, 50, 7, 7, 7]),
        "k": np.array([2500.0, 2500.0, 2500.0, 250.0, 250.0, 250.0]),
        
        # 目标tcp力的上下限，需要调整以保证夹爪、物件的接触安全
        "wrench_limit_pos": np.array([25, 25, 25, 10, 10, 10]), 
        "wrench_limit_neg":np.array([-25, -25, -25, -10, -10, -10]),
        }

class auboImpedanceController(threading.Thread):
    """负责阻抗控制器的启动和停止（以及备用的）关节恢复策略。"""

    def __init__(self,
                robot_ip, 
                gripper_type,
                gripper_port,
                reset_joint_target,
                control_cycle=0.005,      # 控制周期5ms
                without_env=False,  # False通过策略层控制机械臂运动，True直接使用3D鼠标控制机械臂运动（用于测试遥操功能）
                config=auboImpedanceDefaultConfig(),
                *args,
                **kwargs
                ):
        
        super(auboImpedanceController, self).__init__(*args, **kwargs)

        # 输入参数
        self.robot_ip = robot_ip
        self.gripper_type = gripper_type
        self.gripper_port = gripper_port
        self.reset_joint_target = reset_joint_target

        # 循环周期
        self.control_cycle = control_cycle   # 控制周期 5ms
        self.state_update_cycle = control_cycle   # 状态更新周期 5ms
        self.action_update_cycle = 0.1  # 3D鼠标数据更新周期 100ms

        # aubo力传配置
        self.config = config
        self.aubo_config = config.aubo_config

        # aubo力控参数
        self.m = config.M
        self.d = config.D
        self.k = config.K
        self.feature = config.feature
        self.compliance = config.compliance
        self.init_wrench = []
        self.speed_limits = config.speed_limits
        self.Fmax = config.Fmax
        self.Mmax = config.Mmax

        # 阻抗模型参数
        self.fc_param = config.fc_param

        # 控制模式
        self.control_mode = config.control_mode
        self.use_force_control = (self.control_mode == "impedance")

        # 状态参数
        data_bits = 16
        if data_bits==16:
            self.data_type = np.float16
        elif data_bits==32:
            self.data_type = np.float32
        else:
            self.data_type = np.float64
        self.target_pose = np.zeros((6,), dtype=self.data_type)
        self.last_target_pose = np.zeros((6,), dtype=self.data_type)
        self.current_pose = np.zeros((6,), dtype=self.data_type)
        self.current_vel = np.zeros((6,), dtype=self.data_type)
        self.last_vel = np.zeros((6,), dtype=self.data_type)
        self.current_wrench = np.zeros((6,), dtype=self.data_type)
        self.current_joint_pos = np.zeros((6,), dtype=self.data_type)
        self.current_joint_vel = np.zeros((6,), dtype=self.data_type)
        self.current_joint_torque = np.zeros((6,), dtype=self.data_type)
        self.gripper_info = [0.0, 0.0]
        self.action = [0.0]*6
        self.buttons = [0,0]
        self.control_initialized = False

        # 控制接口
        self.robot = aubo_sdk_wripper.AuboArm(self.robot_ip)
        if self.gripper_type == "DH":
            self.gripper = dh_gripper.DH_Gripper(self.gripper_port)
        elif self.gripper_type.lower() == "robotiq":
            # Robotiq 2F 通过串口 Modbus RTU 控制（见 robotiq_gripper.py）
            from aubo_env.gripper.robotiq_gripper import RobotiqGripper
            self.gripper = RobotiqGripper(portname=self.gripper_port)
            gfunc.print_green(f"[AuboServer] Robotiq gripper connected & activated on {self.gripper_port}")
        else:
            self.gripper = None
            gfunc.print_yellow(f"[AuboServer] gripper_type='{self.gripper_type}' 未匹配 DH/Robotiq，夹爪控制不可用")
        self.without_env = without_env
        if self.without_env:
            self.spacemouse0 = SpaceMouseExpert()   # 3D鼠标实例化
        else:
            self.spacemouse0 = None
        self.command_filter = filter.FIRFilter(6,50)    

        # 线程
        self._stopper = threading.Event()
        self._run_imp_loop = threading.Event()  # 阻抗控制循环是否就绪
        self._run_update_state_loop = threading.Event()  # 控制状态更新线程是否运行
        self._run_get_action_loop = threading.Event()   # 控制3D鼠标数据采集线程是否运行        
        self.lock = threading.Lock()

        # 线性插值
        self.i = 0
        self.current_pose_record = np.zeros((6,), dtype=self.data_type)  
        self.pos_delta = np.zeros((3,), dtype=self.data_type)
        self.angle_delta = np.zeros((3,), dtype=self.data_type)
        self.axis = np.zeros((3,), dtype=self.data_type)

# ======================================================================================================
# 基础功能函数 
    def set_force_sensor_param(self):
        '''配置力传感器参数'''
        self.robot.set_force_sensor(self.aubo_config["tcp_force_sensor"])
        self.robot.set_force_sensor_pose(self.aubo_config["tcp_force_sensor_offset"])
        self.robot.set_tcp_offset(self.aubo_config["tcp_offset"])
        self.robot.set_payload(self.aubo_config["payload_mass"], self.aubo_config["payload_offset"], self.aubo_config["moment_axis"], self.aubo_config["inertia"])
        self.robot.set_sensor_limits(self.aubo_config["sensor_limit"])
        self.robot.set_sensor_thresholds(self.aubo_config["threshold"])

        tcp_force_sensor_offset = self.robot.get_tcp_force_sensor_pose()
        tcp_offset = self.robot.get_tcp_offset()
        limit = self.robot.get_sensor_limits()
        threshold = self.robot.get_sensor_thresholds()
        time.sleep(1)
        payload = self.robot.get_payload()

        # if self.robot.get_sensor_status('kw_ftsensor'):
        #     gfunc.print_green(f"[AuboServer] Force sensor {self.aubo_config['tcp_force_sensor']} is ready.")
        # else:
        #     gfunc.print_red(f"[AuboServer] Force sensor {self.aubo_config['tcp_force_sensor']} is not ready.")
        gfunc.print_green(f"[AuboServer] TCP force sensor offset: {tcp_force_sensor_offset}")
        gfunc.print_green(f"[AuboServer] TCP offset: {tcp_offset}")
        gfunc.print_green(f"[AuboServer] Payload_mass: {payload[0]}")
        gfunc.print_green(f"[AuboServer] payload_offset: {payload[1]}")
        gfunc.print_green(f"[AuboServer] moment_axis: {payload[2]}")
        gfunc.print_green(f"[AuboServer] inertia: {payload[3]}")
        gfunc.print_green(f"[AuboServer] limit: {limit}")
        gfunc.print_green(f"[AuboServer] threshold: {threshold}")

    def set_impedance_param(self):
        '''配置阻抗控制参数'''
        self.robot.set_dynamic_model(self.m, self.d, self.k)
        model = self.robot.get_dynamic_model()
        gfunc.print_green(f"[AuboServer] m:{model[0]}")
        gfunc.print_green(f"[AuboServer] d:{model[1]}")
        gfunc.print_green(f"[AuboServer] k:{model[2]}")

    def enable_force_control(self):
        '''启动力控模式'''
        # 设置阻抗参数
        self.set_impedance_param()

        # 设置力传感器
        self.set_force_sensor_param()

        # 设置力控参考(目标)值
        self.init_wrench = [0.0]*6
        self.robot.set_target_force(self.feature, \
                    self.compliance, self.init_wrench, self.speed_limits)

        ret = self.robot.fc_enalbe()
        if ret:
            gfunc.print_green(f"[AuboServer] Force control mode activation succeeded")
        else:
            gfunc.print_red(f"[AuboServer] Force control mode activation failed")    
        return ret

    def disable_force_control(self):
        '''停止力控模式'''
        ret = self.robot.fc_disable()
        if ret:
            gfunc.print_green(f"[AuboServer] Force control mode deactivation succeeded")
        else:
            gfunc.print_red(f"[AuboServer] Force control mode deactivation failed")    
        return ret
    
    def send_force_command(self, target_tcp_wrench):
        """ 发送目标tcp力旋 """
        return self.robot.set_target_force(self.feature, \
                    self.compliance, target_tcp_wrench, self.speed_limits)        

    def enable_servo_control(self):
        '''进入位姿伺服模式(无需力传感器, servoCartesian 透传)'''
        self.robot.set_servo_mode(2)  # 2=透传模式(直接下发)
        self._servo_active = True     # 允许控制循环下发伺服指令
        self._run_imp_loop.set()      # 置位后 run_async 会(重新)启动控制线程
        gfunc.print_green(f"[AuboServer] Pose servo mode (servoCartesian) activated")
        return True

    def disable_servo_control(self):
        '''退出位姿伺服模式'''
        self._servo_active = False     # 停下：控制循环不再下发 servoCartesian
        self._run_imp_loop.clear()     # 通知控制循环退出（run_async 会停掉线程）
        self.robot.set_servo_mode(0)   # 0=退出伺服模式
        gfunc.print_green(f"[AuboServer] Pose servo mode deactivated")
        return True

    def send_servo_command(self, target_pose):
        '''发送目标位姿到位姿伺服(servoCartesian 透传)'''
        _t0 = time.time()
        ret = self.robot.set_servo_pose(target_pose, self.control_cycle)
        _dt = time.time() - _t0
        # [dbg] servoCartesian 单次下发超 500ms 即打印 —— 若机械臂"停 1 秒不动"，多半是这里
        if _dt > 0.5:
            gfunc.print_red(f"[AuboServer][dbg] servoCartesian SLOW {_dt*1000:.0f}ms pose={target_pose}")
        return ret

    def enable_control(self):
        '''根据控制模式启用力控或位姿伺服'''
        # [fix] 每次(重新)启动力控/伺服前，把目标位姿重置为当前实测位姿。
        #   原因：控制循环线程常驻，target_pose 会残留上一次(复位前/旧目标)的值；
        #   若不带重置直接 /start_imp，开伺服的瞬间机械臂会朝旧目标回冲一下(下冲)。
        #   current_pose 由 5ms 状态线程持续刷新，此处读到的是最新实际位姿；
        #   同时把插值计数归零，linear_interpolation 会以当前位姿为起点重新采样。
        with self.lock:
            self.current_pose[:] = self.robot.get_tcp_pose()
        self.target_pose = self.current_pose.copy()
        self.last_target_pose = self.current_pose.copy()
        self.i = 0
        gfunc.print_green(f"[AuboServer] enable_control: target_pose reset to current: {self.target_pose}")

        if self.use_force_control:
            return self.enable_force_control()
        else:
            return self.enable_servo_control()

    def disable_control(self):
        '''根据控制模式停止控制'''
        # 停止控制前把目标对齐到当前实测位姿，消除残留的旧目标
        try:
            with self.lock:
                self.current_pose[:] = self.robot.get_tcp_pose()
            self.target_pose = self.current_pose.copy()
            self.last_target_pose = self.current_pose.copy()
            self.i = 0
        except Exception as e:
            gfunc.print_red(f"[AuboServer] disable_control: 对齐目标位姿失败: {e}")

        if self.use_force_control:
            return self.disable_force_control()
        else:
            return self.disable_servo_control()

    def set_robot_global_speed(self, speed):
        '''设置机器人全局速度'''
        ret = self.robot.set_global_speed(speed)
        return ret

    def disconnect(self):
        '''断开机器人连接'''
        self.robot.disconnect()

    def is_imp_control_ready(self):
        """ 供外部查看控制循环是否启用 """
        return self._run_imp_loop.is_set()

    def stopit(self):
        """停止主循环"""
        # 停止前立刻：停下发 + 把目标拉回当前位姿。
        # 否则会残留上一次的 target_pose，与停机后被移动的机械臂差很远，
        # 重新下发/停止瞬间的几帧会强拉机械臂（示教器报"关节位置突然改变"）。
        self._servo_active = False
        self._run_imp_loop.clear()
        try:
            with self.lock:
                self.current_pose[:] = self.robot.get_tcp_pose()
            self.target_pose = self.current_pose.copy()
            self.last_target_pose = self.current_pose.copy()
            self.i = 0
        except Exception as e:
            gfunc.print_red(f"[AuboServer] stopit: 对齐目标位姿失败: {e}")
        self._stopper.set()

    def stopped(self):
        '''主循环是否已停止'''
        return self._stopper.is_set()
    
    def start(self):
        '''线程启动函数'''
        super().start()
        gfunc.print_green(f"[AutoServer] Controller process spawned at {self.native_id}")
        
        # 等待控制器准备好
        if not self._run_imp_loop.wait(timeout=5):
            raise TimeoutError("[AutoServer] Controller failed to become ready within timeout.")
       
    def run(self):
        '''线程运行函数'''
        try:
            self.run_async()
        finally:
            self.stopit()

    def update_robot_state(self):
        '''更新机器人状态'''
        tcp_pose = self.robot.get_tcp_pose()    # xyz+rxryrz(zyx_euler) m,rad
        tcp_vel = self.robot.get_tcp_vel()
        tcp_wrench = self.robot.get_tcp_force()
        joint_pos = self.robot.get_joint_pos()
        joint_vel = self.robot.get_joint_vel()
        joint_torque = self.robot.get_joint_cur()
            
        with self.lock:
            self.current_pose[:] = np.array(tcp_pose)
            self.current_vel[:] = np.array(tcp_vel)
            self.current_wrench[:] = np.array(tcp_wrench)
            self.current_joint_pos[:] = np.array(joint_pos)
            self.current_joint_vel[:] = np.array(joint_vel)
            self.current_joint_torque[:] = np.array(joint_torque)
        
    def get_action(self):
        '''获取3D鼠标指令'''
        action, buttons = self.spacemouse0.get_action()
        self.action[:3] = action[:3] * 0.05 
        self.action[3:] = action[3:] * 0.1  #0.05
        self.buttons = buttons
        # print(f"[action]:{action}    [buttons]:{buttons}")

    def calculate_pose(self):
        '''根据3D鼠标指令计算目标位姿'''
        last_target_pose = self.current_pose.copy()

        # 基于基座坐标系进行控制
        R0 = R.from_euler('xyz', last_target_pose[3:])
        P0 = np.array(last_target_pose[:3])
        dR = R.from_rotvec(self.action[3:])
        dP = np.array(self.action[:3])
        Rt = dR * R0 
        Pt = dP + P0

        self.target_pose = np.concatenate((Pt, Rt.as_euler('xyz')))
        # print(f"[target_pose]:{self.target_pose}")
            
    def linear_interpolation(self):
        '''根据强化学习策略的指令生成插值指令'''
        # 强化学习策略指令发送周期为100ms，机械臂控制周期为2ms，因此需要对指令进行插值
        num = int(self.action_update_cycle/self.control_cycle)

        if self.i==0:
            self.current_pose_record = self.current_pose.copy()
            current_pose = self.current_pose_record.copy()
            target_pose = self.target_pose.copy()
            pos = target_pose[:3]-current_pose[:3]
            self.pos_delta = pos / num

            current_R = R.from_euler('xyz', current_pose[3:])
            target_R = R.from_euler('xyz', target_pose[3:])
            rot_delta = (current_R.inv() * target_R).as_rotvec()

            angle = np.linalg.norm(rot_delta)
            self.angle_delta = angle / num

            if abs(angle) > 1e-6:  # 避免除以零
                self.axis = rot_delta / angle
            else:
                self.axis = np.array([0., 0., 0.])  # 零旋转时无定义方向
                    
        self.i += 1
        pose_command = np.zeros(6)
        current_pose = self.current_pose_record.copy()
        pose_command[:3]=current_pose[:3]+self.pos_delta*self.i
        pose_command[3:]=(R.from_euler('xyz', current_pose[3:]) * R.from_rotvec(self.axis*self.i*self.angle_delta)).as_euler('xyz') # ZYX欧拉角
        if self.i>=num:
            self.i = 0
        return pose_command.tolist()

    def calculate_force(self, is_Initialized, target_pose):
        '''
        阻抗控制模型
        '''
        # 初始化
        if not is_Initialized:
            self.last_vel = self.current_vel.copy()

        # 力计算
        actual_pos = self.current_pose[:3].copy()
        target_pos = np.array(target_pose[:3])
        last_pos_vel = self.last_vel[:3].copy()

        pos_error = actual_pos-target_pos
        pos_vel = self.current_vel[:3].copy()
        pos_acc = (pos_vel - last_pos_vel) / self.control_cycle
        force = self.fc_param['m'][:3]*pos_acc + self.fc_param['d'][:3]*pos_vel + self.fc_param['k'][:3]*pos_error

        # 力矩计算
        actual_ori = self.current_pose[3:].copy()
        target_ori = np.array(target_pose[3:])
        actual_R = R.from_euler('xyz',actual_ori)
        target_R = R.from_euler('xyz',target_ori)
        ori_vel = self.current_vel[3:].copy()

        ori_error = -actual_R.as_matrix() @ ((actual_R.inv()*target_R).as_rotvec())
        moment = self.fc_param['d'][3:]*ori_vel + self.fc_param['k'][3:]*ori_error

        # 更新过去状态
        self.last_vel = self.current_vel.copy()

        target_wrench = np.concatenate([force, moment])
        target_wrench = np.clip(target_wrench, self.fc_param['wrench_limit_neg'], self.fc_param['wrench_limit_pos'])

        return target_wrench

# ======================================================================================================
# 循环函数    
    def update_robot_state_loop(self):
        '''机器人状态更新循环'''
        time_inv_s = self.state_update_cycle

        # # 设置CPU亲和性
        # gfunc.set_cpu_affinity([2])
        
        # # 设置实时调度策略
        # gfunc.set_realtime_scheduling(priority=90)

        gfunc.print_green(f"[AuboServer] Update robot state loop started")
        while self._run_update_state_loop.is_set():
            try:
                start_time = time.monotonic()

                self.update_robot_state()

                delay = max(0, time_inv_s - (time.monotonic() - start_time))
                time.sleep(delay)

            except Exception as e:
                gfunc.print_red(f"[AuboServer] Error in state update thread: {e}")
                self._run_update_state_loop.clear()  # 出错时主动停止线程
    
    def impedance_control_loop(self):
        '''控制循环(力控 / 位姿伺服 可切换)'''
        assert self.enable_control() == True
        self.target_pose = self.current_pose.copy()
        gfunc.print_green(f"[AuboServer] target pose is set to current pose: {self.target_pose}")
        time_inv_s = self.control_cycle

        # # 设置CPU亲和性
        # gfunc.set_cpu_affinity([3])
        
        # # 设置实时调度策略
        # gfunc.set_realtime_scheduling(priority=99)

        gfunc.print_green(f"[AuboServer] Control loop started (mode={self.control_mode})")
        self._run_imp_loop.set()
        while self._run_imp_loop.is_set(): 
            start_time = time.monotonic()

            target_pose = self.linear_interpolation()

            if self.without_env:
                if self.buttons[0]==1:
                    self.gripper.openGripper()
                elif self.buttons[1]==1:
                    self.gripper.closeGripper()

            if self.use_force_control:
                # 实际力/力矩超出阈值,停止控制
                if abs(self.current_wrench[0])>self.Fmax or abs(self.current_wrench[1])>self.Fmax or abs(self.current_wrench[2])>self.Fmax: #or \
                   #abs(self.current_wrench[3])>self.Mmax or abs(self.current_wrench[4])>self.Mmax or abs(self.current_wrench[5])>self.Mmax:
                    self.robot.stop_move()
                    self._run_imp_loop.clear()
                    self.stopit()
                    gfunc.print_red(f"[AuboServer] Force/Moment exceeds threshold, stopping control. Current wrench: {self.current_wrench}")
                    break

                command = self.calculate_force(self.control_initialized, target_pose)
                command = self.command_filter.filter(command)
                self.send_force_command(command)
            else:
                # 位姿伺服: 直接将插值后的目标位姿下发给 servoCartesian(透传)
                # 停下(disable_servo_control)时不再下发，避免向已退出伺服的机械臂发指令
                if not getattr(self, "_servo_active", True):
                    flag = None        # 未下发
                else:
                    flag = self.send_servo_command(target_pose)
                # [dbg] 伺服健康心跳（2s 一次）——"程序活着但机械臂不动"时看这里：
                #   - flag != 0      : servoCartesian 下发被 SDK 拒绝（未真正执行）
                #   - servo_on False : 伺服模式掉线，机械臂不会再跟随任何指令
                #   - pos_err 大且持续不收敛(servo_on=True)：机械臂该动没动，更底层的运动问题
                _now = time.monotonic()
                if (getattr(self, "_servo_active", True)
                        and (getattr(self, "_dbg_hb_t", None) is None or _now - self._dbg_hb_t > 2.0)):
                    self._dbg_hb_t = _now
                    try:
                        servo_on = bool(self.robot.get_servo_mode())
                    except Exception as e:
                        servo_on = f"err:{e}"
                    pos_err = float(np.linalg.norm(np.asarray(self.current_pose[:3]) - np.asarray(self.target_pose[:3])))
                    line = (f"[AuboServer][dbg] servo_on={servo_on} flag={flag} "
                            f"pos_err={pos_err:.4f} tgt={np.round(self.target_pose, 3).tolist()} "
                            f"cur={np.round(self.current_pose, 3).tolist()}")
                    if servo_on is True and flag == 0:
                        gfunc.print_green(line)
                    else:
                        gfunc.print_red(line + "  <<< 异常：伺服未使能或指令被拒")
                        if servo_on is False:
                            gfunc.print_red("[AuboServer][dbg] 尝试重新打开伺服 (set_servo_mode(2))")
                            self.robot.set_servo_mode(2)

            if not self.control_initialized:
                self.control_initialized = True

            delay = max(0, time_inv_s - (time.monotonic() - start_time))
            time.sleep(delay)

        self.disable_control()

    def get_action_loop(self):
        time_inv_s = self.action_update_cycle

        self.last_target_pose = self.robot.get_tcp_pose()
        while self._run_get_action_loop.is_set():
            try:
                start_time = time.monotonic()

                self.get_action()
                target_pose = self.calculate_pose()

                delay = max(0, time_inv_s - (time.monotonic() - start_time))
                time.sleep(delay)

            except Exception as e:
                gfunc.print_red(f"[AuboServer] Error in get action thread: {e}")
                self._run_get_action_loop.clear()  # 出错时主动停止线程

    def run_async(self):
        '''主循环'''
        try:
            time_inv_s = self.control_cycle

            # 启动机器人状态更新线程
            self._run_update_state_loop.set()
            update_robot_state_thread = threading.Thread(target=self.update_robot_state_loop, daemon=True).start()        

            if self.without_env:
                # 启动3D鼠标数据采集线程
                self._run_get_action_loop.set()
                get_action_thread = threading.Thread(target=self.get_action_loop,daemon=True).start()
            time.sleep(0.5)

            # 启动导纳控制线程
            self._run_imp_loop.set()
            impedance_thread = None

            while not self.stopped():
                if self._run_imp_loop.is_set():
                    # 如果线程不存在或已结束，则新建并启动
                    if impedance_thread is None or not impedance_thread.is_alive():
                        impedance_thread = threading.Thread(
                            target=self.impedance_control_loop,
                            daemon=True
                        )
                        impedance_thread.start()
                else:
                    # 停止线程
                    if impedance_thread and impedance_thread.is_alive():
                        self._run_imp_loop.clear()  # 停止内部循环
                        impedance_thread.join(timeout=time_inv_s*2)  # 可选等待退出
                        gfunc.print_yellow(f"[AuboServer] Admittance control loop stoped")
                    impedance_thread = None  # 重置引用

                time.sleep(time_inv_s)
        except KeyboardInterrupt:
            gfunc.print_red(f"[AuboServer] Interruption in run_async") 

        except Exception as e:
            gfunc.print_red(f"[AuboServer] Exception in run_async: {e}")                

        finally:
                self._run_update_state_loop.clear()  # 停止状态更新线程
                self._run_imp_loop.clear()  # 停止阻抗控制线程
                self._run_get_action_loop.clear() # 停止3D鼠标数据采集线程
                time.sleep(3* time_inv_s)

                # 停止控制模式、机器人连接         
                self.disable_control()
                self.disconnect()
                gfunc.print_red(f"[AuboServer] Disconnected from robot: {self.robot_ip}")
