from scipy.spatial.transform import Rotation
import numpy as np
import ctypes
import ctypes.util
import os

# ====================================================================
# 彩色打印
def print_red(text):
    print(f"\033[31m{text}\033[0m")

def print_green(text):
    print(f"\033[32m{text}\033[0m")

def print_yellow(text):
    print(f"\033[33m{text}\033[0m")

# ====================================================================
# 位姿格式转换
def pose_euler2quat(pose_euler):
    pos = pose_euler[:3]
    rpy = pose_euler[3:]
    R = Rotation.from_euler('xyz', rpy) # ZYX欧拉角
    quat = R.as_quat()
    pose_quat = np.concatenate((pos, quat))
    return pose_quat.tolist()

def pose_quat2euler(pose_quat):
    pos = pose_quat[:3]
    quat = pose_quat[3:]
    R = Rotation.from_quat(quat)
    rpy = R.as_euler('xyz') # ZYX欧拉角
    pose_euler = np.concatenate((pos, rpy))
    return pose_euler.tolist()

# ====================================================================
# 精准延时函数

# 加载实时库
librt = ctypes.CDLL(ctypes.util.find_library('rt'))

# 定义 timespec 结构
class Timespec(ctypes.Structure):
    _fields_ = [
        ('tv_sec', ctypes.c_long),
        ('tv_nsec', ctypes.c_long)
    ]

# 设置函数原型
librt.clock_nanosleep.argtypes = [
    ctypes.c_int, ctypes.c_int, 
    ctypes.POINTER(Timespec), ctypes.POINTER(Timespec)
]

# 定义常量
CLOCK_MONOTONIC = 1

def precise_delay_ns(nanoseconds):
    """
    高精度纳秒级延时函数（使用clock_nanosleep系统调用）
    """
    req = Timespec()
    req.tv_sec = nanoseconds // 1_000_000_000
    req.tv_nsec = nanoseconds % 1_000_000_000
    
    rem = Timespec()
    librt.clock_nanosleep(CLOCK_MONOTONIC, 0, ctypes.byref(req), ctypes.byref(rem))

def precise_delay_ms(milliseconds):
    """
    高精度毫秒级延时函数
    """
    precise_delay_ns(milliseconds * 1_000_000)


# ====================================================================
# 线程

def set_realtime_scheduling(priority=80, policy=os.SCHED_FIFO, pid=0):
    """
    设置实时调度策略和优先级
    
    参数:
        priority: 实时优先级 (1-99)
        policy: 调度策略 (os.SCHED_FIFO 或 os.SCHED_RR)
        pid: 进程ID (0表示当前进程)
    """
    try:
        param = os.sched_param(priority)
        os.sched_setscheduler(pid, policy, param)
        print(f"成功设置实时调度: 策略={policy}, 优先级={priority}")
        return True
    except PermissionError:
        print("错误: 需要root权限设置实时调度策略!")
        return False
    except Exception as e:
        print(f"设置实时调度失败: {e}")
        return False

def set_cpu_affinity(cpu_list, pid=0):
    """
    设置CPU亲和性,将进程/线程绑定到指定的CPU核心
    
    参数:
        cpu_list: CPU核心编号列表 (如 [0, 2] 或 [3])
        pid: 进程ID (0表示当前进程)
    """
    try:
        # 将列表转换为集合格式
        cpu_set = set(cpu_list)
        os.sched_setaffinity(pid, cpu_set)
        print(f"成功设置CPU亲和性: 绑定到核心 {cpu_set}")
        return True
    except Exception as e:
        print(f"设置CPU亲和性失败: {e}")
        return False