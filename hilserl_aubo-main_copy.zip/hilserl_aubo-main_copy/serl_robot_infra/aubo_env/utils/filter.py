import numpy as np

class MeanFilter:
    def __init__(self, array_size, sample_size):
        self.data = np.zeros((sample_size, array_size))
        self.sample_size = sample_size
        self.array_size = array_size
        self.init = False
        self.index = 0
    
    def filter(self, new_data):
        if not self.init:
            self.data[self.index] = new_data
            self.index +=1
            sum = np.zeros(self.array_size,)
            for i in range(self.index):
                sum = sum + self.data[i]
            mean_value = sum / float(self.index)

            if self.index == self.sample_size:
                self.init = True

            return mean_value
        else:
            for i in range(self.sample_size-1):
                self.data[i] = self.data[i+1]
            self.data[self.sample_size-1] = new_data

            sum = np.zeros(self.array_size,)
            for i in range(self.sample_size):
                sum = sum + self.data[i]
            mean_value = sum / float(self.sample_size)      

            return mean_value

class FIRFilter:
    def __init__(self, array_size, sample_size):
        self.data = np.zeros((sample_size, array_size))
        self.sample_size = sample_size
        self.array_size = array_size
        self.init = False
        self.index = 0    

    def reset(self):
        self.data = np.zeros((self.sample_size, self.array_size))
        self.init = False
        self.index = 0          

    def filter(self, new_data):
        if not self.init:
            self.data[self.index] = new_data
            self.index +=1

            n = 0.5*(1+self.index)*self.index
            sum = np.zeros(self.array_size,)
            for i in range(self.index):
                sum = sum + float(i+1)/n*self.data[i]
            
            if self.index == self.sample_size:
                self.init = True
            
            return sum
        else:
            for i in range(self.sample_size-1):
                self.data[i] = self.data[i+1]
            self.data[self.sample_size-1] = new_data

            n = 0.5*(1+self.sample_size)*self.sample_size
            sum = np.zeros(self.array_size,)
            for i in range(self.sample_size):
                sum = sum + float(i+1)/n*self.data[i]

            return sum   

class KalmanFilter:
    def __init__(self, n, process_noise, measurement_noise):
        """     
        参数:
        process_noise: 过程噪声标准差 (6维向量)
        measurement_noise: 测量噪声标准差 (6维向量)
        """
        # 状态维度: [Fx, Fy, Fz, Mx, My, Mz]
        self.n = n
        
        # 状态转移矩阵 (简单恒定模型)
        self.F = np.eye(self.n)
        
        # 过程噪声协方差矩阵
        self.Q = np.diag(process_noise**2)
        
        # 测量矩阵 (直接测量所有状态)
        self.H = np.eye(self.n)
        
        # 测量噪声协方差矩阵
        self.R = np.diag(measurement_noise**2)
        
        # 初始状态估计
        self.x = np.zeros((self.n, 1))
        
        # 初始估计误差协方差
        self.P = np.eye(self.n)
        
    def predict(self):
        """预测步骤"""
        # 预测状态
        self.x = self.F @ self.x
        
        # 预测误差协方差
        self.P = self.F @ self.P @ self.F.T + self.Q
        
        return self.x.flatten() 

    def update(self, z):
        """更新步骤"""
        z = z.reshape((self.n, 1))
        
        # 计算卡尔曼增益
        S = self.H @ self.P @ self.H.T + self.R
        K = self.P @ self.H.T @ np.linalg.inv(S)
        
        # 更新状态估计
        y = z - self.H @ self.x
        self.x = self.x + K @ y
        
        # 更新误差协方差
        I = np.eye(self.n)
        self.P = (I - K @ self.H) @ self.P
        
        return self.x.flatten()

    def filter(self, z):
        self.predict()
        estimate = self.update(z.copy())
        return estimate                   


