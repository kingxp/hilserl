"""
Robotiq 2F 夹爪驱动（RS485 / Modbus RTU），接口兼容 DH_Gripper。

实现参考：serl_robot_infra/aubo_env/controller/ref_code/GripperRobotIQ.py 的
GripperRobotiqRS485（纯手写 Modbus RTU 帧 + CRC，slave_id=9，波特率 115200）。

本模块对外提供与 aubo_server / aubo_impedance_controller 一致的接口：
    openGripper()           张开（Robotiq pos 0 = 完全张开）
    closeGripper()          闭合（Robotiq pos 255 = 完全闭合）
    setPosition_mm(pos)     aubo 二值夹爪命令适配：小值张开 / 较大值闭合
    getPosition()           读当前开度（0~255，0=全开 255=全闭，调试/反馈用）
    read_status()           读详细状态（调试用）

注意（README 4.5）：
    aubo 侧约定 gripper 0=张开、1=闭合。若你的夹爪反馈方向相反，调整本模块的
    setPosition_mm / 反馈映射即可，注释处已标出。
"""

import time


class RobotiqGripper:
    OUTPUT_REG_START = 0x03E8   # 1000：写（输出）寄存器起点
    INPUT_REG_START = 0x07D0    # 2000：读（输入）寄存器起点
    CLOSE_POS = 255             # Robotiq 位置编码：255 = 完全闭合
    OPEN_POS = 0                # Robotiq 位置编码：0   = 完全张开

    def __init__(self, portname, slave_id=9, baudrate=115200, timeout=1.0):
        """
        portname: 串口设备路径，如 '/dev/ttyUSB0'
        slave_id: Modbus 从站地址，Robotiq 默认 9
        """
        self.port = portname
        self.slave_id = slave_id
        self.baudrate = baudrate
        self.timeout = timeout
        self.serial = None
        self._connected = False

        import serial
        self.serial = serial.Serial(
            port=self.port,
            baudrate=self.baudrate,
            bytesize=8,
            parity='N',
            stopbits=1,
            timeout=self.timeout,
        )
        if not self.serial.is_open:
            raise IOError(f"[RobotiqGripper] 无法打开串口 {self.port}")
        print(f"[RobotiqGripper] 串口 {self.port} 已打开，开始激活夹爪 ...")
        self._activate()
        self._connected = True
        print("[RobotiqGripper] 激活完成，准备就绪")

    # ------------------------------------------------------------------ #
    # Modbus 通信底层
    # ------------------------------------------------------------------ #

    @staticmethod
    def _crc16_modbus(data: bytes) -> int:
        crc = 0xFFFF
        for byte in data:
            crc ^= byte
            for _ in range(8):
                if crc & 0x0001:
                    crc = (crc >> 1) ^ 0xA001
                else:
                    crc >>= 1
        return crc

    @staticmethod
    def _build_modbus_frame(slave_id: int, func_code: int, data: bytes) -> bytes:
        frame = bytes([slave_id, func_code]) + data
        crc = RobotiqGripper._crc16_modbus(frame)
        return frame + crc.to_bytes(2, byteorder='little')

    def _send_frame(self, frame: bytes) -> bytes:
        if not self.serial or not self.serial.is_open:
            raise RuntimeError("[RobotiqGripper] 串口未打开")
        self.serial.reset_input_buffer()
        self.serial.write(frame)
        time.sleep(0.05)
        response = b''
        start_time = time.time()
        while time.time() - start_time < self.timeout:
            if self.serial.in_waiting > 0:
                chunk = self.serial.read(self.serial.in_waiting)
                response += chunk
                if len(response) >= 8:
                    if response[0] == self.slave_id and response[1] == 0x10:
                        return response          # 完整写响应
                    elif response[0] == self.slave_id and response[1] in (0x03, 0x04):
                        byte_count = response[2]
                        if len(response) >= 3 + byte_count + 2:
                            return response      # 完整读响应
            time.sleep(0.01)
        print(f"[RobotiqGripper] 响应超时，已收 {len(response)} 字节")
        return b''

    def _write_multiple_registers(self, address: int, values) -> bool:
        byte_data = b''.join(int(v).to_bytes(2, 'big') for v in values)
        data = (address.to_bytes(2, 'big') +
                len(values).to_bytes(2, 'big') +
                len(byte_data).to_bytes(1, 'big') +
                byte_data)
        frame = self._build_modbus_frame(self.slave_id, 0x10, data)
        resp = self._send_frame(frame)
        if len(resp) < 8:
            return False
        return resp[0] == self.slave_id and resp[1] == 0x10

    def _read_input_registers(self, address: int, count: int = 3):
        data = address.to_bytes(2, 'big') + count.to_bytes(2, 'big')
        frame = self._build_modbus_frame(self.slave_id, 0x04, data)
        resp = self._send_frame(frame)
        if len(resp) < 5 or resp[0] != self.slave_id or resp[1] != 0x04:
            return None
        byte_count = resp[2]
        if len(resp) < 3 + byte_count + 2:
            return None
        return resp[3:3 + byte_count]

    # ------------------------------------------------------------------ #
    # 激活与运动
    # ------------------------------------------------------------------ #

    def _activate(self, timeout: float = 10.0) -> bool:
        """Robotiq 官方激活序列 + 真校验。

        1) rACT=0 复位（不做会夹爪猛张的"自动释放"）
        2) rACT=1 请求激活
        3) 轮询直到 gACT=1 且 gSTA=3(已激活) 且 fault=0
        4) 超时/异常直接抛错，让服务启动阶段就暴露问题
        """
        # 1) rACT=0 复位
        if not self._write_multiple_registers(self.OUTPUT_REG_START, [0x0000, 0x0000, 0x0000]):
            raise IOError("[RobotiqGripper] 复位写寄存器失败（检查串口/接线/供电）")
        time.sleep(0.2)

        # 2) rACT=1 请求激活
        if not self._write_multiple_registers(self.OUTPUT_REG_START, [0x0100, 0x0000, 0x0000]):
            raise IOError("[RobotiqGripper] 激活写寄存器失败")
        time.sleep(0.1)

        # 3) 轮询激活结果
        t0 = time.time()
        last = None
        while time.time() - t0 < timeout:
            last = self.read_status()
            if last and last["gACT"] == 1 and last["gSTA"] == 3:
                if last["fault"] == 0:
                    print("[RobotiqGripper] 激活成功 (gSTA=3, fault=0)")
                    return True
                raise IOError(f"[RobotiqGripper] 激活完成但存在故障 fault={last['fault']} status={last}")
            time.sleep(0.2)

        raise IOError(f"[RobotiqGripper] 激活失败/超时，最后状态={last}")

    def _send_auto_release(self, direction: int = 1) -> bool:
        byte0 = 0x01 | 0x02 | (direction << 1)   # rACT=1, rATR=1, rARD=direction
        reg0 = (byte0 << 8) | 0x00
        return self._write_multiple_registers(self.OUTPUT_REG_START, [reg0, 0x0000, 0x0000])

    def setRaw(self, pos: int, speed: int = 0xFF, force: int = 0xFF) -> bool:
        """直接下发 Robotiq 位置（0=全开，255=全闭）并等待运动完成。"""
        pos = int(round(max(0, min(255, pos))))
        reg0 = (0x09 << 8) | 0x00          # rACT=1, rGTO=1
        reg1 = (0x00 << 8) | pos
        reg2 = ((speed & 0xFF) << 8) | (force & 0xFF)
        if not self._write_multiple_registers(self.OUTPUT_REG_START, [reg0, reg1, reg2]):
            return False
        return self._wait_motion_complete()

    def _wait_motion_complete(self, timeout: float = 5.0) -> bool:
        start = time.time()
        last_pos = -1
        stable_count = 0
        while time.time() - start < timeout:
            data = self._read_input_registers(self.INPUT_REG_START, 3)
            if data and len(data) >= 6:
                byte0 = data[0]
                byte4 = data[4]
                gGTO = (byte0 >> 3) & 0x01
                gOBJ = (byte0 >> 2) & 0x03
                if gOBJ != 0:
                    return True
                if gGTO == 0:
                    return True
                if byte4 == last_pos:
                    stable_count += 1
                    if stable_count >= 3:
                        return True
                else:
                    stable_count = 0
                    last_pos = byte4
            time.sleep(0.1)
        return False

    # ------------------------------------------------------------------ #
    # aubo_server / aubo_impedance_controller 需要的接口
    # ------------------------------------------------------------------ #

    def openGripper(self):
        """张开夹爪（Robotiq pos=0 = 完全张开）"""
        return self.setRaw(self.OPEN_POS)

    def closeGripper(self):
        """闭合夹爪（Robotiq pos=255 = 完全闭合）"""
        return self.setRaw(self.CLOSE_POS)

    def setPosition_mm(self, pos) -> bool:
        """兼容 aubo_server 的 /set_gripper 调用。

        aubo 二值模式只发两个值：0（张开）/ 70~85（闭合）。
        因此这里做二值语义映射：小值 -> 张开，较大值 -> 全闭合。
        若以后要连续位置控制，请直接调用 setRaw(pos0_255) 并按你的
        "张开/闭合"方向约定换算（0~255：0=全开，255=全闭）。
        """
        if pos is None:
            return False
        try:
            pos = float(pos)
        except (TypeError, ValueError):
            return False
        if pos < 10:          # 张开
            return self.setRaw(self.OPEN_POS)
        return self.setRaw(self.CLOSE_POS)   # 闭合

    def getPosition(self) -> int:
        """读当前开度 0~255（0=全开，255=全闭）；失败返回 -1。"""
        data = self._read_input_registers(self.INPUT_REG_START, 3)
        if not data or len(data) < 6:
            return -1
        return data[4]

    def read_status(self):
        """读取详细状态（调试用）。"""
        data = self._read_input_registers(self.INPUT_REG_START, 3)
        if not data or len(data) < 6:
            return None
        return {
            'gACT': data[0] & 0x01,
            'gGTO': (data[0] >> 3) & 0x01,
            'gSTA': (data[0] >> 4) & 0x03,
            'gOBJ': (data[0] >> 2) & 0x03,
            'fault': data[2],
            'pos_echo': data[3],
            'actual_pos': data[4],
            'current': data[5],
        }
