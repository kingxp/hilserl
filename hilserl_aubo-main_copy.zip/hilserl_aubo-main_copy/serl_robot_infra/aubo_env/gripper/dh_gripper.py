import minimalmodbus as mm
import serial
import time
from aubo_env.utils import general_func as gfunc 

BAUDRATE = 115200
BYTESIZE=8
PARITY="N"
STOPBITS=1
TIMEOUT=0.2

MODBUS_INIT=0x0100
MODBUS_FORCE=0x0101
MODBUS_POSITION=0x0103
MODBUS_VELOCITY=0x0104
MODBUS_INIT_STATE=0x0200
MODBUS_GRIPPER_STATE=0x0201
MODBUS_POSITION_STATE=0x0202
MODBUS_COMMAND_ROTATION_POSITION_LOW=0x0105
MODBUS_COMMAND_ROTATION_POSITION_HIGH=0x0105
MODBUS_ROTATION_VELOCITY=0x0107
MODBUS_ROTATION_MOMENT=0x0108
MODBUS_REALTIME_ROTATION_POSITION_LOW=0x0208 
MODBUS_REALTIME_ROTATION_POSITION_HIGH=0x0209
MODBUS_ROTATION_INIT_STATE=0x020A
MODBUS_ROTATION_STATE=0x020B
MODBUS_ROTATION_RESET=0x0506


class DH_Gripper(mm.Instrument):
    def __init__(self, portname, type='PGI', slaveAddress=1):
        self.slaveAddress = slaveAddress
        self.portname = portname
        self.type = type

        ser=serial.Serial(self.portname,
                          BAUDRATE,
                          BYTESIZE,
                          PARITY,
                          STOPBITS,
                          TIMEOUT)
        
        super().__init__(ser,
                         self.slaveAddress,
                         mm.MODE_RTU,
                         close_port_after_each_call=False,
                         debug=False)
        
        self.command_max=1000
        self.command_min=90
        if self.type=='RGI':    # 旋转夹爪
            self.distance_max=30
            self.distance_min=0
        else:   # 其余夹爪
            self.distance_max=85
            self.distance_min=0        
        self.degree_max=360
        self.degree_min=-360

        if not self.getInitState():
            self.calibration()
            while not self.getGripperState():
                time.sleep(0.1)
            
        self.setVelocity(100)
        self.setForce(100)
       
    def calibration(self):
        self.write_register(MODBUS_INIT, 0xA5)
    
    def setVelocity(self, velocity):
        velocity=self.limit(velocity, 0, 100)
        self.write_register(MODBUS_VELOCITY, velocity)  #velocity: 0-100
    
    def getVelocity(self):
        return self.read_register(MODBUS_VELOCITY)

    def setForce(self, force):
        force=self.limit(force, 20, 100)
        self.write_register(MODBUS_FORCE, force)  #force: 20-100

    def getForce(self):
        return self.read_register(MODBUS_FORCE)
    
    def setPosition(self, position):
        position=self.limit(position, self.command_min, self.command_max)
        self.write_register(MODBUS_POSITION, position)  #position: 0-1000

    def getPosition(self):
        return self.read_register(MODBUS_POSITION)  
    
    def getInitState(self):
        return self.read_register(MODBUS_INIT_STATE)
    
    def getGripperState(self):
        ret =  self.read_register(MODBUS_GRIPPER_STATE) # 0：运动中；1：到达位置；2：夹住物体；3：物体掉落
        return ret
    
    def openGripper(self):
        self.setPosition(self.command_max)
    
    def closeGripper(self):
        self.setPosition(self.command_min)
    
    def setPosition_mm(self, distance):
        distance = self.limit(distance, self.distance_min, self.distance_max)
        position = int(distance/self.distance_max*1000.0)
        self.setPosition(position)

    def getPosition_mm(self):
        position = self.getPosition()
        distance = position/1000.0*self.distance_max
        return distance

    def waitGraspDone(self):
        while self.getGripperState()==0:
            time.sleep(0.1)
            
    def limit(self, value, min_value, max_value):
        if value < min_value:
            value = min_value
        elif value > max_value:
            value = max_value
        
        return value

    #=================================================================================
    #旋转夹爪RGI的旋转控制
    def setRotationPosition(self, degree):
        position = self.limit(degree, self.degree_min, self.degree_max)
        self.write_register(MODBUS_COMMAND_ROTATION_POSITION_LOW, position, signed=True)  #position: -32768-32767，角度值

    def setRotationVelocity(self, velocity):
        velocity = self.limit(velocity, 0, 100)
        self.write_register(MODBUS_ROTATION_VELOCITY, velocity)  #velocity: 0-100
    
    def setRotationMoment(self, moment):
        moment=self.limit(moment, 20, 100)
        self.write_register(MODBUS_ROTATION_MOMENT, moment)  #force: 20-100    

    def getRotationPosition(self):
        return self.read_register(MODBUS_REALTIME_ROTATION_POSITION_LOW, signed=True)  

    def getRotationInitState(self):
        return self.read_register(MODBUS_ROTATION_INIT_STATE)
    
    def getRotationState(self):
        return self.read_register(MODBUS_ROTATION_STATE)

def main():
    gripper0 = DH_Gripper('/dev/ttyUSB0',type='RGI')
    # gripper1 = DH_Gripper('/dev/ttyUSB1')
    # gripper2 = DH_Gripper('/dev/ttyUSB2')
    gripper_list = [gripper0]
    gripper = None

    def change_gripper(number, gripper_list):
        if number=='0':
            gripper = gripper_list[0]
            gfunc.print_green('控制夹爪0, 对应USB0端口')
        elif number=='1':
            gripper = gripper_list[1]
            gfunc.print_green('控制夹爪1, 对应USB1端口')
        else:
            gripper = gripper_list[2] 
            gfunc.print_green('控制夹爪2, 对应USB2端口')
        return gripper

    need_to_init = False
    if need_to_init:
        gripper0.calibration()
        # gripper1.calibration()
        # gripper2.calibration()
        time.sleep(3)

    number = input('请输入夹爪编号：')
    gripper = change_gripper(number, gripper_list)
    
    mode = 1
    while True:
        if gripper.type=='RGI':
            if mode==1:
                distance = input("(输入Q切换夹爪，输入W切换旋转角度控制)请输入夹爪开合距离(mm):")
                if distance=='Q':
                    number = input('准备切换夹爪，请输入夹爪编号：')
                    gripper = change_gripper(number, gripper_list)                  
                elif distance=='W':
                    gfunc.print_green('切换成旋转角度控制')
                    mode = 2
                else:
                    gripper.setPosition_mm(float(distance))
                    gripper.waitGraspDone()
                    pos = gripper.getPosition_mm()
                    gfunc.print_yellow(f"当前位置: {pos}")
            else:
                degree = input("(输入Q切换夹爪，输入W切换开合位置控制)请输入旋转角度(°):")
                if degree=='Q':
                    number = input('准备切换夹爪，请输入夹爪编号：')
                    gripper = change_gripper(number, gripper_list)                  
                elif degree=='W':
                    gfunc.print_green('切换成开合位置控制')
                    mode = 1
                else:
                    gripper.setRotationPosition(int(degree))
                    time.sleep(0.5)
                    deg = gripper.getRotationPosition()
                    gfunc.print_yellow(f"当前角度: {deg}")

        else:
                distance = input("(输入Q切换夹爪)请输入夹爪开合距离(mm):")
                if distance=='Q':
                    number = input('准备切换夹爪，请输入夹爪编号：')
                    gripper = change_gripper(number, gripper_list)                  
                elif distance=='W':
                    gfunc.print_green('切换成旋转角度控制')
                    mode = 2
                else:
                    gripper.setPosition_mm(float(distance))
                    gripper.waitGraspDone()
                    pos = gripper.getPosition_mm()
                    gfunc.print_yellow(f"当前位置: {pos}")
    


if __name__ == '__main__':
    main()