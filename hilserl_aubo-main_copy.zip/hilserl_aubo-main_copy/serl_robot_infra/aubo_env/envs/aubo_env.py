"""Gym Interface for Aubo"""
import os
import numpy as np
import gymnasium as gym
import warnings
import copy
from scipy.spatial.transform import Rotation
import time
import requests
import queue
import threading
from datetime import datetime
from collections import OrderedDict
from typing import Dict

from aubo_env.camera.video_capture import VideoCaptureManager
from aubo_env.utils.rotations import euler_2_quat, quat_2_euler
from aubo_env.utils import general_func as gfunc

try:
    import cv2
except Exception as exc:
    cv2 = None
    _CV2_IMPORT_ERROR = exc
else:
    if getattr(cv2, "__codex_stub__", False):
        _CV2_IMPORT_ERROR = ImportError("using local cv2 compatibility shim")
        cv2 = None
    else:
        _CV2_IMPORT_ERROR = None


# =====================================================================
# [dbg] 排查日志（全仓库统一前缀 [dbg]，带相对启动时间戳）
#   定位卡点方法：进程卡住时，看门狗线程每秒打一行 [dbg][watch]，
#   若 phase / step 长时间不变，卡点就在该 phase 标记的调用里。
#   用 AUBO_DBG=0 可关闭本模块的 [dbg] 输出。
# =====================================================================
_DBG_T0 = time.time()
def _dbg(msg: str) -> None:
    if os.environ.get("AUBO_DBG", "1") == "1":
        print(f"[dbg] {time.time() - _DBG_T0:8.3f}s {msg}", flush=True)


def _resize_image(image: np.ndarray, size: tuple[int, int]) -> np.ndarray:
    """Resize image to (width, height), falling back to numpy when OpenCV is unavailable."""
    if cv2 is not None:
        return cv2.resize(image, size)

    target_w, target_h = size
    src_h, src_w = image.shape[:2]
    if src_h == target_h and src_w == target_w:
        return image.copy()

    y_idx = np.linspace(0, src_h - 1, target_h).astype(np.int32)
    x_idx = np.linspace(0, src_w - 1, target_w).astype(np.int32)
    if image.ndim == 3:
        return image[y_idx][:, x_idx, :]
    return image[y_idx][:, x_idx]



class envImageDisplayer(threading.Thread):
    """ 由于各环境调用的相机、画面裁切各不同，因此每个env单独持有ImageDisplayer """
    def __init__(self, queue, name):
        threading.Thread.__init__(self)
        self.queue = queue  # ref of queue
        self.daemon = True  # make this a daemon thread
        self.name = name
        self.size_imshow = (400, 400)
        self._running = True
        self._last_hb = time.time()   # [dbg] 显示线程心跳

    def run(self):
        if cv2 is None:
            return
        self.initialize_window()
        while self._running:
            try:
                img_array = self.queue.get(timeout=1)
                if (img_array is None) or (not self._running):
                    break

                frame = np.concatenate(
                    [_resize_image(v, self.size_imshow) for k, v in img_array.items() if "full" in k], axis=1
                )
                _dt0 = time.time()
                cv2.imshow(self.name, frame)
                cv2.waitKey(1)
                _dt = time.time() - _dt0
                _now = time.time()
                # [dbg] imshow 慢调用或 5s 心跳；心跳停更 = 显示线程卡死在 cv2/Qt 内部
                if _dt > 0.5 or _now - self._last_hb > 5.0:
                    self._last_hb = _now
                    _dbg(f"[display:{self.name}] imshow ok (last {_dt*1000:.0f}ms)")
            except queue.Empty:
                continue  # 超时后继续检查_running状态，确保可以响应shutdown
            except Exception as e:
                # [dbg] 显示线程异常不静默：打印并继续，避免整线程无声死掉
                _dbg(f"[display:{self.name}] exception: {e!r}")
                import traceback
                traceback.print_exc()
                time.sleep(0.5)

        cv2.destroyAllWindows()

    def initialize_window(self):
        """Initialize the image window before entering the main loop."""
        if cv2 is None:
            return
        frame = np.zeros(self.size_imshow, dtype=np.uint8)  # Create a blank frame
        cv2.imshow(self.name, frame)
        cv2.waitKey(1)

    def shutdown(self):
        """显式关闭线程和图像窗口"""
        self._running = False
        self.queue.put(None)  # 可选：加速线程退出
        self.join()  # 等待线程结束

##############################################################################


class DefaultEnvConfig:
    """Default configuration for AuboEnv. Fill in the values below."""
    ### 任务相关参数
    MAX_EPISODE_LENGTH: int = 100
    JOINT_RESET_PERIOD: int = 0
    
    ### 任务空间运动相关参数
    ACTION_SCALE: np.ndarray = np.array([0.01, 0.01, 0.01, 0.05, 0.05, 0.05, 1.0])  # xyz+rpy+gripper
    
    TARGET_POSE: np.ndarray = np.zeros((6,))  # 目标位姿及其上下界xyz+rpy
    ABS_POSE_LIMIT_HIGH = TARGET_POSE + np.array([0.01, 0.01, 0.01, 0.01, 0.01, 0.01]) 
    ABS_POSE_LIMIT_LOW = TARGET_POSE - np.array([0.01, 0.01, 0.01, 0.01, 0.01, 0.01]) 
    RELATIVE_POSE_LIMIT_HIGH = np.array([0.01, 0.01, 0.01])
    RELATIVE_POSE_LIMIT_LOW = np.array([-0.01, -0.01, -0.01])
    CLOSE_TO_POSE_THRESHOLD: np.ndarray = np.zeros((6,))  # 用于判断是否接近目标位置的阈值

    GRAB_POSE: np.ndarray = np.zeros((6,))  # optional
    GRAB_JOINT: np.ndarray = np.zeros((6,))  # optional
    
    # 任务重置的初始位置及其随机性参数 (optional）
    RESET_POSE = np.zeros((6,))  
    RANDOM_RESET = False
    RANDOM_XY_RANGE = np.array([0.0, 0.0])
    RANDOM_RZ_RANGE = np.array([0.0])
    
    ### 机器人控制相关参数
    SERVER_URL: str = "http://127.0.0.1:5000/"  # 机器人控制器服务地址
    GRIPPER_SLEEP: float = 0.6
    COMPLIANCE_PARAM: dict[str, float] = {}
    RESET_PARAM: dict[str, float] = {}
    PRECISION_PARAM: dict[str, float] = {}
    LOAD_PARAM: dict[str, float] = {
        "mass": 0.0,
        "F_x_center_load": [0.0, 0.0, 0.0],
        "load_inertia": [0, 0, 0, 0, 0, 0, 0, 0, 0]
    }
    
    ### 相机相关参数
    REALSENSE_CAMERAS: dict = {
        "wrist_1": {
            "serial_number": "218622275245",
            "dim": (1280, 720),
            "exposure": 20000,
        },   
        # "wrist_2": {
        #     "serial_number": "427xxxxxxxxx",
        #     "dim": (1280, 720),
        #     "exposure": 20000,
        # },
    }
    IMAGE_CROP: dict[str, callable] = {
        "wrist_1": lambda img: img[250:500, 620:830],
        # "wrist_2": lambda img: img[230:670, 470:910],
    }
    DISPLAY_IMAGE: bool = True

    ### 可自行根据需要添加参数
    VIA_POSE: np.ndarray = np.zeros((6,))  # optional
    TASK_INIT_POSE: np.ndarray = np.zeros((6,))  # optional

##############################################################################


class auboEnv(gym.Env):
    def __init__(
        self,
        env_name: str,
        camera_manager: VideoCaptureManager,
        # display_manager: ImageDisplayer,
        freq=10,
        fake_env=False,
        save_video=False,
        config: DefaultEnvConfig = None,
    ):
        self.config = config
        self.action_scale = config.ACTION_SCALE
        self._TARGET_POSE = config.TARGET_POSE
        self._RESET_POSE = config.RESET_POSE
        self._REWARD_THRESHOLD = config.CLOSE_TO_POSE_THRESHOLD
        self.max_episode_length = config.MAX_EPISODE_LENGTH
        self.url = config.SERVER_URL  # robot controller server url
        self.gripper_sleep = config.GRIPPER_SLEEP

        self._target_rot = Rotation.from_euler("xyz", self._TARGET_POSE[3:]).as_matrix()

        # convert last 3 elements from euler to quat, from size (6,) to (7,)
        if config.RESET_POSE.shape == (6,):
            self.reset_pos = np.concatenate(
                [config.RESET_POSE[:3], euler_2_quat(config.RESET_POSE[3:])]
            )

        # self._update_currstate()
        # self.last_gripper_act = time.time()
        # self.lastsent = time.time()
        # self.randomreset = config.RANDOM_RESET
        # self.random_xy_range = config.RANDOM_XY_RANGE
        # self.random_rz_range = config.RANDOM_RZ_RANGE
        # self.freq = freq
        # self.joint_reset_cycle = config.JOINT_RESET_PERIOD  # reset the robot joint every 200 cycles

        # 工作空间
        self.xyz_bounding_box = gym.spaces.Box(
            config.ABS_POSE_LIMIT_LOW[:3],
            config.ABS_POSE_LIMIT_HIGH[:3],
            dtype=np.float64,
        )
        # 欧拉角裁切存在问题
        self.rpy_bounding_box = gym.spaces.Box(
            config.ABS_POSE_LIMIT_LOW[3:],
            config.ABS_POSE_LIMIT_HIGH[3:],
            dtype=np.float64,
        )
        self.rpydelta_bounding_box = gym.spaces.Box(
            config.RELATIVE_POSE_LIMIT_LOW,
            config.RELATIVE_POSE_LIMIT_HIGH,
            dtype=np.float64,
        )

        # 指令空间
        # tcp pose + gripper
        self.action_space = gym.spaces.Box(
            np.ones((7,), dtype=np.float32) * -1,
            np.ones((7,), dtype=np.float32),
        )

        # 状态空间
        self.observation_space = gym.spaces.Dict(
            {
                "state": gym.spaces.Dict(
                    {
                        "tcp_pose": gym.spaces.Box(
                            -np.inf, np.inf, shape=(7,)
                        ),  # xyz + quat
                        "tcp_vel": gym.spaces.Box(-np.inf, np.inf, shape=(6,)),
                        "gripper_pose": gym.spaces.Box(-1, 1, shape=(1,)),
                        "tcp_force": gym.spaces.Box(-np.inf, np.inf, shape=(3,)),
                        "tcp_torque": gym.spaces.Box(-np.inf, np.inf, shape=(3,)),
                    }
                ),
                "images": gym.spaces.Dict(
                    {key: gym.spaces.Box(0, 255, shape=(128, 128, 3), dtype=np.uint8) 
                                for key in config.REALSENSE_CAMERAS}
                ),
            }
        )

        if fake_env:
            return

        self._start_imp_control()
        self._update_currstate()
        self.last_gripper_act = time.time()
        self.lastsent = time.time()
        self.randomreset = config.RANDOM_RESET
        self.random_xy_range = config.RANDOM_XY_RANGE
        self.random_rz_range = config.RANDOM_RZ_RANGE
        self.freq = freq
        self.joint_reset_cycle = config.JOINT_RESET_PERIOD  # reset the robot joint every 200 cycles
        self.cycle_count = 0

        self.display_image = config.DISPLAY_IMAGE
        if self.display_image and cv2 is None:
            warnings.warn(
                f"OpenCV import failed ({_CV2_IMPORT_ERROR}); disabling image display.",
                RuntimeWarning,
            )
            self.display_image = False
        self.camera_config = config.REALSENSE_CAMERAS
        self.camera_manager = camera_manager
        # self.display_manager = display_manager  # 统一的display_manager引用

        # self.video_cap = None
        self.init_cameras()
        if self.display_image:
            self.display_img_queue = queue.Queue()
            self.displayer = envImageDisplayer(self.display_img_queue, env_name)
            self.displayer.start()

        self.save_video = save_video
        if self.save_video and cv2 is None:
            warnings.warn(
                f"OpenCV import failed ({_CV2_IMPORT_ERROR}); disabling video recording.",
                RuntimeWarning,
            )
            self.save_video = False
        if self.save_video:
            print("Saving videos!")
            self.recording_frames = []

        from pynput import keyboard
        self.terminate = False
        self.exit = False
        def on_press(key):
            if key == keyboard.Key.esc:
                self.terminate = True          # 只结束当前回合（会 reset），不是退出程序
            elif str(key) == 'Key.f3':
                self.exit = True               # 退出信号（原代码误写成 self.exi，导致该信号永远传不出去）
        self.listener = keyboard.Listener(on_press=on_press)
        self.listener.start()

        gfunc.print_green("[aubo env] Initialized aubo env")

        # [dbg] 看门狗线程：每秒上报主循环 phase/step，定位卡点（AUBO_DBG=0 关闭）
        self._dbg_phase = "ready"
        threading.Thread(target=self._dbg_watchdog, daemon=True).start()

#########################################################################################
###########  环境相关函数  ###########
#########################################################################################

    def _dbg_watchdog(self):
        """[dbg] 看门狗：每秒上报主循环健康状态。
        若 phase / step 连续 5 秒不前进，说明主线程卡在 phase 指向的调用处。"""
        last_phase, last_step, stall = "", -1, 0
        while True:
            time.sleep(1.0)
            step_now = getattr(self, "curr_path_length", -1)
            if self._dbg_phase == last_phase and step_now == last_step:
                stall += 1
            else:
                stall = 0
            last_phase, last_step = self._dbg_phase, step_now
            mark = "  <<<< STALL" if stall >= 5 else ""
            _dbg(f"[watch] phase={self._dbg_phase:10s} step={step_now}{mark}")

    def step(self, action: np.ndarray) -> tuple:
        """
        底层step方法，约束action、计算目标tcp位姿，下发控制命令；进行观测；控制回合进行。
        input:
            action = [delta xyz, delta rpy, gripper]
        """
        start_time = time.time()
        self._dbg_phase = "set_pose"

        # 限制在-1~1之间
        action = np.clip(action, self.action_space.low, self.action_space.high)

        # 计算目标tcp位姿，action中的变化量+当前位姿计算，最终是xyz+quat。
        self.nextpos = self.currpos.copy()
        self.nextpos[:3] = self.nextpos[:3] +  action[:3] * self.action_scale[:3]
        self.nextpos[3:] = (
            Rotation.from_euler("xyz", action[3:6] * self.action_scale[3:6])
            * Rotation.from_quat(self.currpos[3:])
        ).as_quat()

        gripper_action = action[6] * self.action_scale[-1]  # 一般是*1

        # send to robot controller 
        self._send_target_pose(self.clip_safety_box(self.nextpos))
        #self._send_target_pose(self.nextpos)
        self._dbg_phase = "gripper"
        self._send_gripper_command(gripper_action)

        self.curr_path_length += 1
        self._dbg_phase = "get_state"
        self._update_currstate()
        self._dbg_phase = "camera"
        obs = self._get_obs()
        self._dbg_phase = "reward"
        reward = self.compute_reward(obs)
        done = self.curr_path_length >= self.max_episode_length \
                        or reward or self.terminate

        dt = time.time() - start_time
        if dt > 0.30:
            _dbg(f"[step#{self.curr_path_length}] SLOW total={dt*1000:.0f}ms")
        time.sleep(max(0, (1.0 / self.freq) - dt))
        self._dbg_phase = "sleeping"

        return obs, int(reward), done, False, {"succeed": reward, "exit": self.exit}

    def clip_safety_box(self, pose: np.ndarray) -> np.ndarray:
        """
        Clip the pose to be within the env safety box.
        裁切姿态，使得其在环境运动范围内
        input:
            pose: np.ndarray, shape (7,)
        """
        # 位置裁切
        pose[:3] = np.clip(
            pose[:3], self.xyz_bounding_box.low, self.xyz_bounding_box.high
        )

        # 姿态裁切
        actual_R = Rotation.from_euler("xyz", self._TARGET_POSE[3:])
        target_R = Rotation.from_quat(pose[3:])
        rpy_delta = (actual_R.inv()*target_R).as_euler('xyz')   # 以tcp坐标系为基准约束姿态
        rpy_delta = np.clip(rpy_delta, self.rpydelta_bounding_box.low, self.rpydelta_bounding_box.high)
        pose[3:] = (actual_R*Rotation.from_euler('xyz', rpy_delta)).as_quat() 

        # 存在问题，rx符号跳变
        # euler = Rotation.from_quat(pose[3:]).as_euler("xyz")
        # # Clip first euler angle separately due to discontinuity from pi to -pi
        # sign = np.sign(euler[0])
        # euler[0] = sign * (
        #     np.clip(
        #         np.abs(euler[0]),
        #         self.rpy_bounding_box.low[0],
        #         self.rpy_bounding_box.high[0],
        #     )
        # )

        # euler[1:] = np.clip(
        #     euler[1:], self.rpy_bounding_box.low[1:], self.rpy_bounding_box.high[1:]
        # )

        # pose[3:] = Rotation.from_euler("xyz", euler).as_quat()

        return pose

    def _get_obs(self) -> dict:
        """ get basic observation """
        images = self.get_image()
        state_observation = {
            "tcp_pose": self.currpos,
            "tcp_vel": self.currvel,
            "gripper_pose": self.curr_gripper_pos,
            "tcp_force": self.currforce,
            "tcp_torque": self.currtorque,
        }
        return copy.deepcopy(dict(images=images, state=state_observation))

    def compute_reward(self, obs) -> bool:
        """ 
        计算奖励，根据当前状态是否接近目标位置
        Args:
            obs: observation
        Returns:
            bool: True if the current pose is close to the target pose, False otherwise. 
        """
        current_pose = obs["state"]["tcp_pose"]

        # relative rotation matrix -> eular diff -> delta
        current_rot = Rotation.from_quat(current_pose[3:]).as_matrix()
        # target_rot = Rotation.from_euler("xyz", self._TARGET_POSE[3:]).as_matrix()
        diff_rot = current_rot.T  @ self._target_rot
        diff_euler = Rotation.from_matrix(diff_rot).as_euler("xyz")
        delta = np.abs(np.hstack([current_pose[:3] - self._TARGET_POSE[:3], diff_euler]))
        # print(f"Delta: {delta}")
        if np.all(delta < self._REWARD_THRESHOLD):
            return True
        else:
            # print(f'Goal not reached, the difference is {delta}, the desired threshold is {self._REWARD_THRESHOLD}')
            return False

    def go_to_reset(self, joint_reset=False):
        """
        运动到任务起始位置，按需重写
        """
        # Change to precision mode for reset
        self._update_currstate()

        # 先停止力控模式，因为后续使用moveline、movejoint
        self._stop_imp_control()
        time.sleep(0.5)

        if self.randomreset:  # randomize reset position in xy plane
            reset_pose = self.reset_pos.copy()
            reset_pose[:2] += np.random.uniform(
                -self.random_xy_range, self.random_xy_range, (2,)
            )
            euler_random = self._RESET_POSE[3:].copy()
            euler_random[-1] += np.random.uniform(
                -self.random_rz_range, self.random_rz_range
            )
            reset_pose[3:] = euler_random
            self._send_target_pose(reset_pose)
        else:
            reset_pose = self.reset_pos.copy()
            self._send_target_pose(reset_pose)

        # Change to force control mode
        self._start_imp_control()
        time.sleep(1)

    def reset(self, joint_reset=False, **kwargs):
        """ 重置回合 """
        _dbg(f"[reset] enter cycle={self.cycle_count} options={kwargs.get('options')}")
        # 保存上一回合视频
        if self.save_video:
            self.save_video_recording()

        # 运行一定轮数后回到关节起始位置、重新开始阻抗控制模式
        self.cycle_count += 1
        if self.joint_reset_cycle!=0 and self.cycle_count % self.joint_reset_cycle == 0:
            self.cycle_count = 0
            joint_reset = True

        options = kwargs.get("options", {})
        if options==None:
            reset_flag=True
        else:
            if "reset_flag" in options:
                reset_flag=options["reset_flag"]
            else:
                reset_flag=True
        # 运动回到任务起始点
        if options==None:
            self.go_to_reset(joint_reset=reset_flag)
        elif options['retreat']=='False':
            self.go_to_reset(joint_reset=reset_flag, retreat=False)               

        # 重置回合相关变量
        self.last_gripper_act = time.time()
        self.terminate = False
        self.curr_path_length = 0
        self._update_currstate()
        obs = self._get_obs()
        return obs, {"succeed": False}

    def close(self):
        if hasattr(self, 'listener'):
            self.listener.stop()
        self.close_cameras()
        if self.display_image:
            self.displayer.shutdown()

    def after_success(self):
        # Change to precision mode for reset
        self._update_currstate()

        # 先停止力控模式，因为后续使用moveline、movejoint
        self._stop_imp_control()
        time.sleep(0.5)

#########################################################################################
###########  camera函数  ###########
#########################################################################################

    def init_cameras(self):
        """ 传入相机配置字典 """
        print(self.camera_config)
        self.camera_manager.add_capture_multi(self.camera_config)

    def close_cameras(self):
        """Close cameras in list"""
        try:
            for cam_name in self.camera_config.keys():
                self.camera_manager.close_capture(cam_name)
        except Exception as e:
            print(f"Failed to close cameras: {e}")

    def get_image(self) -> Dict[str, np.ndarray]:
        """Get images from the realsense cameras."""
        obs_image = {}
        display_image = {}
        rec_image = {}  # New dictionary to store full resolution cropped images
        for cam_name in self.camera_config.keys():
            try:
                rgb = self.camera_manager.read_one(cam_name)
                # 裁切关键部分
                cropped_rgb = self.config.IMAGE_CROP[cam_name](rgb) if cam_name in self.config.IMAGE_CROP else rgb
                # resize 至网络观测输入尺寸
                resized = _resize_image(
                    cropped_rgb, self.observation_space["images"][cam_name].shape[:2][::-1]
                )
                obs_image[cam_name] = resized[..., ::-1]
                # display_images[cam_name] = resized
                display_image[cam_name + "_full"] = cropped_rgb
                rec_image[cam_name] = copy.deepcopy(cropped_rgb)  # Store the full resolution cropped image
            except TimeoutError as e:
                print(f"[{cam_name}] Read timeout: {e}")
                input(f"{cam_name} camera frozen. Check connect, then press enter to relaunch...")
                self.close_cameras()
                self.init_cameras()
                return self.get_image()

        # Store full resolution cropped images separately
        if self.save_video:
            self.recording_frames.append(rec_image)

        if self.display_image:
            self.display_img_queue.put(display_image)
        return obs_image

    def save_video_recording(self):
        try:
            if len(self.recording_frames):
                if not os.path.exists('./videos'):
                    os.makedirs('./videos')
                
                timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
                
                for camera_key in self.recording_frames[0].keys():
                    if self.url == "http://127.0.0.1:5000/":
                        video_path = f'./videos/left_{camera_key}_{timestamp}.mp4'
                    else:
                        video_path = f'./videos/right_{camera_key}_{timestamp}.mp4'
                    
                    # Get the shape of the first frame for this camera
                    first_frame = self.recording_frames[0][camera_key]
                    height, width = first_frame.shape[:2]
                    
                    video_writer = cv2.VideoWriter(
                        video_path,
                        cv2.VideoWriter_fourcc(*"mp4v"),
                        10,
                        (width, height),
                    )
                    
                    for frame_dict in self.recording_frames:
                        video_writer.write(frame_dict[camera_key])
                    
                    video_writer.release()
                    print(f"Saved video for camera {camera_key} at {video_path}")
                
            self.recording_frames.clear()
        except Exception as e:
            print(f"Failed to save video: {e}")

#########################################################################################
###########  机器人控制相关函数  ###########
#########################################################################################

    def _start_imp_control(self):
        _t0 = time.time()
        requests.post(self.url + "start_imp")
        _dt = time.time() - _t0
        if _dt > 0.5:
            _dbg(f"[http] /start_imp SLOW {_dt*1000:.0f}ms")

    def _stop_imp_control(self):
        _t0 = time.time()
        requests.post(self.url + "stop_imp")
        _dt = time.time() - _t0
        if _dt > 0.5:
            _dbg(f"[http] /stop_imp SLOW {_dt*1000:.0f}ms")

    def _update_currstate(self):
        """
        Internal function to get the latest state of the robot and its gripper.
        """
        _t0 = time.time()
        ps = requests.post(self.url + "get_state").json()
        _dt = time.time() - _t0
        if _dt > 0.2:
            _dbg(f"[http] /get_state SLOW {_dt*1000:.0f}ms")
        self.joints = np.array(ps["joints"])
        self.currpos = np.array(ps["pose"])
        self.currvel = np.array(ps["vel"])
        self.currforce = np.array(ps["force"][:3])
        self.currtorque = np.array(ps["force"][3:])
        self.curr_gripper_pos = np.array([ps["gripper"][0] / 100.0]) # gripper position -> 0~1.0
        self.curr_gripper_state = np.array([ps["gripper"][1]])  # grab state

    def _send_target_pose(self, pose: np.ndarray, speed: float = 1.0, acce: float = 1.0):
        """send target pose to the robot controller server
        pose: 6-dim xyz+eular or 7-dim xyz+quat target tcp pose
        speed: target speed rate
        acce: target accelerate rate
        """
        arr = np.array(pose).astype(np.float32)
        data = {"pose": arr.tolist(), "speed": speed, "acce": acce}
        _t0 = time.time()
        requests.post(self.url + "set_pose", json=data)
        _dt = time.time() - _t0
        if _dt > 0.2:
            _dbg(f"[http] /set_pose SLOW {_dt*1000:.0f}ms")

    def _send_target_joints(self, joints: np.ndarray, speed: float = 1.0, acce: float = 1.0):
        """send target pose to the robot controller server
        pose: 6-dim target joints
        speed: target speed rate
        acce: target accelerate rate
        """
        arr = np.array(joints).astype(np.float32)
        data = {"joints": arr.tolist(), "speed": speed, "acce": acce}
        requests.post(self.url + "set_joints", json=data)  # wait for response

    def _send_gripper_command(self, pos: float, speed: int = 255, 
                                force: int = 255, mode="binary"):
        """Internal function to send gripper command to the robot.
        按需继承重写~~~
        """
        if mode == "binary":   # 张开、关闭两种位置控制
            if pos>=0.9:
                terget_pos = 0
            elif pos<=-0.9:
                terget_pos = 70
            else:
                return
        elif mode == "continuous":  # 连续位置控制
            terget_pos = pos

        data = {"pos": terget_pos, "speed": speed, "force": force}
        requests.post(self.url + "set_gripper", json=data)  

    def _close_gripper(self):
        requests.post(self.url + "close_gripper")

    def _open_gripper(self):
        requests.post(self.url + "open_gripper")

    def _set_robot_goal_speed(self, speed):
        """ 设置机器人全局运动速度比例 0~1.0 """
        data = {"speed": speed}
        requests.post(self.url + "set_robot_goal_speed", json=data)

#########################################################################################
###########  装配任务相关函数  ###########
#########################################################################################
    def start_mission(self):
        ''' 启动装配任务 '''
        response = requests.post(self.url + "start_mission")
        print(response.text)
    
    def end_mission(self):
        ''' 结束装配任务 '''
        response = requests.post(self.url + "end_mission")
        print(response.text)
