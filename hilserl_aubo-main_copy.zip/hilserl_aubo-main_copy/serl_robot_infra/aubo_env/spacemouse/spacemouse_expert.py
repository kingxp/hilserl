import os
import threading
import numpy as np
from aubo_env.spacemouse import pyspacemouse
from typing import Tuple


class SpaceMouseExpert:
    """3D 鼠标读取器（线程版）。

    历史背景：旧实现用 multiprocessing.Manager() + daemon 子进程共享数据，
    有两个致命问题：
      1) fork 一个已经启动 RealSense/OpenCV 等 C++ 线程的进程，
         会破坏 USB/锁状态，导致运行期偶发卡死；
      2) 主进程退出时 Manager server 先关闭，子进程仍在写共享 dict
         会抛 BrokenPipeError，随后 C++ 清理把整个进程 abort(core dump)。
    现改为单线程 + 普通成员变量：
      - 不 fork、不跨进程 IPC；读线程只写 self._action/_buttons，
        get_action() 在锁保护下读取，接口签名不变，调用方零改动。
    """

    def __init__(self):
        pyspacemouse.open()

        # 共享状态（仅读写线程与主线程，用锁保护）
        self._lock = threading.Lock()
        self._action = [0.0] * 6
        self._buttons = [0, 0, 0, 0]
        self._stop = threading.Event()

        # 单线程持续读 HID（daemon，不阻塞主进程退出）
        self.thread = threading.Thread(target=self._read_spacemouse, daemon=True)
        self.thread.start()

    def _read_spacemouse(self):
        import time as _t
        import traceback
        _dbg_on = os.environ.get("AUBO_DBG", "1") == "1"  # AUBO_DBG=0 时关闭 [dbg][smouse] 心跳
        _hb = _t.time()
        while not self._stop.is_set():
            try:
                state = pyspacemouse.read_all()
            except Exception:
                if _dbg_on:
                    traceback.print_exc()
                    print("[dbg][smouse] read_all raised, retry in 1s", flush=True)
                _t.sleep(1.0)
                continue
            if state is None:
                _t.sleep(0.1)
                continue
            action = [0.0] * 6
            buttons = [0, 0, 0, 0]

            if len(state) == 2:
                action = [
                    -state[0].y, state[0].x, state[0].z,
                    -state[0].roll, -state[0].pitch, -state[0].yaw,
                    -state[1].y, state[1].x, state[1].z,
                    -state[1].roll, -state[1].pitch, -state[1].yaw
                ]
                buttons = state[0].buttons + state[1].buttons
            elif len(state) == 1:
                action = [
                    -state[0].y, state[0].x, state[0].z,
                    -state[0].roll, -state[0].pitch, -state[0].yaw
                ]
                buttons = state[0].buttons

            with self._lock:
                self._action = action
                self._buttons = buttons

            # [dbg] 心跳：若这行停更，说明读线程已卡死（主进程此时可能还活着）
            _now = _t.time()
            if _now - _hb > 0.5:
                _hb = _now
                if _dbg_on:
                    print(f"[dbg][smouse] alive action={[round(x, 3) for x in action[:6]]} btn={buttons}", flush=True)

            _t.sleep(0.002)  # 防止占满单核 CPU

    def get_action(self) -> Tuple[np.ndarray, list]:
        """Returns the latest action and button state of the SpaceMouse."""
        with self._lock:
            return np.array(self._action).copy(), list(self._buttons)

    def close(self):
        self._stop.set()
