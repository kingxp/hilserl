import os
import queue
import threading
import time
import numpy as np
# from typing import OrderedDict
from aubo_env.camera.rs_capture import RSCapture

def print_red(text):
    print(f"\033[31m{text}\033[0m")

def print_green(text):
    print(f"\033[32m{text}\033[0m")

def print_yellow(text):
    print(f"\033[33m{text}\033[0m")

class VideoCaptureManager:
    """
    管理多个RealSense相机的统一接口，支持多相机实时帧读取与资源管理。
    TODO: 添加更多相机兼容性

    功能：
    - 初始化并管理多个 VideoCaptureCommon 实例（每个对应一个相机）
    - 提供 read_one/read_multi/read_all 方法获取指定/多个/全部相机的最新帧
    - 支持单个、多个或全部相机资源的关闭

    特性：
    - 支持基于 serial_number 的共享实例引用计数，避免重复创建相同相机实例
    - 使用 OrderedDict 保持相机注册顺序

    属性：
    - name_to_serial: 相机名称到序列号映射
    - serial_to_capture: 序列号到采集器映射
    - name_to_cap: 相机名称到采集器映射（OrderedDict）
    - serial_ref_count: 每个序列号的引用计数
    """

    def __init__(self, verbose = False):
        """ 初始化公用的VideoCapture对象字典 """
        self.name_to_serial = {}                # cam_name → serial_number
        self.serial_to_capture = {}             # serial_number → capture
        self.name_to_cap = {}        # cam_name → VideoCaptureCommon
        self.serial_ref_count = {}              #  serial_number → ref_count
        self.verbose = verbose
        print_green("[VCM] video capture manager initialized")

    def print(self, msg, color:str=None):
        if self.verbose:
            if color == "red":
                print(f"\033[31m{msg}\033[0m")
            elif color == "green":
                print(f"\033[32m{msg}\033[0m")
            elif color == "yellow":
                print(f"\033[33m{msg}\033[0m")
            else:
                print(msg)

    def add_capture(self, cam_name:str, config:dict)-> None:
        # 检查配置中是否有 serial_number
        serial_number = config.get("serial_number", None)
        assert serial_number is not None, f"[VCCM] Camera {cam_name} missing 'serial_number' in config"

        # 检查是否已有 serial_number 对应的相机实例
        if serial_number in self.serial_to_capture.keys():
            self.print(f"[VCCM] capture (serial number: '{serial_number}') already exists", "yellow")
            capture = self.serial_to_capture[serial_number]
            self.serial_ref_count[serial_number] += 1
        else:
            # 创建新相机采集器
            capture = VideoCaptureCommon(
                RSCapture(name=cam_name, **config),
                name=cam_name,
            )
            self.serial_to_capture[serial_number] = capture
            self.serial_ref_count[serial_number] = 1 

        self.name_to_serial[cam_name] = serial_number
        self.name_to_cap[cam_name] = capture

    def add_capture_multi(self, name_serial_dict:dict)-> None:
        for cam_name, config in name_serial_dict.items():
            self.add_capture(cam_name, config)

    def list_captuers(self) -> list:
        result = []
        for cam_name, serial_number in self.name_to_serial.items():
            result.append(f"{cam_name}_{serial_number}")
        return result
    
    def get_captuers_dict(self) -> dict:
        return [
            {"cam_name": cam_name, "serial_number": s_n}
            for s_n, cam_name in self.name_to_serial.items()
        ]

    def read_one(self, cam_name:str) -> np.ndarray:
        """ 获取某个相机最新的视频帧
        名称->采集器 """
        assert cam_name in self.name_to_cap, f"Camera '{cam_name}' not registered"
        return self.name_to_cap[cam_name].read()

    def read_multi(self, cam_names) -> dict:
        """ 获取多个相机最新的视频帧 """
        result = {}
        for cam_name in cam_names:
            assert cam_name in self.name_to_cap, f"Camera '{cam_name}' not registered"
            result[cam_name] = self.name_to_cap[cam_name].read()
        return result

    def read_all(self) -> dict:
        """
        读取所有已注册相机的最新帧，根据所有名称
        Returns:
            Dict[str, np.ndarray]: {cam_name: frame} 字典形式返回各相机当前帧
        """
        result = {}
        for cam_name, capture in self.name_to_cap.items():
            result[cam_name] = capture.read()
        return result

    def close_capture(self, cam_name:str):
        """Close a specific camera."""
        if cam_name not in self.name_to_cap:
            self.print(f"[VCCM] <close_capture> Camera '{cam_name}' not found.", "yellow")
            return
        try:
            serial_name = self.name_to_serial[cam_name]

            # 减少serial引用计数，引用为0时表示不需要对应的采集器，关闭对应的采集器
            self.serial_ref_count[serial_name] -= 1
            if self.serial_ref_count[serial_name] == 0:
                self.serial_to_capture[serial_name].close()  # 关闭对应的采集器
                # 删除serial相关信息
                del self.serial_to_capture[serial_name]
                del self.serial_ref_count[serial_name]
            
            # 仅删除cam_name对应信息
            del self.name_to_cap[cam_name]
            del self.name_to_serial[cam_name]

        except Exception as e:
            print(f"[VCCM] Failed to close '{cam_name}', e: {e}")

    def close_capture_multi(self, cam_names:list[str]):
        """
        批量关闭指定名称的相机资源

        Args:
            cam_names (List[str]): 要关闭的相机名称列表
        """
        for cam_name in cam_names:
            self.close_capture(cam_name)

    def close_capture_all(self):
        """Close all capture"""
        for serial_number, capture in self.serial_to_capture.items():
            try:
                capture.close()
            except Exception as e:
                print(f"[VCCM] Failed to close camera serial={serial_number}: {e}")
        print_green(f"[VCCM] success to close all camera")

class VideoCaptureCommon:
    """
    用于视频捕获的类，支持多线程读取视频帧并存储到队列中。

    功能描述：
    - 维持具体的相机接口
    - 初始化时创建一个线程，用于持续从视频源中读取帧。
    - 使用队列存储最新的视频帧，确保队列中只保留最新的一帧。
    - 提供方法读取队列中的帧数据，并支持关闭视频捕获功能。

    属性：
    - name: 视频捕获对象的名称，默认为传入的 capture 对象的名称。
    - queue: 用于存储视频帧的队列。
    - capture: 视频捕获对象，通常是一个 OpenCV 的 VideoCapture 实例。
    - t: 线程对象，用于在后台持续读取视频帧。
    - enable: 控制视频捕获线程是否继续运行的标志。

    方法：
    - __init__(self, capture, name=None): 构造函数，初始化视频捕获对象及线程。
    - _reader(self): 私有方法，在线程中运行，负责从视频源读取帧并存入队列。
    - read(self): 从队列中获取最新的视频帧。
    - close(self): 关闭视频捕获线程及资源。
    """

    def __init__(self, capture, name=None):
        if name is None:
            name = capture.name
        self.name = name
        self.capture = capture  # 具体的相机采集接口

        self.enable = True
        self.t = threading.Thread(target=self._reader)
        self.t.daemon = True
        self.t.start()

        self.initialized = False  # 初始化就绪标志位
        self.latest_frame = None  # 共享帧存储
        self.frame_lock = threading.Lock()  # 线程锁
        self._last_hb = time.time()   # [dbg] 读帧心跳

    def _reader(self):
        max_fail_count = 10  # 最大失败次数
        fail_count = 0      # 当前失败计数
        while self.enable:
            _rd_t0 = time.time()
            ret, frame = self.capture.read()
            _rd = time.time() - _rd_t0
            
            if not ret:
                fail_count += 1
                print_yellow(f"[VideoCapture] {self.name} read failed {fail_count} times")
                if fail_count >= max_fail_count:
                    print_red(f"[VideoCapture] {self.name} read failed too many times. Exiting reader thread.")
                    self.enable = False
                    break
                time.sleep(0.1)
                continue

            # [dbg] 慢读取告警 + 5s 心跳；心跳停更 = 读帧线程卡死（卡在 capture.read 内部）
            _now = time.time()
            if _rd > 0.3 or _now - self._last_hb > 5.0:
                self._last_hb = _now
                if os.environ.get("AUBO_DBG", "1") == "1":
                    print(f"[dbg][cam:{self.name}] read={_rd*1000:.0f}ms alive", flush=True)
            # 更新共享帧
            with self.frame_lock:
                self.latest_frame = frame
                self.initialized = True 

    def read(self):
        """ 返回最新的帧
        超时检查机制 """
        start_time = time.time()
        while not self.initialized:
            time.sleep(0.1)
            if time.time() - start_time > 2:
                raise TimeoutError(f"[{self.name}] Timeout waiting for camera initialization.")
        with self.frame_lock:
            return self.latest_frame.copy()

    def close(self):
        """ 停止帧采集线程，停止相机资源 """
        self.enable = False
        self.t.join()
        self.capture.close()


class VideoCapture:
    """
    用于视频捕获的类，支持多线程读取视频帧并存储到队列中。

    功能描述：
    - 维持具体的相机接口
    - 初始化时创建一个线程，用于持续从视频源中读取帧。
    - 使用队列存储最新的视频帧，确保队列中只保留最新的一帧。
    - 提供方法读取队列中的帧数据，并支持关闭视频捕获功能。

    属性：
    - name: 视频捕获对象的名称，默认为传入的 capture 对象的名称。
    - queue: 用于存储视频帧的队列。
    - capture: 视频捕获对象，通常是一个 OpenCV 的 VideoCapture 实例。
    - t: 线程对象，用于在后台持续读取视频帧。
    - enable: 控制视频捕获线程是否继续运行的标志。

    方法：
    - __init__(self, capture, name=None): 构造函数，初始化视频捕获对象及线程。
    - _reader(self): 私有方法，在线程中运行，负责从视频源读取帧并存入队列。
    - read(self): 从队列中获取最新的视频帧。
    - close(self): 关闭视频捕获线程及资源。
    """

    """ 
    TODO：同一个相机（capture）被多个videocapture使用可能存在问题
    """

    def __init__(self, capture, name=None, image_cropper=None):
        if name is None:
            name = capture.name
        self.name = name
        self.queue = queue.Queue()
        self.capture = capture  # 具体的相机采集接口
        self.image_cropper = image_cropper

        self.t = threading.Thread(target=self._reader)
        self.t.daemon = True
        self.enable = True
        self.t.start()

    def _reader(self):
        while self.enable:
            ret, frame = self.capture.read()
            if not ret:
                print("[VideoCapture] {} read failed".format(self.name))
                break
            """ 队列不为空则移除之前的帧，保证队列中只有最新的一帧 """
            if not self.queue.empty():
                try:
                    self.queue.get_nowait()  # discard previous (unprocessed) frame
                except queue.Empty:
                    pass
            self.queue.put(frame)

    def read(self, croppe = False):
        """ 获取最新的视频帧，可以添加裁剪功能 """
        frame = self.queue.get(timeout=2)
        if croppe and self.image_cropper is not None:
            frame = self.image_cropper(frame)  # 应用裁剪函数
        elif croppe:
            print("[VideoCapture] cropper is None")
        return frame

    def close(self):
        self.enable = False
        self.t.join()
        self.capture.close()
