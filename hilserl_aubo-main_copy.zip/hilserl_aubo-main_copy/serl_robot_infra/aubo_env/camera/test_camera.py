from aubo_env.camera.video_capture import VideoCaptureManager
import threading
import queue
import numpy as np
import cv2
from typing import Dict
import time

class envImageDisplayer(threading.Thread):
    """ 由于各环境调用的相机、画面裁切各不同，因此每个env单独持有ImageDisplayer """
    def __init__(self, queue, name):
        threading.Thread.__init__(self)
        self.queue = queue  # ref of queue
        self.daemon = True  # make this a daemon thread
        self.name = name
        # self.size_imshow = (1280, 720)
        self.size_imshow = (500, 500)
        self._running = True

    def run(self):
        self.initialize_window()
        while self._running:
            try:
                img_array = self.queue.get(timeout=1)
                if (img_array is None) or (not self._running):
                    break

                frame = np.concatenate(
                    [cv2.resize(v, self.size_imshow) for k, v in img_array.items() if "full" in k], axis=1
                )
                cv2.imshow(self.name, frame)
                cv2.waitKey(1)

            except queue.Empty:
                continue  # 超时后继续检查_running状态，确保可以响应shutdown

        cv2.destroyAllWindows()

    def initialize_window(self):
        """Initialize the image window before entering the main loop."""
        frame = np.zeros(self.size_imshow, dtype=np.uint8)  # Create a blank frame
        cv2.imshow(self.name, frame)
        cv2.waitKey(1)

    def shutdown(self):
        """显式关闭线程和图像窗口"""
        self._running = False
        self.queue.put(None)  # 可选：加速线程退出 

class RealSenseCamera:
    def __init__(self):
        REALSENSE_CAMERAS: dict = {
            "wrist_1": {
                "serial_number": "218622274130",    #正：218622273967   侧：218622275245  
                "dim": (1280, 720),
                "exposure": 60000,
            },   
            "wrist_2": {
                "serial_number": "427622270618",
                "dim": (1280, 720),
                "exposure": 60000,
            },
        }
        self.IMAGE_CROP: dict[str, callable] = {
            # "wrist_1": lambda img: img[:720, :1280],
            "wrist_1": lambda img: img[50:400, 600:950],
            "wrist_2": lambda img: img[300:650, 650:1000],
        }
        DISPLAY_IMAGE: bool = True

        self.display_image = DISPLAY_IMAGE
        self.camera_config = REALSENSE_CAMERAS
        self.camera_manager = VideoCaptureManager()

        self.init_cameras()
        if self.display_image:
            self.display_img_queue = queue.Queue()
            self.displayer = envImageDisplayer(self.display_img_queue, "diana_env")
            self.displayer.start()   

    def get_image(self) -> Dict[str, np.ndarray]:
        """Get images from the realsense cameras."""
        obs_image = {}
        display_image = {}
        rec_image = {}  # New dictionary to store full resolution cropped images
        for cam_name in self.camera_config.keys():
            try:
                rgb = self.camera_manager.read_one(cam_name)
                # 裁切关键部分
                cropped_rgb = self.IMAGE_CROP[cam_name](rgb) if cam_name in self.IMAGE_CROP else rgb

                display_image[cam_name + "_full"] = cropped_rgb
            except TimeoutError as e:
                print(f"[{cam_name}] Read timeout: {e}")
                input(f"{cam_name} camera frozen. Check connect, then press enter to relaunch...")
                self.close_cameras()
                self.init_cameras()
                return self.get_image()

        if self.display_image:
            self.display_img_queue.put(display_image)
        return obs_image    
          
    def init_cameras(self):
        """ 传入相机配置字典 """
        self.camera_manager.add_capture_multi(self.camera_config)

    def close_cameras(self):
        """Close cameras in list"""
        try:
            for cam_name in self.camera_config.keys():
                self.camera_manager.close_capture(cam_name)
        except Exception as e:
            print(f"Failed to close cameras: {e}")

def main():
    cameras=RealSenseCamera()
    while True:
        cameras.get_image()
        time.sleep(0.01)


if __name__ == '__main__':
    main()