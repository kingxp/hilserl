import os
import struct
import serial
from scipy.spatial.transform import Rotation
import numpy as np
import threading
import time
import modern_robotics as mr
import json
from aubo_env.utils import filter
from aubo_env.utils import general_func as gfunc
from aubo_env.controller import aubo_sdk_wripper

# 彩色打印
def print_red(text):
    print(f"\033[31m{text}\033[0m")

def print_green(text):
    print(f"\033[32m{text}\033[0m")

def print_yellow(text):
    print(f"\033[33m{text}\033[0m")

'''
力传接在遨博机械臂控制柜上, 利用aubo_sdk获取传感器数据。
利用自开发标定算法对力传进行重力补偿，可在任务空间中进行标定，在执行任务时会具有更好的效果。
'''

robot_ip = '169.254.111.99'
# 数据文件路径
current_path = os.path.dirname(os.path.abspath(__file__))
data_path = os.path.join(current_path, 'calibration_data.txt')
para_path = os.path.join(current_path, 'para.json')

deg2rad = np.pi / 180.0
np.set_printoptions(precision=4, suppress=True)
class KunWei_SerialComm():
    def __init__(self, robot, parafile_exist=True):
        # aubo机械臂实例化
        self.robot = robot

        # 设置力传
        self.robot.set_force_sensor('kw_ftsensor')

        # 采样周期
        self.cycle_t = 0.001

        # 力传数据
        self.wrench = np.zeros(6)
        self.filtered_wrench = np.zeros(6)

        # 滤波器初始化
        process_noise = np.array([0.00005, 0.00005, 0.00005, 0.000005, 0.000005, 0.000005])
        measurement_noise = np.array([0.1, 0.1, 0.1, 0.004, 0.004, 0.004])
        self.kalman_filter = filter.KalmanFilter(6, process_noise, measurement_noise)   # 滞后严重?
        self.fir_filter = filter.FIRFilter(6, 10)

        if not parafile_exist:
            # 负载质心在传感器坐标系下的坐标(m)
            self.x = -0.004020
            self.y = 0.000716
            self.z = 0.048057
            self.r = np.array([self.x, self.y, self.z])
            # 传感器零点(kg,kgm)
            self.Fx0 = 0.123909
            self.Fy0 = 0.924607
            self.Fz0 = -0.024658
            self.Mx0 = 0.035355
            self.My0 = 0.006819
            self.Mz0 = 0.000951
            # 负载质量(kg)
            self.load = 1.672435
            # 底座倾角(°)
            self.rx = 0.309371
            self.ry = -0.356943
        else:

            with open(para_path, "r") as openfile:
                data = json.load(openfile)

            # 负载质心在传感器坐标系下的坐标(m)
            self.x = data["x"][0]
            self.y = data["y"][0]
            self.z = data["z"][0]
            self.r = np.array([self.x, self.y, self.z])
            # 传感器零点(kg,kgm)
            self.Fx0 = data["Fx0"][0]
            self.Fy0 = data["Fy0"][0]
            self.Fz0 = data["Fz0"][0]
            self.Mx0 = data["Mx0"][0]
            self.My0 = data["My0"][0]
            self.Mz0 = data["Mz0"][0]
            # 负载质量(kg)
            self.load = data["G"][0]
            # 底座倾角(°)
            self.rx = data["alpha"][0]
            self.ry = data["beta"][0]

        # 重力加速度
        self.g = 10 # 单位：N/kg

        # 最大力/力矩
        self.Fmax = 200 * 0.8
        self.Mmax = 10 * 0.8

        # 世界坐标系到基座坐标系的齐次变换矩阵
        vector_x = [self.rx*deg2rad, 0, 0]
        vector_y = [0, self.ry*deg2rad, 0]
        R_world_base = Rotation.from_rotvec(vector_x) * Rotation.from_rotvec(vector_y)
        self.R_base_world = R_world_base.inv().as_matrix()

        # 法兰盘坐标系到传感器坐标系的齐次变换矩阵
        flange_sensor_pose = [0, 0, 0.098, 0, 0, 0]
        self.T_flange_sensor = self.pose2Matrix(flange_sensor_pose)

        # 法兰盘坐标系到TCP坐标系的齐次变换矩阵
        flange_tcp_pose = [0.00048, 0.00015, 0.26018, 0, 0, 0]
        self.T_flange_tcp = self.pose2Matrix(flange_tcp_pose)

        # 传感器坐标系到TCP坐标系的齐次变换矩阵
        self.T_sensor_tcp = np.linalg.inv(self.T_flange_sensor) @ self.T_flange_tcp

    # 将位姿转换成齐次变换矩阵
    def pose2Matrix(self, pose):
        pos = pose[:3]
        rpy = pose[3:]
        T = np.eye(4)
        T[:3,:3] = Rotation.from_euler('xyz',rpy).as_matrix()
        T[:3,3] = np.array(pos)
        return T

    # 利用法兰盘位姿计算传感器位姿
    def flangePose2SensorPose(self, flange_pose):
        pos = flange_pose[:3]
        rpy = flange_pose[3:]
        T_base_flange = np.eye(4)
        T_base_flange[:3,:3] = Rotation.from_euler('xyz',rpy).as_matrix()
        T_base_flange[:3,3] = np.array(pos)
        T_base_sensor = T_base_flange @ self.T_flange_sensor

        R = T_base_sensor[:3,:3]
        output_rpy = Rotation.from_matrix(R).as_euler('xyz')
        output_pos = T_base_sensor[:3,3]
        output = np.concatenate([output_pos, output_rpy])
        return output.tolist()
        
    # 计算传感器坐标系所受外力
    def calSensorExternalWrench(self, tcp_pose_):
        '''
        当传感器坐标系与tcp坐标系姿态一致时， 可传入tcp的位姿
        当传感器坐标系与法兰盘坐标系姿态一致时，可传入法兰盘坐标系位姿
        否则，还是需要传入传感器坐标系位姿
        '''
        tcp_pose = tcp_pose_.copy()
        filtered_wrench = self.filtered_wrench.copy()

        rpy = tcp_pose[3:]
        R_base_sensor = Rotation.from_euler('xyz', rpy) #ZYX欧拉角

        # 负载重力补偿
        R_sensor_base = R_base_sensor.inv().as_matrix()
        world_Fg = np.array([0,0,-self.load])
        sensor_Fg = R_sensor_base @ self.R_base_world @ world_Fg
        sensor_Mg = np.cross(self.r, sensor_Fg)
        sensor_external_wrench = filtered_wrench
        sensor_external_wrench[0] = sensor_external_wrench[0] - self.Fx0 - sensor_Fg[0]
        sensor_external_wrench[1] = sensor_external_wrench[1] - self.Fy0 - sensor_Fg[1]
        sensor_external_wrench[2] = sensor_external_wrench[2] - self.Fz0 - sensor_Fg[2]
        sensor_external_wrench[3] = sensor_external_wrench[3] - self.Mx0 - sensor_Mg[0]
        sensor_external_wrench[4] = sensor_external_wrench[4] - self.My0 - sensor_Mg[1]
        sensor_external_wrench[5] = sensor_external_wrench[5] - self.Mz0 - sensor_Mg[2]
        # sense_external_wrench = sense_external_wrench * self.g
        # print(f"sense_external_wrench:{sense_external_wrench}")

        # 在工具坐标系下描述的外力力旋
        tool_external_wrench = sensor_external_wrench.copy()

        # 在基座坐标系下描述的外力力旋
        base_external_wrench = sensor_external_wrench.copy()
        base_external_wrench[:3] = R_base_sensor.as_matrix() @ base_external_wrench[:3]
        base_external_wrench[3:] = R_base_sensor.as_matrix() @ base_external_wrench[3:]
        # print(f"base_external_wrench:{base_external_wrench}")

        return base_external_wrench

    # 计算Tcp坐标系所受外力
    def calTcpExternalWrench(self, tcp_pose_):
        '''
        传入tcp位姿
        '''
        tcp_pose = tcp_pose_.copy()
        filtered_wrench = self.filtered_wrench.copy()

        rpy = tcp_pose[3:]
        R_base_tcp = Rotation.from_euler('xyz', rpy).as_matrix() #ZYX欧拉角
        R_tcp_sensor = np.linalg.inv(self.T_sensor_tcp[:3, :3])
        R_base_sensor = R_base_tcp @ R_tcp_sensor

        # 负载重力补偿
        R_sensor_base = np.linalg.inv(R_base_sensor)
        world_Fg = np.array([0,0,-self.load])
        sensor_Fg = R_sensor_base @ self.R_base_world @ world_Fg
        sensor_Mg = np.cross(self.r, sensor_Fg)
        sensor_external_wrench = filtered_wrench
        sensor_external_wrench[0] = sensor_external_wrench[0] - self.Fx0 - sensor_Fg[0]
        sensor_external_wrench[1] = sensor_external_wrench[1] - self.Fy0 - sensor_Fg[1]
        sensor_external_wrench[2] = sensor_external_wrench[2] - self.Fz0 - sensor_Fg[2]
        sensor_external_wrench[3] = sensor_external_wrench[3] - self.Mx0 - sensor_Mg[0]
        sensor_external_wrench[4] = sensor_external_wrench[4] - self.My0 - sensor_Mg[1]
        sensor_external_wrench[5] = sensor_external_wrench[5] - self.Mz0 - sensor_Mg[2]

        # 在传感器坐标系下描述的传感器坐标系处所受力旋
        sensor_sensor_wrench = sensor_external_wrench.copy()

        # 在tcp坐标系下描述的tcp坐标系处所受力旋
        T_sensor_tcp = self.T_sensor_tcp.copy()
        T_tcp_sensor = np.linalg.inv(T_sensor_tcp)        
        R_tcp_sensor = T_tcp_sensor[:3,:3]
        P_tcp_sensor = T_tcp_sensor[:3,3]
        tcp_tcp_F =  R_tcp_sensor @ sensor_sensor_wrench[:3]
        tcp_tcp_M =  np.cross(P_tcp_sensor, R_tcp_sensor) @ sensor_sensor_wrench[:3] + R_tcp_sensor @ sensor_sensor_wrench[3:]
        tcp_tcp_wrench = np.concatenate([tcp_tcp_F, tcp_tcp_M])

        # 在基座坐标系下描述的tcp坐标系处所受力旋
        base_external_wrench = np.zeros(6)
        base_external_wrench[:3] = R_base_tcp @ tcp_tcp_wrench[:3]
        base_external_wrench[3:] = R_base_tcp @ tcp_tcp_wrench[3:]        

        return base_external_wrench

    def update(self):
        self.readData()
        # self.filtered_wrench = self.kalman_filter.filter(np.array(self.wrench)) 
        self.filtered_wrench = self.fir_filter.filter(self.wrench)
 
    def run(self):
        while True:
            start_time = time.monotonic()
            self.readData()
            # self.filtered_wrench = self.kalman_filter.filter(np.array(self.wrench))
            self.filtered_wrench = self.fir_filter.filter(self.wrench)
            time.sleep(max(0, self.cycle_t - (time.monotonic() - start_time))) 
            
    def readData(self):
        self.wrench = self.robot.get_sensor_force()


''' 力传标定 '''
# 采集数据
def collect_data():
    '''
    需要采集的数据是力传感器数据（即wrench_sensor_sensor）以及传感器姿态（即R_base_sensor）
    若传感器坐标系与tcp坐标系或法兰盘坐标系姿态一致，则也可采集tcp或法兰盘的姿态数据
    '''
    robot = aubo_sdk_wripper.AuboArm(robot_ip)
    sensor = KunWei_SerialComm(robot)
    update_data_thread = threading.Thread(target=sensor.run, daemon=True)
    update_data_thread.start()

    while(input("按回车键以进行记录")==''):
        print("开始记录...")

        # 采集1000次数据取平均值
        sum = np.zeros(6)
        forces_temp = np.zeros(6)
        num = 1000
        for i in range(num):
            forces = sensor.wrench
            forces_temp = np.array(forces)
            sum += forces_temp
            print(f"({i}) {forces}")
            time.sleep(0.001)
        mean_forces = sum / num

        print(f"均值: {mean_forces}")

        # 在实际使用时，读取传感器坐标系处所受力旋进行力控
        # 由于不能保证工具坐标系与传感器坐标系姿态一致，所以使用法兰盘坐标系进行坐标变换，变换到基座坐标系
        pose = robot.get_flange_pose()
        rpy = np.array(pose[3:])*180.0/np.pi
        print(f"欧拉角: {rpy}")
        data=np.concatenate((mean_forces,rpy))

        # 写入数据到文件
        with open(data_path, 'a') as file:
            for item in data:
                x="{:.6f}".format(item)
                file.write(f"{x}\t")
            file.write(f"\n")
        print("数据已成功写入 calibration_data.txt 文件") 

# 计算标定参数
def cal_parameters():

    def read_numeric_data(file_path):
        """
        从txt文件中读取数值数据并返回数值列表的列表
        自动处理空格、制表符、逗号分隔的数据
        自动转换整数和浮点数
        """
        data_list = []
        
        with open(file_path, 'r') as file:
            for line in file:
                # 移除行首尾空白字符
                clean_line = line.strip()
                
                if not clean_line:  # 跳过空行
                    continue
                
                # 替换常见分隔符为空格
                for sep in [',', ';', '\t']:
                    clean_line = clean_line.replace(sep, ' ')
                
                # 分割字符串并转换为数值
                row = []
                for item in clean_line.split():
                    try:
                        # 尝试转换为整数
                        row.append(int(item))
                    except ValueError:
                        try:
                            # 尝试转换为浮点数
                            row.append(float(item))
                        except ValueError:
                            # 保留无法转换的值（字符串）
                            row.append(item)
                
                data_list.append(row)
        
        return data_list

    def solve_least_squares_svd(A, B):
        '''最小二乘法'''
        U, s, Vt = np.linalg.svd(A, full_matrices=False)
        # 计算奇异值的伪逆（避免除零错误）
        threshold = np.finfo(s.dtype).eps * max(A.shape) * s[0]
        s_inv = np.where(s > threshold, 1 / s, 0)
        # 计算 x = V^T * diag(s_inv) * U^T * B
        x = Vt.T @ np.diag(s_inv) @ U.T @ B
        return x

    numeric_data = read_numeric_data(data_path)

    # 求x,y,z,K1,K2,K3
    A = []
    B = []
    for data in numeric_data:
        Fx = data[0]
        Fy = data[1]
        Fz = data[2]
        Mx = data[3]
        My = data[4]
        Mz = data[5]
        a = np.array([[0, Fz, -Fy, 1, 0, 0], [-Fz, 0, Fx, 0, 1, 0], [Fy, -Fx, 0, 0, 0, 1]])
        b = np.array([[Mx], [My], [Mz]])
        A.append(a)
        B.append(b)    
    A1 = np.vstack(A)
    B1 = np.vstack(B)
    X1 = solve_least_squares_svd(A1, B1)
    
    # 求Lx,Ly,Lz,Fx0,Fy0,Fz0
    A = []
    B = []
    deg2rad = np.pi/180.0
    for data in numeric_data:
        Fx = data[0]
        Fy = data[1]
        Fz = data[2]                
        rx = data[6]*deg2rad
        ry = data[7]*deg2rad
        rz = data[8]*deg2rad
        R = Rotation.from_rotvec([0,0,rz])* Rotation.from_rotvec([0,ry,0])* Rotation.from_rotvec([rx,0,0])
        a = np.hstack((R.inv().as_matrix(), np.eye(3)))
        b = np.array([[Fx],[Fy],[Fz]])
        A.append(a)
        B.append(b)    
    A2 = np.vstack(A)
    B2 = np.vstack(B)
    X2 = solve_least_squares_svd(A2, B2)

    # 最终参数
    x = X1[0]
    y = X1[1]
    z = X1[2]
    K1 = X1[3]
    K2 = X1[4]
    K3 = X1[5]

    Lx = X2[0]
    Ly = X2[1]
    Lz = X2[2]
    Fx0 = X2[3]
    Fy0 = X2[4]
    Fz0 = X2[5]

    Mx0 = K1 + y*Fz0 - z*Fy0
    My0 = K2 + z*Fx0 - x*Fz0
    Mz0 = K3 + x*Fy0 - y*Fx0

    beta_r = np.arctan(-Lx/Lz)
    alpha_r = np.arctan(-Ly*np.sin(beta_r)/Lx)
    G = -Ly/np.sin(alpha_r)

    rad2deg = 180/np.pi
    alpha = alpha_r*rad2deg
    beta = beta_r*rad2deg

    # 记录数据到文件
    jsondata = {
        "x": x.tolist(),
        "y": y.tolist(),
        "z": z.tolist(),
        "Fx0" : Fx0.tolist(),
        "Fy0" : Fy0.tolist(),
        "Fz0" : Fz0.tolist(),
        "Mx0" : Mx0.tolist(),
        "My0" : My0.tolist(),
        "Mz0" : Mz0.tolist(),
        "alpha" : alpha.tolist(),
        "beta" : beta.tolist(),
        "G" : G.tolist(),
    }
    with open(para_path, "w") as outfile:
        json.dump(jsondata, outfile)
        outfile.write("\n")

    print(f"x:{x}, y:{y}, z:{z}")
    print(f"Fx0:{Fx0}, Fy0:{Fy0}, Fz0:{Fz0}, Mx0:{Mx0}, My0:{My0}, Mz0:{Mz0}")
    print(f"alpha:{alpha}, beta:{beta}, G:{G}")

# 标定参数验证
def validation_test(mode='tcp'):
    robot = aubo_sdk_wripper.AuboArm(robot_ip)
    sensor = KunWei_SerialComm(robot)
    update_data_thread = threading.Thread(target=sensor.run, daemon=True)
    update_data_thread.start()

    while True:
        if mode == 'tcp':
            pose = robot.get_tcp_pose()
            external_forces = sensor.calTcpExternalWrench(pose)
            print_green(f"external_forces: {external_forces}")
            # forces = robot.get_tcp_force()
            # print_red(f"external_forces: {forces}")
            time.sleep(0.5)                
        else:
            # 法兰盘坐标系与传感器坐标系的姿态一致，故使用法兰盘坐标系的姿态将传感器坐标系所受力旋变换到基座坐标系下描述
            pose = robot.get_flange_pose()
            external_forces = sensor.calSensorExternalWrench(pose)
            print(f"external_forces: {external_forces}")
            time.sleep(0.5)

# 显示原始数据
def display_raw_data():
    robot = aubo_sdk_wripper.AuboArm(robot_ip)
    sensor = KunWei_SerialComm(robot)
    update_data_thread = threading.Thread(target=sensor.run, daemon=True)
    update_data_thread.start()
    while True:
        sensor_wrench = np.array(sensor.wrench)

        print(f"external_forces: {sensor_wrench}")
        time.sleep(0.5)        

if __name__ == "__main__":
    # collect_data()
    # cal_parameters()
    # validation_test()
    display_raw_data()
